#!/usr/bin/env python3
"""
Jarvis Monitoring Agent (Docker)
Universal monitoring agent for remote servers

Monitors:
- Docker containers
- HTTP/HTTPS endpoints
- System resources (TODO: future enhancement)

Sends alerts to Jarvis API when issues detected.
"""
import os
import requests
import docker
import time
import sys
import signal
from datetime import datetime

# Configuration from environment variables
JARVIS_API = (
    os.getenv("JARVIS_API")
    or os.getenv("JARVIS_API_URL")
    or "http://localhost:8880/api/alerts"
)
JARVIS_API_KEY = os.getenv("JARVIS_API_KEY", "")  # Optional: for auth-enabled Jarvis API
CHECK_INTERVAL = int(os.getenv("CHECK_INTERVAL", "60"))
MONITOR_CONTAINERS = [c.strip() for c in os.getenv("MONITOR_CONTAINERS", "").split(",") if c.strip()]
SOURCE_NAME = os.getenv("SOURCE_NAME", os.uname().nodename)
AUTO_RESOLVE_INTERVAL = int(os.getenv("AUTO_RESOLVE_INTERVAL", "60"))  # Faster auto-resolve (60s default)
ALERT_TIMEOUT = int(os.getenv("ALERT_TIMEOUT", "30"))  # Timeout for Jarvis API calls (increased for TTS)


def _get_auth_headers() -> dict:
    """Get headers for Jarvis API requests, including auth if configured."""
    headers = {"Content-Type": "application/json"}
    if JARVIS_API_KEY:
        headers["Authorization"] = f"Bearer {JARVIS_API_KEY}"
    return headers


def _response_detail(response: requests.Response) -> str:
    """Return a short, log-safe response detail for failed API calls."""
    try:
        payload = response.json()
        if isinstance(payload, dict):
            detail = payload.get("detail") or payload.get("error") or payload.get("message")
            if detail:
                return str(detail)
            return str(payload)
        return str(payload)
    except ValueError:
        return (response.text or "").strip()[:300]


def parse_monitor_urls(env_value: str) -> list:
    """
    Parse MONITOR_URLS with optional names.
    
    Formats supported:
      - Simple URL: http://host:port/health
      - Named URL: friendly-name|http://host:port/health
    
    Returns list of tuples: [(name, url), ...]
    """
    urls = []
    for entry in env_value.split(","):
        entry = entry.strip()
        if not entry:
            continue
        
        if "|" in entry:
            # Named format: name|url
            parts = entry.split("|", 1)
            name = parts[0].strip()
            url = parts[1].strip()
        else:
            # Simple format: url only (extract hostname for name)
            url = entry
            # Create name from URL: http://192.168.60.155:8080/health -> 192.168.60.155:8080
            try:
                name = url.split("//")[-1].split("/")[0]
            except:
                name = url
        
        urls.append((name, url))
    return urls


# Parse URLs with names
MONITOR_URLS = parse_monitor_urls(os.getenv("MONITOR_URLS", ""))

# Global state
running = True


def signal_handler(sig, frame):
    """Handle graceful shutdown."""
    global running
    print("\n🛑 Shutdown signal received, stopping gracefully...")
    running = False


def send_alert(title, description, severity, auto_resolve_url=None, metadata=None):
    """Send alert to Jarvis."""
    payload = {
        "title": title,
        "description": description,
        "severity": severity,
        "source": SOURCE_NAME,
    }
    
    if auto_resolve_url:
        payload["auto_resolve_url"] = auto_resolve_url
        payload["auto_resolve_check_interval"] = AUTO_RESOLVE_INTERVAL  # Use configured interval
    
    if metadata:
        payload["metadata"] = metadata
    
    try:
        response = requests.post(JARVIS_API, json=payload, headers=_get_auth_headers(), timeout=ALERT_TIMEOUT)
        if not response.ok:
            detail = _response_detail(response)
            print(
                f"❌ Failed to send alert: HTTP {response.status_code}"
                f"{f' - {detail}' if detail else ''}",
                file=sys.stderr
            )
            if response.status_code in (401, 403) and not JARVIS_API_KEY:
                print(
                    "   Jarvis API auth is enabled, but JARVIS_API_KEY is not configured in this monitor container.",
                    file=sys.stderr
                )
            return {"ok": False, "status_code": response.status_code, "error": detail}
        return response.json()
    except ValueError as e:
        print(f"❌ Failed to parse Jarvis API response: {e}", file=sys.stderr)
        return None
    except requests.exceptions.RequestException as e:
        print(f"❌ Failed to send alert: {e}", file=sys.stderr)
        return None


def resolve_alerts_by_source(title_pattern: str):
    """Resolve pending alerts matching title pattern from this source."""
    try:
        # Get pending alerts for this source
        response = requests.get(
            JARVIS_API.replace('/alerts', '/alerts'),
            params={"status": "pending", "source": SOURCE_NAME},
            headers=_get_auth_headers(),
            timeout=ALERT_TIMEOUT
        )
        if not response.ok:
            detail = _response_detail(response)
            print(
                f"⚠️  Failed to list alerts for resolution: HTTP {response.status_code}"
                f"{f' - {detail}' if detail else ''}",
                file=sys.stderr
            )
            return False
        
        alerts = response.json().get('alerts', [])
        
        # Find alerts matching the pattern
        for alert in alerts:
            if title_pattern in alert.get('title', ''):
                alert_id = alert['id']
                # Resolve this alert
                resolve_url = JARVIS_API.replace('/alerts', f'/alerts/{alert_id}/resolve')
                resolve_response = requests.post(resolve_url, headers=_get_auth_headers(), timeout=ALERT_TIMEOUT)
                if resolve_response.ok:
                    return True
                detail = _response_detail(resolve_response)
                print(
                    f"⚠️  Failed to resolve alert {alert_id}: HTTP {resolve_response.status_code}"
                    f"{f' - {detail}' if detail else ''}",
                    file=sys.stderr
                )
                return False
        
        return False
    except requests.exceptions.RequestException as e:
        print(f"⚠️  Failed to resolve alerts: {e}", file=sys.stderr)
        return False


def check_url(url):
    """Check if URL is responding."""
    try:
        response = requests.get(url, timeout=15, allow_redirects=True)
        return 200 <= response.status_code < 400
    except requests.exceptions.RequestException:
        return False


def check_container(client, name):
    """Check if Docker container is running."""
    try:
        container = client.containers.get(name)
        return container.status == "running", container.status
    except docker.errors.NotFound:
        return False, "not_found"
    except docker.errors.APIError as e:
        print(f"⚠️  Docker API error for {name}: {e}", file=sys.stderr)
        return None, "error"


def main():
    """Main monitoring loop."""
    print("=" * 60)
    print("🔍 Jarvis Monitoring Agent")
    print("=" * 60)
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Jarvis API: {JARVIS_API}")
    print(f"API Auth: {'✓ Configured' if JARVIS_API_KEY else '✗ None'}")
    print(f"Source Name: {SOURCE_NAME}")
    print(f"Check Interval: {CHECK_INTERVAL}s")
    
    if MONITOR_CONTAINERS:
        print(f"Monitoring Containers: {', '.join(MONITOR_CONTAINERS)}")
    if MONITOR_URLS:
        url_display = [f"{name} ({url})" for name, url in MONITOR_URLS]
        print(f"Monitoring URLs: {', '.join(url_display)}")
    
    print("=" * 60)
    print()
    
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Initialize Docker client
    docker_client = None
    if MONITOR_CONTAINERS:
        try:
            docker_client = docker.from_env()
            print("✅ Docker client initialized")
        except Exception as e:
            print(f"⚠️  Docker not available: {e}")
            print("   Container monitoring disabled")
    
    # Write health file for Docker health check
    try:
        with open('/tmp/monitor_healthy', 'w') as f:
            f.write('ok')
    except:
        pass  # Ignore if can't write (non-Docker environment)
    
    print(f"✅ {SOURCE_NAME} monitoring started")
    print()
    
    # Track last known status
    last_status = {}
    check_count = 0
    
    while running:
        check_count += 1
        current_time = datetime.now().strftime('%H:%M:%S')
        
        # Check URLs
        for name, url in MONITOR_URLS:
            is_up = check_url(url)
            prev = last_status.get(f"url:{url}")
            
            # Status changed from up to down
            if prev and not is_up:
                print(f"[{current_time}] ❌ URL DOWN: {name} ({url})")
                result = send_alert(
                    f"Service Down: {name}",
                    f"{name} is not responding (URL: {url})",
                    "high",
                    auto_resolve_url=url,
                    metadata={"url": url, "name": name, "source": SOURCE_NAME}
                )
                if result and result.get("ok"):
                    print(f"           ✅ Alert sent (ID: {result.get('alert_id')})")
            
            # Status changed from down to up
            elif prev == False and is_up:
                print(f"[{current_time}] ✅ URL UP: {name} ({url})")
            
            last_status[f"url:{url}"] = is_up
        
        # Check Docker containers
        if docker_client:
            for container_name in MONITOR_CONTAINERS:
                is_running, status = check_container(docker_client, container_name)
                prev = last_status.get(f"container:{container_name}")
                
                # Status changed from running to stopped
                if prev and not is_running:
                    print(f"[{current_time}] ❌ CONTAINER STOPPED: {container_name} (status: {status})")
                    result = send_alert(
                        f"Container Stopped: {container_name}",
                        f"Docker container '{container_name}' is no longer running (status: {status})",
                        "high",
                        metadata={
                            "container": container_name,
                            "status": status,
                            "host": SOURCE_NAME
                        }
                    )
                    if result and result.get("ok"):
                        print(f"           ✅ Alert sent (ID: {result.get('alert_id')})")
                
                # Status changed from stopped to running
                elif prev == False and is_running:
                    print(f"[{current_time}] ✅ CONTAINER RUNNING: {container_name}")
                    # Resolve any pending alerts for this container
                    if resolve_alerts_by_source(f"Container Stopped: {container_name}"):
                        print("           ✅ Resolved alert in Jarvis")
                
                last_status[f"container:{container_name}"] = is_running
        
        # Print status summary (only every 10 checks to reduce noise)
        if check_count % 10 == 0:
            statuses = []
            
            for name, url in MONITOR_URLS:
                status = last_status.get(f"url:{url}")
                if status:
                    statuses.append(f"{name}:✓")
                elif status is False:
                    statuses.append(f"{name}:✗")
            
            for container_name in MONITOR_CONTAINERS:
                status = last_status.get(f"container:{container_name}")
                if status:
                    statuses.append(f"{container_name}:✓")
                elif status is False:
                    statuses.append(f"{container_name}:✗")
            
            if statuses:
                print(f"[{current_time}] Status: {' | '.join(statuses)}")
        
        # Update health file
        try:
            with open('/tmp/monitor_healthy', 'w') as f:
                f.write(datetime.now().isoformat())
        except:
            pass
        
        # Wait before next check
        time.sleep(CHECK_INTERVAL)
    
    print("\n✅ Monitoring agent stopped gracefully")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n❌ Fatal error: {e}", file=sys.stderr)
        sys.exit(1)

/**
 * Shared structured tool-result previews for Jarvis Web.
 *
 * Adapters normalize tool-specific payloads into one small presentation model.
 * Future tools can register another adapter without changing ChatUI.
 */
class StructuredResultsRenderer {
  constructor() {
    this.adapters = new Map();
    this._scrollControlsBound = false;
    this._readerDialog = null;
    this._readerOpener = null;
    this._registerDefaultAdapters();
    this._bindScrollControls();
  }

  register(toolName, adapter) {
    if (!toolName || typeof adapter !== 'function') return false;
    this.adapters.set(toolName, adapter);
    return true;
  }

  registeredTools() {
    return Array.from(this.adapters.keys());
  }

  render(toolResultsData = {}, data = {}, toolsUsed = []) {
    this._registerWorkspaceResults(toolResultsData, data);
    const workflow = this._workflowPayload(toolResultsData, data);
    if (workflow) {
      const sections = this._workflowCollections(workflow, toolResultsData, data);
      const html = sections.length ? this._renderWorkflow(workflow, sections) : '';
      if (html) this._scheduleScrollControlsRefresh();
      return html;
    }

    const orchestration = this._directOrchestrationCollections(
      toolResultsData,
      data,
      toolsUsed
    );
    if (orchestration) {
      const html = orchestration.sections.length > 1
        ? this._renderOrchestration(orchestration)
        : (orchestration.sections[0]
          ? this._renderCollection(orchestration.sections[0].collection)
          : '');
      if (html) this._scheduleScrollControlsRefresh();
      return html;
    }

    const collections = [];
    for (const [toolName, adapter] of this.adapters.entries()) {
      const rawPayload = toolResultsData?.[toolName] ?? data?.[toolName];
      const collection = this._adaptCollection(toolName, rawPayload, adapter);
      if (collection) collections.push(collection);
    }
    const html = collections.map(collection => this._renderCollection(collection)).join('');
    if (html) this._scheduleScrollControlsRefresh();
    return html;
  }

  _adaptCollection(toolName, rawPayload, adapter = this.adapters.get(toolName)) {
    if (!adapter && String(toolName).startsWith('mcp_google_workspace_')) {
      this.register(toolName, payload => this._adaptWorkspace(payload));
      adapter = this.adapters.get(toolName);
    }
    if (!adapter) return null;
    const payload = ['tmdb_movies', 'tmdb_tv_shows'].includes(toolName)
      ? this._tmdbDisplayPayload(rawPayload)
      : this._latestPayload(rawPayload);
    if (!payload) return null;
    try {
      const collection = adapter(payload);
      return collection?.items?.length ? collection : null;
    } catch (error) {
      console.warn(`[StructuredResults] Could not render ${toolName}:`, error);
      return null;
    }
  }

  _directTraceEntries(toolResultsData = {}, data = {}, toolsUsed = []) {
    const traceCandidates = [
      toolResultsData?._tool_trace,
      toolResultsData?.data?._tool_trace,
      data?._tool_trace,
      data?.data?._tool_trace,
    ];
    const trace = traceCandidates.find(candidate => Array.isArray(candidate));
    if (trace) {
      return trace.filter(entry => (
        entry && typeof entry === 'object' && String(entry.tool || '').trim()
      ));
    }
    return Array.isArray(toolsUsed)
      ? toolsUsed
        .map(tool => String(tool || '').trim())
        .filter(Boolean)
        .map(tool => ({tool, ok: true}))
      : [];
  }

  _payloadForOccurrence(rawPayload, occurrenceIndex, occurrenceCount) {
    // Direct orchestration stores successful payloads only; failed calls stay
    // in _tool_trace. Match against the success index so an error between two
    // successful calls cannot shift the second payload onto the wrong card.
    if (occurrenceCount <= 1) return rawPayload;
    if (!Array.isArray(rawPayload)) {
      return occurrenceIndex === 0 ? rawPayload : null;
    }
    return occurrenceIndex < rawPayload.length
      ? rawPayload[occurrenceIndex]
      : null;
  }

  _directOrchestrationCollections(toolResultsData = {}, data = {}, toolsUsed = []) {
    const entries = this._directTraceEntries(toolResultsData, data, toolsUsed);
    if (!entries.length) return null;

    const successTotals = new Map();
    for (const entry of entries) {
      if (entry.ok === false) continue;
      const toolName = String(entry.tool || '').trim();
      successTotals.set(toolName, (successTotals.get(toolName) || 0) + 1);
    }

    const successIndexes = new Map();
    const sections = [];
    let failedCalls = 0;
    let callsWithoutCards = 0;

    entries.forEach((entry, callIndex) => {
      const toolName = String(entry.tool || '').trim();
      if (entry.ok === false) {
        failedCalls += 1;
        return;
      }

      const occurrenceIndex = successIndexes.get(toolName) || 0;
      successIndexes.set(toolName, occurrenceIndex + 1);
      const adapter = this.adapters.get(toolName);
      if (!adapter || this._usesDedicatedSurface(toolName)) {
        callsWithoutCards += 1;
        return;
      }

      const rawPayload = toolResultsData?.[toolName] ?? data?.[toolName];
      const occurrencePayload = this._payloadForOccurrence(
        rawPayload,
        occurrenceIndex,
        successTotals.get(toolName) || 0
      );
      const collection = this._adaptCollection(toolName, occurrencePayload, adapter);
      if (!collection) {
        callsWithoutCards += 1;
        return;
      }
      sections.push({
        toolName,
        call: callIndex + 1,
        occurrence: occurrenceIndex + 1,
        collection,
      });
    });

    return {
      sections,
      totalCalls: entries.length,
      failedCalls,
      callsWithoutCards,
    };
  }

  _workflowPayload(toolResultsData = {}, data = {}) {
    const directCandidates = [
      toolResultsData,
      data,
      toolResultsData?.data,
      data?.data,
    ];
    for (const candidate of directCandidates) {
      if (
        candidate
        && typeof candidate === 'object'
        && candidate.workflow_id
        && Array.isArray(candidate.results)
      ) return candidate;
    }

    for (const container of directCandidates) {
      if (!container || typeof container !== 'object') continue;
      const rawWorkflow = container.workflow;
      const candidates = Array.isArray(rawWorkflow)
        ? [...rawWorkflow].reverse()
        : [rawWorkflow];
      const workflow = candidates.find(candidate => (
        candidate
        && typeof candidate === 'object'
        && Array.isArray(candidate.results)
        && (candidate.action === 'run' || candidate.workflow_id)
      ));
      if (workflow) return workflow;
    }
    return null;
  }

  _workflowStepPayload(step) {
    const outputs = Array.isArray(step?.outputs) ? step.outputs : [];
    if (outputs.length) {
      return outputs.map(output => (
        output?.data && typeof output.data === 'object'
          ? output.data
          : (output ?? {})
      ));
    }
    return step?.data ?? null;
  }

  _usesDedicatedSurface(toolName) {
    // The chat renderer already turns the leading YouTube search result into a
    // full-size playable embed. Keep that richer surface instead of duplicating
    // the same result as a compact workflow section.
    return toolName === 'serpapi_youtube_search';
  }

  _workflowUsesDedicatedSurface(toolName) {
    return this._usesDedicatedSurface(toolName);
  }

  _workflowCollections(workflow, toolResultsData = {}, data = {}) {
    const sections = [];
    const representedTools = new Set();
    const steps = Array.isArray(workflow?.results) ? workflow.results : [];

    for (const step of steps) {
      const toolName = String(step?.tool || '').trim();
      if (!toolName) continue;
      representedTools.add(toolName);
      if (step.skipped === true || step.ok === false) continue;
      if (this._workflowUsesDedicatedSurface(toolName)) continue;

      const collection = this._adaptCollection(
        toolName,
        this._workflowStepPayload(step)
      );
      if (collection) {
        sections.push({
          toolName,
          step: step.step,
          collection,
        });
      }
    }

    // Preserve supported payloads that came back beside the explicit step
    // envelopes, but keep them inside the same workflow surface. This is the
    // compatibility fallback for older or provider-specific workflow results.
    for (const [toolName, adapter] of this.adapters.entries()) {
      if (representedTools.has(toolName) || this._workflowUsesDedicatedSurface(toolName)) continue;
      const rawPayload = toolResultsData?.[toolName]
        ?? workflow?.[toolName]
        ?? data?.[toolName];
      const collection = this._adaptCollection(toolName, rawPayload, adapter);
      if (collection) sections.push({toolName, step: null, collection});
    }
    return sections;
  }

  _workflowTitle(workflow) {
    const raw = String(workflow?.workflow_name || workflow?.name || workflow?.workflow_id || 'Workflow');
    return raw
      .replace(/[_-]+/g, ' ')
      .replace(/\b\w/g, letter => letter.toUpperCase());
  }

  _renderWorkflow(workflow, sections) {
    const workflowId = String(workflow?.workflow_id || workflow?.id || 'workflow');
    const skipped = Array.isArray(workflow?.optional_tools_skipped)
      ? workflow.optional_tools_skipped.filter(Boolean).length
      : 0;
    const subtitle = [
      `${sections.length} tool section${sections.length === 1 ? '' : 's'} combined`,
      skipped ? `${skipped} optional source${skipped === 1 ? '' : 's'} unavailable` : '',
    ].filter(Boolean).join(' · ');
    const sectionHtml = sections.map(section => this._renderCollection(
      section.collection,
      {
        embedded: true,
        toolName: section.toolName,
        step: section.step,
      }
    )).join('');

    return `
      <section class="structured-results-workflow-preview" data-workflow-id="${this._escape(workflowId)}" aria-label="Workflow results: ${this._escape(this._workflowTitle(workflow))}">
        <div class="structured-results-workflow-header">
          <div class="structured-results-eyebrow">Workflow results</div>
          <div class="structured-results-heading">${this._escape(this._workflowTitle(workflow))}</div>
          <div class="structured-results-subtitle">${this._escape(subtitle)}</div>
        </div>
        <div class="structured-results-workflow-sections">${sectionHtml}</div>
      </section>
    `;
  }

  _renderOrchestration(orchestration) {
    const sections = orchestration.sections || [];
    const subtitle = [
      `${sections.length} visual section${sections.length === 1 ? '' : 's'} from ${orchestration.totalCalls} tool call${orchestration.totalCalls === 1 ? '' : 's'}`,
      orchestration.failedCalls
        ? `${orchestration.failedCalls} failed`
        : '',
      orchestration.callsWithoutCards
        ? `${orchestration.callsWithoutCards} call${orchestration.callsWithoutCards === 1 ? '' : 's'} without visual cards`
        : '',
    ].filter(Boolean).join(' · ');
    const sectionHtml = sections.map(section => this._renderCollection(
      section.collection,
      {
        embedded: true,
        surface: 'orchestration',
        toolName: section.toolName,
        call: section.call,
        occurrence: section.occurrence,
      }
    )).join('');

    return `
      <section class="structured-results-workflow-preview structured-results-orchestration-preview" data-orchestration-results="true" aria-label="Combined tool results">
        <div class="structured-results-workflow-header">
          <div class="structured-results-eyebrow">Tool results</div>
          <div class="structured-results-heading">Combined results</div>
          <div class="structured-results-subtitle">${this._escape(subtitle)}</div>
        </div>
        <div class="structured-results-workflow-sections">${sectionHtml}</div>
      </section>
    `;
  }

  _registerDefaultAdapters() {
    const helpers = {
      getRows: payload => this._rows(payload),
      list: value => this._list(value),
      formatMarketplacePrice: value => this._formatMarketplacePrice(value),
      formatCount: value => this._formatCount(value),
      compactText: (value, maxLength) => this._compactText(value, maxLength),
      displayText: value => this._displayText(value),
      formatDateTime: value => this._formatDateTime(value),
      formatPrice: (value, currency) => this._formatPrice(value, currency),
      formatFlightTime: value => this._formatFlightTime(value),
    };
    const shopping = window.createShoppingResultAdapters(helpers);
    const search = window.createSearchResultAdapters(helpers);
    const localTravel = window.createLocalTravelResultAdapters(helpers);

    this.register('serpapi_amazon_search', shopping.adaptShoppingSearch);
    // Saved conversations may still contain the pre-rename result key.
    this.register('serpapi_search', shopping.adaptShoppingSearch);
    this.register('serpapi_home_depot', shopping.adaptHomeDepotProduct);
    this.register('serpapi_ebay_search', shopping.adaptEbaySearch);
    this.register('serpapi_ebay_product', shopping.adaptEbayProduct);
    this.register('serpapi_hotel_search', localTravel.adaptHotels);
    this.register('serpapi_yelp_search', localTravel.adaptYelp);
    this.register('serpapi_open_table_reviews', localTravel.adaptOpenTableReviews);
    this.register('serpapi_search_index', search.adaptSearchIndex);
    this.register('searxng_search', search.adaptSearxngSearch);
    this.register('tavily_search', search.adaptTavilySearch);
    this.register('tavily_extract', search.adaptTavilyExtract);
    this.register('serpapi_google_images_light', search.adaptGoogleImagesLight);
    this.register('serpapi_google_news_light', search.adaptGoogleNewsLight);
    this.register('serpapi_google_immersive_product', shopping.adaptGoogleImmersiveProduct);
    this.register('serpapi_google_shopping_light', shopping.adaptGoogleShoppingLight);
    this.register('serpapi_google_sports', search.adaptGoogleSports);
    this.register('serpapi_google_trends', search.adaptGoogleTrends);
    this.register('serpapi_google_trending_now', search.adaptGoogleTrendingNow);
    this.register('serpapi_travel_explore', localTravel.adaptTravelExplore);
    this.register('serpapi_google_events', localTravel.adaptGoogleEvents);
    this.register('serpapi_tripadvisor', localTravel.adaptTripadvisor);
    this.register('trakt_movies', payload => this._adaptTraktMovies(payload));
    this.register('trakt_account', payload => this._adaptTraktAccount(payload));
    this.register('tmdb_movies', payload => this._adaptTmdbMovies(payload));
    this.register('trakt_tv_shows', payload => this._adaptTraktMovies(payload, 'show'));
    this.register('tmdb_tv_shows', payload => this._adaptTmdbMovies(payload, 'show'));
    this.register('flight_search', localTravel.adaptFlights);
    this.register('serpapi_google_local', localTravel.adaptGoogleLocal);
    this.register('serpapi_google_local_services', localTravel.adaptGoogleLocalServices);
    this.register('serpapi_maps_search', localTravel.adaptMaps);
    this.register('serpapi_youtube_search', payload => this._adaptYouTubeSearch(payload));
    this.register('weather', payload => this._adaptWeather(payload));
    this.register('external_network_intel', payload => this._adaptExternalNetworkIntel(payload));
    this.register('gpu_hot_status', payload => this._adaptGpuHotStatus(payload));
    this.register('source_library', payload => {
      const rows = Array.isArray(payload.passages) && payload.passages.length
        ? payload.passages : (payload.sources || (payload.source ? [payload.source] : []));
      return {
        kind: 'generic', heading: 'Source library',
        subtitle: payload.semantic_unavailable_reason || payload.index_error || payload.retrieval_mode || '',
        items: rows.slice(0, 8).filter(row => /^[0-9a-f]{64}$/.test(row.source_id)
          && ['cloud', 'local'].includes(row.mode)).map(row => ({
          title: row.citation || row.title,
          url: new URL(`/library?mode=${row.mode}&source=${row.source_id}`
            + (Number.isInteger(row.number) ? `&passage=${row.number}` : ''), window.location.origin).href,
          primary: row.index_status || (row.matched_by || []).join(' + '),
          details: row.text ? [this._compactText(row.text, 500)] : [],
          actionLabel: 'Open source',
        })),
      };
    });
    this.register('project_nomad', payload => {
      const action = String(payload.action || 'status');
      const hasLongText = action === 'ask' || action === 'read_file' || action === 'passages';
      const rows = action === 'files' ? payload.files
        : action === 'zims' ? payload.zims
        : action === 'models' ? payload.models
        : action === 'collections' ? payload.collections
        : action === 'passages' ? payload.passages : [];
      const items = action === 'ask' ? [{
        title: 'Nomad answer',
        primary: payload.model || '',
        details: [this._compactText(payload.answer, 280)].filter(Boolean),
        expandText: payload.answer,
        expandNote: payload.evidence_note,
        expandLabel: 'Read full answer',
      }] : action === 'read_file' ? [{
        title: payload.source || 'Indexed file',
        primary: payload.next_start_char == null ? 'End of text' : `Continue at character ${payload.next_start_char}`,
        details: [this._compactText(payload.text, 280)].filter(Boolean),
        expandText: payload.text,
        expandNote: payload.evidence_note,
        expandLabel: 'Read file text',
      }] : action === 'status' ? [{
        title: `Nomad server: ${payload.status || 'status unknown'}`,
        primary: payload.rag_online ? 'RAG service online' : 'RAG service offline',
      }] : (Array.isArray(rows) ? rows : []).slice(0, 8).map(row => {
        if (action === 'collections') return {title: String(row)};
        if (!row || typeof row !== 'object') return null;
        if (action === 'passages') {
          const score = Number(row.score);
          return {
            title: row.full_title || row.article_path || 'Indexed passage',
            primary: [row.archive_title, Number.isFinite(score)
              ? `${Math.round(score * 100)}% similarity` : ''].filter(Boolean).join(' · '),
            details: [this._compactText(row.text, 360)].filter(Boolean),
            expandText: row.text,
            expandNote: [payload.evidence_note, row.article_path, row.source].filter(Boolean).join(' · '),
            expandLabel: 'Read passage',
          };
        }
        if (action === 'files') return {
          title: row.file_name || row.source || 'Indexed file',
          primary: row.state || '',
          details: [row.collection, row.source, row.chunks_embedded != null
            ? `${row.chunks_embedded} embedded chunks` : ''].filter(Boolean),
        };
        if (action === 'zims') return {
          title: row.title || row.key || 'ZIM archive',
          primary: row.type || '',
          details: [row.summary, row.key].filter(Boolean),
        };
        return {title: row.name || 'Model', primary: row.cloud ? 'Cloud model' : 'Installed model'};
      }).filter(Boolean);
      if (!items.length) items.push({title: action === 'passages'
        ? 'No indexed passage met the similarity threshold'
        : action === 'collections' && payload.total === 0
        ? 'No named collections; indexed files may still exist'
        : action === 'files' && payload.query ? 'No file names match this search'
        : payload.total === 0 ? 'Nothing here yet' : 'No items at this offset'});
      const inventory = payload.inventory;
      const inventorySummary = action === 'files' && inventory
        ? `${inventory.total_files} stored · ${inventory.files_with_chunks} report embedded chunks`
          + ` · ${inventory.states?.pending_decision || 0} pending`
          + ` · ${inventory.states?.failed || 0} failed`
          + (payload.query ? ` · ${payload.total} name matches` : '')
          + (payload.has_more ? ' · more available' : '')
        : '';
      return {
        kind: 'generic', layout: hasLongText || action === 'status' ? 'list' : 'rail',
        eyebrow: action === 'ask' ? '🗿 Project NOMAD · Unverified answer'
          : action === 'passages' ? '🗿 Project NOMAD · Indexed passages' : '🗿 Project NOMAD',
        heading: action === 'ask' ? 'Project NOMAD · answer'
          : action === 'status' ? 'Project NOMAD · connection'
          : `Project NOMAD · ${action.replace(/_/g, ' ')}`,
        subtitle: action === 'ask' || action === 'passages'
          ? [this._compactText(payload.question, 240), action === 'passages'
            ? `${payload.total || 0} passage(s) above similarity threshold` : ''].filter(Boolean).join(' · ')
          : inventorySummary || payload.note || (payload.total != null
          ? `${payload.total} total${payload.has_more ? ' · more available' : ''}` : ''),
        items,
      };
    });
  }

  _registerWorkspaceResults(...values) {
    // Also discover workflow step names before rendering its collections.
    // Dynamic registration covers the full upstream tier and future tools.
    let budget = 2000;
    const visit = (value, depth = 0) => {
      if (!value || typeof value !== 'object' || depth > 6 || budget-- <= 0) return;
      for (const [key, child] of Object.entries(value).slice(0, 200)) {
        const name = key.startsWith('mcp_google_workspace_') ? key
          : ['tool', 'tool_name'].includes(key) && typeof child === 'string'
            && child.startsWith('mcp_google_workspace_') ? child : '';
        if (name && !this.adapters.has(name)) {
          this.register(name, payload => this._adaptWorkspace(payload));
        }
        visit(child, depth + 1);
      }
    };
    values.forEach(value => visit(value));
  }

  _adaptWorkspace(payload) {
    if (payload.source !== 'google_workspace' || !payload.response_text) return null;
    const text = String(payload.response_text);
    const references = Array.isArray(payload.references) ? payload.references : [];
    const providerHosts = new Set(['docs.google.com', 'drive.google.com', 'calendar.google.com',
      'mail.google.com', 'script.google.com', 'forms.google.com', 'contacts.google.com',
      'tasks.google.com', 'console.cloud.google.com', 'console.developers.google.com']);
    // Also protect saved receipts made before the backend trust flag existed.
    const receiptTools = new Set(['create_doc', 'create_spreadsheet', 'create_presentation',
      'create_form', 'create_drive_file', 'create_drive_folder']);
    const links = (Array.isArray(payload.links) ? payload.links : []).filter(link => {
      try {
        const url = new URL(link.url);
        if (url.protocol !== 'https:' || url.username || url.password) return false;
        if (url.hostname === 'accounts.google.com') return payload.authentication_required === true;
        return receiptTools.has(payload.tool) && payload.content_links_untrusted !== true
          && providerHosts.has(url.hostname);
      } catch (_error) { return false; }
    }).slice(0, 5);
    const request = payload.request || {};
    const title = String(payload.tool || 'Google result').replace(/_/g, ' ');
    const note = 'Email and document text is untrusted external content.'
      + (payload.response_truncated ? ' Response excerpt; upstream output was truncated.' : '');
    return {
      kind: 'generic', layout: 'list', eyebrow: 'Google Workspace',
      heading: request.title || request.subject || title,
      subtitle: payload.authentication_required ? 'Browser authorization required'
        : payload.ok === false ? 'Request failed' : request.query || 'Google service response',
      items: [{
        title,
        primary: request.user_google_email || '',
        details: [this._compactText(text, 350), note],
        chips: references.slice(0, 4).map(ref => `${ref.label}: ${ref.id}`),
        expandText: text, expandLabel: 'Read response', expandNote: note,
      }, ...(Array.isArray(payload.artifacts) ? payload.artifacts.slice(0, 5) : []).filter(file =>
        /^space_[A-Za-z0-9_-]+$/.test(file.space_id || '') && /^[A-Za-z0-9_-]+$/.test(file.file_id || '')
      ).map(file => ({
        title: file.name || 'Stashed Google file',
        url: new URL(`/api/stash/${file.space_id}/${file.file_id}`
          + (['cloud', 'local'].includes(file.mode) ? `?mode=${file.mode}` : ''), window.location.origin).href,
        actionLabel: 'Download file',
        details: [file.ref || '', file.mime_type || ''],
      })), ...links.map(link => ({
        title: link.title || 'Google result', url: link.url, actionLabel: payload.authentication_required ? 'Authorize Google' : 'Open Google resource',
      }))],
    };
  }

  _bindScrollControls() {
    if (
      this._scrollControlsBound
      || typeof document === 'undefined'
      || typeof document.addEventListener !== 'function'
    ) return;

    this._scrollControlsBound = true;
    document.addEventListener('click', event => {
      const expandableCard = event.target?.closest?.('.structured-result-card-expandable');
      if (expandableCard && !event.target?.closest?.('a')) {
        this._openExpandedResult(expandableCard);
        return;
      }
      const button = event.target?.closest?.('.structured-results-scroll-button');
      if (!button || button.disabled) return;
      const section = button.closest('.structured-results-preview');
      const track = section?.querySelector('.structured-results-track');
      if (!track) return;
      const direction = button.dataset.direction === 'previous' ? -1 : 1;
      const distance = Math.max(track.clientWidth * 0.82, 240);
      track.scrollBy({left: direction * distance, behavior: 'smooth'});
      window.setTimeout?.(() => this._refreshScrollControls(track), 350);
    });
    document.addEventListener('scroll', event => {
      if (event.target?.classList?.contains('structured-results-track')) {
        this._refreshScrollControls(event.target);
      }
    }, true);
    window.addEventListener?.('resize', () => this._refreshAllScrollControls());
  }

  _ensureReaderDialog() {
    if (this._readerDialog?.isConnected) return this._readerDialog;
    if (typeof document === 'undefined' || !document.body) return null;
    const dialog = document.createElement('dialog');
    dialog.className = 'structured-result-reader';
    dialog.setAttribute('aria-labelledby', 'structuredResultReaderTitle');

    const header = document.createElement('div');
    header.className = 'structured-result-reader-header';
    const heading = document.createElement('div');
    const title = document.createElement('h2');
    title.id = 'structuredResultReaderTitle';
    title.className = 'structured-result-reader-title';
    title.dataset.readerTitle = '';
    const meta = document.createElement('div');
    meta.className = 'structured-result-reader-meta';
    meta.dataset.readerMeta = '';
    heading.append(title, meta);
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'structured-result-reader-close';
    close.setAttribute('aria-label', 'Close expanded result');
    close.textContent = '✕';
    close.addEventListener('click', () => dialog.close());
    header.append(heading, close);

    const body = document.createElement('div');
    body.className = 'structured-result-reader-body';
    const text = document.createElement('div');
    text.className = 'structured-result-reader-text';
    text.dataset.readerText = '';
    const note = document.createElement('p');
    note.className = 'structured-result-reader-note';
    note.dataset.readerNote = '';
    body.append(text, note);
    dialog.append(header, body);
    dialog.addEventListener('click', event => {
      if (event.target === dialog) dialog.close();
    });
    dialog.addEventListener('keydown', event => {
      if (event.key === 'Escape') event.stopPropagation();
    });
    dialog.addEventListener('close', () => {
      if (this._readerOpener?.isConnected) this._readerOpener.focus();
      this._readerOpener = null;
    });
    document.body.appendChild(dialog);
    this._readerDialog = dialog;
    return dialog;
  }

  _openExpandedResult(card) {
    const fullText = card?.querySelector?.('.structured-result-full-text')?.textContent;
    if (!fullText) return;
    const dialog = this._ensureReaderDialog();
    if (!dialog || typeof dialog.showModal !== 'function') return;
    dialog.querySelector('[data-reader-title]').textContent =
      card.querySelector('.structured-result-title')?.textContent || 'Full result';
    dialog.querySelector('[data-reader-meta]').textContent =
      [card.querySelector('.structured-result-primary')?.textContent, 'Plain text']
        .filter(Boolean).join(' · ');
    dialog.querySelector('[data-reader-text]').textContent = fullText;
    const note = dialog.querySelector('[data-reader-note]');
    note.textContent = card.querySelector('.structured-result-full-note')?.textContent || '';
    note.hidden = !note.textContent;
    this._readerOpener = card.querySelector('.structured-result-expand-button');
    if (!dialog.open) dialog.showModal();
  }

  _scheduleScrollControlsRefresh() {
    if (typeof document === 'undefined') return;
    const refresh = () => this._refreshAllScrollControls();
    if (typeof window.requestAnimationFrame === 'function') {
      window.requestAnimationFrame(refresh);
    } else {
      window.setTimeout?.(refresh, 0);
    }
  }

  _refreshAllScrollControls() {
    if (typeof document === 'undefined') return;
    document.querySelectorAll('.structured-results-track')
      .forEach(track => this._refreshScrollControls(track));
  }

  _refreshScrollControls(track) {
    const section = track?.closest?.('.structured-results-preview');
    const controls = section?.querySelector('.structured-results-scroll-controls');
    if (!controls) return;
    const maxScroll = Math.max(0, track.scrollWidth - track.clientWidth);
    controls.hidden = maxScroll <= 4;
    if (controls.hidden) return;
    const previous = controls.querySelector('[data-direction="previous"]');
    const next = controls.querySelector('[data-direction="next"]');
    if (previous) previous.disabled = track.scrollLeft <= 2;
    if (next) next.disabled = track.scrollLeft >= maxScroll - 2;
  }

  _latestPayload(raw) {
    if (!raw) return null;
    if (Array.isArray(raw)) {
      if (!raw.length) return null;
      const looksLikeRepeatedRuns = raw.some(item => item && typeof item === 'object' && (
        item.data || item.results || item.top_results || item.candidates
        || item.engine || item.provider || item.destination || item.find_loc
      ));
      if (!looksLikeRepeatedRuns) return { results: raw };
      raw = raw[raw.length - 1];
    }
    if (!raw || typeof raw !== 'object') return null;
    if (raw.data && typeof raw.data === 'object' && !Array.isArray(raw.data)) {
      raw = raw.data;
    }
    return raw;
  }

  _tmdbDisplayPayload(raw) {
    if (!Array.isArray(raw)) return this._latestPayload(raw);
    const looksLikeRepeatedRuns = raw.some(item => item && typeof item === 'object' && (
      item.data || item.action || item.results || item.top_results
    ));
    if (!looksLikeRepeatedRuns) return this._latestPayload(raw);
    const payloads = raw
      .map(item => this._latestPayload(item))
      .filter(item => item && typeof item === 'object');
    if (!payloads.length) return null;

    // A complete mixed artwork call is more representative than a provider's
    // redundant poster/backdrop/logo drill-down that follows it.
    const mixedArtwork = [...payloads].reverse().find(item => (
      item.action === 'images' && item.image_type === 'all'
    ));
    return mixedArtwork || payloads[payloads.length - 1];
  }

  _rows(payload) {
    for (const key of ['top_results', 'results', 'candidates', 'items']) {
      if (Array.isArray(payload?.[key]) && payload[key].length) {
        return payload[key].filter(item => item && typeof item === 'object').slice(0, 5);
      }
    }
    return [];
  }

  _list(value) {
    if (Array.isArray(value)) return value.filter(Boolean).map(item => String(item));
    if (value == null || value === '') return [];
    return [String(value)];
  }

  _formatPrice(value, currency = 'USD') {
    if (value == null || value === '') return '';
    if (typeof value === 'string' && /[^0-9.,]/.test(value)) return value;
    const amount = String(value);
    return String(currency || 'USD').toUpperCase() === 'USD'
      ? `$${amount}`
      : `${String(currency).toUpperCase()} ${amount}`;
  }

  _formatMarketplacePrice(value) {
    if (value == null || value === '') return '';
    if (typeof value !== 'object') return String(value);
    if (value.raw) return String(value.raw);
    const from = value.from?.raw || value.from?.formatted;
    const to = value.to?.raw || value.to?.formatted;
    if (from) return to ? `${from} – ${to}` : String(from);
    if (value.amount != null) {
      return value.currency ? `${value.currency} ${value.amount}` : String(value.amount);
    }
    return '';
  }

  _formatCount(value) {
    if (value == null || value === '') return '';
    const number = Number(value);
    return Number.isFinite(number) ? number.toLocaleString('en-US') : String(value);
  }

  _formatDateTime(value) {
    const text = String(value || '').trim();
    if (!text) return '';
    const date = new Date(text);
    if (Number.isNaN(date.getTime())) return text;
    try {
      return new Intl.DateTimeFormat(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        timeZoneName: 'short',
      }).format(date);
    } catch (_error) {
      return text;
    }
  }

  _compactText(value, maxLength = 150) {
    const text = String(value || '').replace(/\s+/g, ' ').trim();
    if (text.length <= maxLength) return text;
    return `${text.slice(0, Math.max(1, maxLength - 1)).trimEnd()}…`;
  }

  _displayText(value) {
    if (value == null || value === '') return '';
    if (Array.isArray(value)) return value.filter(Boolean).map(item => String(item)).join(' · ');
    if (typeof value !== 'object') return String(value);
    for (const key of ['raw', 'formatted', 'text', 'label', 'name', 'username', 'status', 'message']) {
      if (value[key] != null && value[key] !== '') return String(value[key]);
    }
    return Object.values(value)
      .filter(item => ['string', 'number', 'boolean'].includes(typeof item) && item !== '')
      .slice(0, 3)
      .map(item => String(item))
      .join(' · ');
  }

  _formatFlightTime(value) {
    const text = String(value || '').trim();
    const match = text.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/);
    if (!match) return text;
    const [, year, month, day, rawHour, minute] = match;
    const hour = Number(rawHour);
    const clockHour = hour % 12 || 12;
    const meridiem = hour >= 12 ? 'PM' : 'AM';
    return `${month}/${day}/${year} · ${clockHour}:${minute} ${meridiem}`;
  }

  _adaptTraktMovies(payload, mediaType = 'movie') {
    const isShow = mediaType === 'show';
    const items = this._rows(payload).map((row, index) => {
      const chips = [];
      if (row.year) chips.push(String(row.year));
      const runtime = isShow ? row.episode_runtime_minutes : row.runtime_minutes;
      if (runtime) chips.push(`${runtime} min${isShow ? '/episode' : ''}`);
      if (row.certification) chips.push(String(row.certification));
      if (isShow && row.network) chips.push(String(row.network));
      if (isShow && row.status) chips.push(String(row.status));
      const signals = this._list(row.source_signals)
        .slice(0, 3)
        .map(signal => String(signal).replace(/^related:/, 'Like '));
      chips.push(...signals);
      const genres = this._list(row.genres).slice(0, 4).join(' · ');
      const details = [];
      if (genres) details.push(genres);
      if (row.overview) details.push(this._compactText(row.overview, 260));
      if (row.trailer_url) details.push('Trailer available');
      const rating = row.rating != null ? Number(row.rating) : null;
      const primary = Number.isFinite(rating)
        ? `★ ${rating.toFixed(1)}${row.votes ? ` · ${this._formatCount(row.votes)} votes` : ''}`
        : '';
      return {
        title: row.title || `${isShow ? 'Show' : 'Movie'} ${index + 1}`,
        url: row.trakt_url || row.imdb_url || row.trailer_url,
        primary,
        chips,
        details,
        actionLabel: row.trakt_url ? 'Open on Trakt' : `Open ${isShow ? 'show' : 'movie'}`,
      };
    });
    const action = String(payload.action || 'recommend').replace(/_/g, ' ');
    const references = (Array.isArray(payload.resolved_references) ? payload.resolved_references : [])
      .map(item => item && typeof item === 'object' ? item.title : item)
      .filter(Boolean)
      .slice(0, 3)
      .join(', ');
    const subtitle = [
      action,
      references ? `Inspired by ${references}` : '',
      payload.streaming_provider_data === 'not returned' ? 'Provider availability not included' : '',
    ].filter(Boolean).join(' · ');
    return {
      kind: 'generic',
      layout: 'rail',
      eyebrow: isShow ? 'Trakt TV shows' : 'Trakt movies',
      heading: payload.request || payload.query || (isShow ? 'TV-show ideas' : 'Movie ideas'),
      subtitle,
      actionUrl: payload.top_url,
      actionLabel: `Open top ${isShow ? 'show' : 'movie'}`,
      items,
    };
  }

  _adaptTraktAccount(payload) {
    const rows = this._rows(payload);
    if (payload.action === 'status') {
      const user = payload.user && typeof payload.user === 'object' ? payload.user : {};
      const chips = ['Read only'];
      if (user.vip === true) chips.push('VIP');
      if (user.private === true) chips.push('Private profile');
      return {
        kind: 'generic',
        layout: 'rail',
        eyebrow: 'Trakt account · read only',
        heading: user.username ? `@${user.username}` : 'Trakt authorization',
        subtitle: payload.authorized ? 'OAuth active' : 'Authorization status',
        items: [{
          title: payload.authorized ? 'Account connected' : 'Account status',
          primary: user.joined_at ? `Joined ${user.joined_at}` : '',
          chips,
          details: [user.location, user.about].filter(Boolean),
        }],
      };
    }
    if (['personal_lists', 'smart_lists'].includes(payload.action)) {
      return {
        kind: 'generic',
        layout: 'rail',
        eyebrow: 'Trakt account · read only',
        heading: payload.action === 'smart_lists' ? 'Smart lists' : 'Personal lists',
        subtitle: `${rows.length} list${rows.length === 1 ? '' : 's'} · OAuth`,
        items: rows.map((row, index) => ({
          title: row.name || `List ${index + 1}`,
          url: row.share_link || row.trakt_url,
          primary: row.item_count != null ? `${row.item_count} items` : '',
          chips: [row.privacy, row.sort_by].filter(Boolean),
          details: row.description ? [this._compactText(row.description, 260)] : [],
          actionLabel: row.share_link || row.trakt_url ? 'Open list' : '',
        })),
      };
    }
    const firstType = rows.find(row => row && row.media_type)?.media_type;
    const mediaType = firstType === 'show' || payload.action === 'show_recommendations'
      || payload.action === 'tv_night_context' ? 'show' : 'movie';
    const adapted = this._adaptTraktMovies(payload, mediaType);
    adapted.eyebrow = 'Trakt account · read only';
    const accountLabel = payload.user?.username ? `@${payload.user.username}` : '';
    adapted.subtitle = [accountLabel, String(payload.action || 'account').replace(/_/g, ' '), 'OAuth']
      .filter(Boolean).join(' · ');
    adapted.items.forEach((item, index) => {
      const row = rows[index] || {};
      if (row.user_rating != null) item.chips.push(`Your rating ${row.user_rating}/10`);
      if (row.progress != null) item.chips.push(`${row.progress}% progress`);
      if (row.watched_at) item.details.push(`Watched ${row.watched_at}`);
      if (row.listed_at) item.details.push(`Added ${row.listed_at}`);
    });
    return adapted;
  }

  _adaptTmdbMovies(payload, mediaType = 'movie') {
    const isShow = mediaType === 'show';
    const action = String(payload.action || 'search').replace(/_/g, ' ');
    const media = payload[isShow ? 'show' : 'movie'];
    const movie = media && typeof media === 'object' ? media : null;
    const mediaLabel = isShow ? 'TV show' : 'Movie';
    const attribution = payload.attribution_notice
      || 'This product uses the TMDB API but is not endorsed or certified by TMDB.';

    if (payload.action === 'images') {
      const items = this._rows(payload).map((row, index) => {
        const width = Number(row.width);
        const height = Number(row.height);
        const dimensions = Number.isFinite(width) && width > 0
          && Number.isFinite(height) && height > 0
          ? `${width} × ${height}`
          : '';
        return {
          title: row.title || `${movie?.title || mediaLabel} artwork ${index + 1}`,
          url: row.source_url || movie?.tmdb_url || payload.top_url,
          image: index === 0
            ? (row.image_url || row.thumbnail)
            : (row.thumbnail || row.image_url),
          imageUrl: row.original_url || row.image_url,
          imageVariant: row.image_type,
          featured: index === 0,
          primary: row.image_type ? String(row.image_type) : '',
          chips: [dimensions, row.language || 'No language', row.rating != null ? `★ ${row.rating}` : '']
            .filter(Boolean),
          actionLabel: 'Open on TMDB',
        };
      });
      return {
        kind: 'image',
        layout: 'gallery',
        eyebrow: `TMDB ${isShow ? 'TV' : 'movie'} artwork · External content`,
        heading: movie?.title || payload.query || `${mediaLabel} artwork`,
        subtitle: [
          `${payload.results_count ?? items.length} image${Number(payload.results_count ?? items.length) === 1 ? '' : 's'}`,
          payload.image_type && payload.image_type !== 'all' ? payload.image_type : '',
          attribution,
        ].filter(Boolean).join(' · '),
        actionUrl: movie?.tmdb_url || payload.top_url || payload.attribution_url,
        actionLabel: 'Open on TMDB',
        items,
      };
    }

    if (payload.action === 'credits') {
      const items = this._rows(payload).map((row, index) => ({
        title: row.name || `Cast member ${index + 1}`,
        url: row.tmdb_url,
        image: row.profile_thumbnail || row.profile_url,
        imageUrl: row.profile_url,
        primary: row.character ? `as ${row.character}` : '',
        chips: [row.known_for_department].filter(Boolean),
        actionLabel: 'Open person',
      }));
      return {
        kind: 'generic',
        layout: 'rail',
        eyebrow: 'TMDB cast and crew',
        heading: movie?.title || payload.query || `${mediaLabel} credits`,
        subtitle: attribution,
        actionUrl: movie?.tmdb_url || payload.top_url || payload.attribution_url,
        actionLabel: 'Open on TMDB',
        items,
      };
    }

    if (payload.action === 'videos') {
      const items = this._rows(payload).map((row, index) => ({
        title: row.title || `${movie?.title || mediaLabel} video ${index + 1}`,
        url: row.url,
        primary: row.site || '',
        chips: [row.type, row.official === true ? 'Official' : '', row.published_at]
          .filter(Boolean),
        actionLabel: 'Watch video',
      }));
      return {
        kind: 'video',
        layout: 'rail',
        eyebrow: `TMDB ${isShow ? 'TV' : 'movie'} videos`,
        heading: movie?.title || payload.query || `${mediaLabel} videos`,
        subtitle: attribution,
        actionUrl: movie?.tmdb_url || payload.top_url || payload.attribution_url,
        actionLabel: 'Open on TMDB',
        items,
      };
    }

    const items = this._rows(payload).map((row, index) => {
      const rating = row.rating != null ? Number(row.rating) : null;
      return {
        title: row.title || `${mediaLabel} ${index + 1}`,
        url: row.tmdb_url || row.imdb_url,
        image: row.poster_thumbnail || row.poster_url,
        imageUrl: row.poster_original_url || row.backdrop_original_url || row.poster_url,
        primary: Number.isFinite(rating)
          ? `★ ${rating.toFixed(1)}${row.votes ? ` · ${this._formatCount(row.votes)} votes` : ''}`
          : '',
        chips: [
          row.year,
          (isShow ? row.episode_runtime_minutes : row.runtime_minutes)
            ? `${isShow ? row.episode_runtime_minutes : row.runtime_minutes} min${isShow ? '/episode' : ''}`
            : '',
          isShow ? row.content_rating : row.certification,
          isShow && row.number_of_seasons ? `${row.number_of_seasons} season${Number(row.number_of_seasons) === 1 ? '' : 's'}` : '',
          isShow ? row.status : '',
          row.source_signal ? String(row.source_signal).replace(/_/g, ' ') : '',
        ].filter(Boolean).map(String),
        details: [
          this._list(row.genres).slice(0, 4).join(' · '),
          isShow ? this._list(row.networks).slice(0, 3).join(' · ') : '',
          row.overview ? this._compactText(row.overview, 260) : '',
        ].filter(Boolean),
        actionLabel: 'Open on TMDB',
      };
    });
    return {
      kind: 'generic',
      layout: 'rail',
      eyebrow: `TMDB ${isShow ? 'TV shows' : 'movies'} · External content`,
      heading: movie?.title || payload.query || `${action.charAt(0).toUpperCase()}${action.slice(1)} ${isShow ? 'TV shows' : 'movies'}`,
      subtitle: [
        `${payload.results_count ?? items.length} result${Number(payload.results_count ?? items.length) === 1 ? '' : 's'}`,
        attribution,
      ].filter(Boolean).join(' · '),
      actionUrl: payload.top_url || movie?.tmdb_url || payload.attribution_url,
      actionLabel: 'Open on TMDB',
      items,
    };
  }

  _adaptYouTubeSearch(payload) {
    const items = this._rows(payload).filter(row => row?.title && (row?.url || row?.video_id)).map(row => {
      const chips = [];
      if (row.channel) chips.push(String(row.channel));
      const views = this._formatCount(row.views ?? row.extracted_views);
      if (views) chips.push(String(views).toLowerCase().includes('view') ? String(views) : `${views} views`);
      if (row.published_date) chips.push(String(row.published_date));
      if (row.live === true) chips.push('Live');
      return {
        title: row.title,
        url: row.url || `https://www.youtube.com/watch?v=${encodeURIComponent(row.video_id)}`,
        image: row.thumbnail,
        primary: row.duration || (row.live === true ? 'Live' : ''),
        chips,
        details: row.description ? [this._compactText(row.description)] : [],
        actionLabel: 'Watch on YouTube',
      };
    });
    return {
      kind: 'video',
      layout: 'rail',
      eyebrow: 'YouTube',
      heading: payload.search_query || 'Video results',
      subtitle: payload.ranking_mode === 'views_desc' ? 'Sorted by views' : '',
      items,
    };
  }

  _adaptWeather(payload) {
    const forecast = Array.isArray(payload.daily_forecast) && payload.daily_forecast.length
      ? payload.daily_forecast
      : (Array.isArray(payload.forecast) ? payload.forecast : []);
    const degree = value => value != null && value !== '' ? `${value}°` : '';
    let items = forecast.slice(0, 10).map((row, index) => {
      const title = row.day
        ? [row.day, row.date].filter(Boolean).join(' · ')
        : (row.date || row.time || `Forecast ${index + 1}`);
      const highLow = row.high != null || row.low != null
        ? [degree(row.high), degree(row.low)].filter(Boolean).join(' / ')
        : degree(row.temp);
      const chips = [];
      if (row.precip_probability != null) chips.push(`${row.precip_probability}% precipitation`);
      if (row.humidity != null) chips.push(`${row.humidity}% humidity`);
      if (row.wind_max != null) chips.push(`Wind ${row.wind_max} mph`);
      return {
        title,
        primary: highLow,
        chips,
        details: row.condition ? [row.condition] : [],
      };
    });
    if (!items.length && payload.temperature != null) {
      items = [{
        title: 'Current conditions',
        primary: degree(payload.temperature),
        chips: [
          payload.feels_like != null ? `Feels like ${degree(payload.feels_like)}` : '',
          payload.humidity != null ? `${payload.humidity}% humidity` : '',
          payload.wind_speed != null ? `Wind ${payload.wind_speed} ${payload.wind_unit || 'mph'}` : '',
        ].filter(Boolean),
        details: payload.condition ? [payload.condition] : [],
      }];
    }
    const current = [];
    if (payload.temperature != null) current.push(`Currently ${degree(payload.temperature)}`);
    if (payload.condition) current.push(String(payload.condition));
    if (payload.feels_like != null && payload.feels_like !== payload.temperature) {
      current.push(`Feels like ${degree(payload.feels_like)}`);
    }
    return {
      kind: 'weather',
      layout: 'metrics',
      eyebrow: 'Weather',
      heading: payload.location || 'Forecast',
      subtitle: current.join(' · '),
      items,
    };
  }

  _adaptExternalNetworkIntel(payload) {
    const summary = payload.summary && typeof payload.summary === 'object'
      ? payload.summary
      : {};
    const registration = payload.registration && typeof payload.registration === 'object'
      ? payload.registration
      : {};
    const routing = payload.routing && typeof payload.routing === 'object'
      ? payload.routing
      : {};
    const dns = payload.dns && typeof payload.dns === 'object'
      ? payload.dns
      : {};
    const providerRange = payload.published_provider_range
      && typeof payload.published_provider_range === 'object'
      ? payload.published_provider_range
      : {};
    const reputation = payload.reputation && typeof payload.reputation === 'object'
      ? payload.reputation
      : {};
    const abuse = reputation.abuseipdb && typeof reputation.abuseipdb === 'object'
      ? reputation.abuseipdb
      : {};
    const shodan = reputation.shodan_internetdb
      && typeof reputation.shodan_internetdb === 'object'
      ? reputation.shodan_internetdb
      : {};
    const asns = this._list(summary.announcing_asns || routing.asns);
    const services = this._list(summary.service_candidates);
    const ptr = this._list(dns.ptr);
    const resolvedIps = this._list(dns.resolved_ips);
    const dnsRecordDetails = Object.entries(
      dns.records && typeof dns.records === 'object' ? dns.records : {}
    ).flatMap(([recordType, record]) => (
      Array.isArray(record?.answers) ? record.answers : []
    ).slice(0, 4).map(answer => (
      answer?.data ? `${recordType} ${answer.data}` : ''
    ))).filter(Boolean).slice(0, 8);
    const hostnames = this._list(shodan.hostnames);
    const ports = this._list(shodan.ports);
    const tags = this._list(shodan.tags);
    const vulnerabilities = this._list(shodan.vulnerabilities);
    const items = [];

    if (summary.owner || summary.registered_network || registration.name || registration.ldh_name) {
      items.push({
        title: 'Ownership',
        primary: summary.owner || registration.name || registration.ldh_name || '',
        chips: [summary.registered_network || registration.name, registration.country].filter(Boolean),
        details: [
          registration.start_address && registration.end_address
            ? `${registration.start_address} – ${registration.end_address}`
            : '',
          this._list(registration.nameservers).slice(0, 5).join(' · '),
        ].filter(Boolean),
      });
    }
    if (asns.length || summary.routed_prefix || providerRange.prefix) {
      items.push({
        title: 'Routing',
        primary: asns.length ? asns.map(asn => `AS${asn}`).join(', ') : '',
        chips: [summary.routed_prefix || routing.prefix, providerRange.provider].filter(Boolean),
        details: [
          providerRange.prefix ? `Published range ${providerRange.prefix}` : '',
          [providerRange.service, providerRange.scope].filter(Boolean).join(' · '),
        ].filter(Boolean),
      });
    }
    if (
      services.length || ptr.length || resolvedIps.length || dnsRecordDetails.length
      || hostnames.length || ports.length
    ) {
      items.push({
        title: 'DNS and service associations',
        primary: services[0] || ptr[0] || hostnames[0] || resolvedIps[0] || '',
        chips: ports.slice(0, 8).map(port => `Port ${port}`),
        details: [
          services.slice(1, 5).join(' · '),
          hostnames.filter(host => !services.includes(host)).slice(0, 5).join(' · '),
          dnsRecordDetails.join(' · '),
        ].filter(Boolean),
      });
    }
    if (abuse.status || tags.length || vulnerabilities.length) {
      const score = abuse.abuse_confidence_score;
      items.push({
        title: 'Reputation',
        primary: score != null ? `${score}% AbuseIPDB confidence` : (abuse.status || ''),
        chips: [
          abuse.total_reports != null ? `${abuse.total_reports} reports` : '',
          ...tags.slice(0, 4),
        ].filter(Boolean),
        details: [
          abuse.last_reported_at ? `Last reported ${this._formatDateTime(abuse.last_reported_at)}` : '',
          vulnerabilities.length ? `${vulnerabilities.length} vulnerabilities in passive snapshot` : '',
        ].filter(Boolean),
      });
    }
    if (!items.length && payload.classification && typeof payload.classification === 'object') {
      const classification = payload.classification;
      items.push({
        title: 'Address classification',
        primary: `${classification.is_global ? 'Global' : 'Non-global'} IPv${classification.version || ''}`,
        chips: [
          classification.is_private ? 'Private' : '',
          classification.is_reserved ? 'Reserved' : '',
          classification.is_loopback ? 'Loopback' : '',
          classification.is_link_local ? 'Link local' : '',
        ].filter(Boolean),
        details: payload.external_lookup_skipped ? [payload.external_lookup_skipped] : [],
      });
    }
    const lookupErrors = Array.isArray(payload.errors)
      ? payload.errors.filter(error => error && typeof error === 'object')
      : [];
    if (!items.length && lookupErrors.length) {
      items.push({
        title: 'Lookup status',
        primary: payload.result_status || 'partial',
        details: lookupErrors.slice(0, 4).map(error => (
          [error?.source, error?.error].filter(Boolean).join(': ')
        )).filter(Boolean),
      });
    }

    return {
      kind: 'generic',
      layout: 'metrics',
      eyebrow: 'Passive network intelligence',
      heading: payload.target || 'Network lookup',
      subtitle: [
        payload.target_type,
        payload.query_type,
        payload.result_status,
        payload.checked_at ? this._formatDateTime(payload.checked_at) : '',
      ].filter(Boolean).join(' · '),
      items,
    };
  }

  _adaptGpuHotStatus(payload) {
    const gpus = Array.isArray(payload.gpus) ? payload.gpus : [];
    const processes = Array.isArray(payload.processes) ? payload.processes : [];
    const formatNumber = value => {
      const number = Number(value);
      return Number.isFinite(number) ? number.toLocaleString(undefined, {maximumFractionDigits: 1}) : '';
    };
    const items = gpus.map((gpu, index) => {
      const gpuIndex = String(gpu.index ?? index);
      const gpuProcesses = processes.filter(process => String(process.gpu_index ?? '') === gpuIndex);
      const chips = [];
      if (gpu.utilization_percent != null) chips.push(`${formatNumber(gpu.utilization_percent)}% utilized`);
      if (gpu.vram_capacity_percent != null) chips.push(`${formatNumber(gpu.vram_capacity_percent)}% VRAM`);
      if (gpu.power_draw_w != null) chips.push(`${formatNumber(gpu.power_draw_w)} W`);
      const details = [];
      if (gpu.vram_used_mib != null && gpu.vram_total_mib != null) {
        details.push(`${formatNumber(Number(gpu.vram_used_mib) / 1024)} / ${formatNumber(Number(gpu.vram_total_mib) / 1024)} GiB allocated`);
      }
      if (gpuProcesses.length) {
        details.push(gpuProcesses.slice(0, 4).map(process => {
          const memory = process.vram_mib != null ? ` ${formatNumber(process.vram_mib)} MiB` : '';
          return `${process.name || 'process'}${memory}`;
        }).join(' · '));
      }
      return {
        title: gpu.name || `GPU ${gpuIndex}`,
        primary: gpu.temperature_c != null ? `${formatNumber(gpu.temperature_c)} °C` : '',
        chips,
        details,
      };
    });
    const system = payload.system && typeof payload.system === 'object' ? payload.system : {};
    const subtitle = [
      system.cpu_percent != null ? `Host CPU ${formatNumber(system.cpu_percent)}%` : '',
      system.ram_percent != null ? `RAM ${formatNumber(system.ram_percent)}%` : '',
      payload.transport ? String(payload.transport) : '',
    ].filter(Boolean).join(' · ');
    return {
      kind: 'generic',
      layout: 'metrics',
      eyebrow: 'GPU Hot',
      heading: payload.host_label || payload.node_name || 'GPU host',
      subtitle,
      actionUrl: payload.dashboard_url,
      actionLabel: 'Open dashboard',
      items,
    };
  }

  _safeUrl(value) {
    if (!value) return '';
    try {
      return Utils.safeHttpUrlForAttr(value) || '';
    } catch (_error) {
      return '';
    }
  }

  _escape(value) {
    return Utils.escapeHtml(String(value ?? ''));
  }

  _renderCollection(collection, options = {}) {
    const kind = ['product', 'hotel', 'local', 'flight', 'video', 'weather', 'image', 'sport'].includes(collection.kind)
      ? collection.kind
      : 'generic';
    const layout = ['rail', 'list', 'metrics', 'gallery'].includes(collection.layout)
      ? collection.layout
      : 'rail';
    const embedded = options.embedded === true;
    const single = collection.items.length === 1;
    const cards = collection.items.map(item => {
      const url = this._safeUrl(item.url);
      const image = this._safeUrl(item.image);
      const imageUrl = this._safeUrl(item.imageUrl);
      const title = this._escape(item.title || 'Result');
      const titleHtml = url
        ? `<a class="structured-result-title" href="${url}" target="_blank" rel="noopener noreferrer" title="${title}">${title}</a>`
        : `<div class="structured-result-title" title="${title}">${title}</div>`;
      const chips = this._list(item.chips)
        .map(chip => `<span class="structured-result-chip">${this._escape(chip)}</span>`)
        .join('');
      const details = this._list(item.details)
        .map(detail => `<div class="structured-result-detail">${this._escape(detail)}</div>`)
        .join('');
      const action = url
        ? `<a class="structured-result-link" href="${url}" target="_blank" rel="noopener noreferrer">${this._escape(item.actionLabel || 'Open')}</a>`
        : '';
      const expandable = typeof item.expandText === 'string' && item.expandText.trim();
      const expand = expandable ? `
        <button class="structured-result-expand-button" type="button" aria-haspopup="dialog">${this._escape(item.expandLabel || 'Read full result')}</button>
        <div class="structured-result-full-text" hidden>${this._escape(item.expandText)}</div>
        <div class="structured-result-full-note" hidden>${this._escape(item.expandNote || '')}</div>
      ` : '';
      const imageVariant = ['poster', 'backdrop', 'logo'].includes(item.imageVariant)
        ? ` structured-result-image-${item.imageVariant}`
        : '';
      const featured = item.featured === true ? ' structured-result-card-featured' : '';
      return `
        <article class="structured-result-card structured-result-card-${kind}${imageVariant}${featured}${expandable ? ' structured-result-card-expandable' : ''}">
          ${image ? `<a class="structured-result-image" href="${imageUrl || url || image}" target="_blank" rel="noopener noreferrer"><img src="${image}" alt="${title}" loading="lazy" referrerpolicy="no-referrer"></a>` : ''}
          <div class="structured-result-body">
            ${titleHtml}
            ${item.primary ? `<div class="structured-result-primary">${this._escape(item.primary)}</div>` : ''}
            ${chips ? `<div class="structured-result-chips">${chips}</div>` : ''}
            ${details ? `<div class="structured-result-details">${details}</div>` : ''}
            ${expand}
            ${action}
          </div>
        </article>
      `;
    }).join('');
    const actionUrl = this._safeUrl(collection.actionUrl);
    const collectionAction = actionUrl
      ? `<a class="structured-results-action" href="${actionUrl}" target="_blank" rel="noopener noreferrer">${this._escape(collection.actionLabel || 'Open results')}</a>`
      : '';
    const scrollControls = layout === 'rail' && !single
      ? `
        <div class="structured-results-scroll-controls" role="group" aria-label="Scroll results" hidden>
          <button class="structured-results-scroll-button" type="button" data-direction="previous" aria-label="Previous results" title="Previous results">&#8249;</button>
          <button class="structured-results-scroll-button" type="button" data-direction="next" aria-label="Next results" title="Next results">&#8250;</button>
        </div>
      `
      : '';
    const orchestration = embedded && options.surface === 'orchestration';
    const surfaceTool = embedded && options.toolName
      ? ` data-${orchestration ? 'orchestration' : 'workflow'}-tool="${this._escape(options.toolName)}"`
      : '';
    const surfacePosition = embedded && (orchestration ? options.call : options.step) != null
      ? ` data-${orchestration ? 'orchestration-call' : 'workflow-step'}="${this._escape(orchestration ? options.call : options.step)}"`
      : '';
    const occurrence = orchestration && options.occurrence != null
      ? ` data-orchestration-occurrence="${this._escape(options.occurrence)}"`
      : '';
    const embeddedClass = embedded
      ? ` structured-results-workflow-section${orchestration ? ' structured-results-orchestration-section' : ''}`
      : '';
    const singleClass = single ? ' structured-results-single' : '';
    return `
      <section class="structured-results-preview structured-results-${kind} structured-results-layout-${layout}${embeddedClass}${singleClass}"${surfaceTool}${surfacePosition}${occurrence} aria-label="${this._escape(collection.eyebrow || 'Structured results')}">
        <div class="structured-results-header">
          <div>
            <div class="structured-results-eyebrow">${this._escape(collection.eyebrow || 'Results')}</div>
            <div class="structured-results-heading">${this._escape(collection.heading || 'Options')}</div>
            ${collection.subtitle ? `<div class="structured-results-subtitle">${this._escape(collection.subtitle)}</div>` : ''}
          </div>
          <div class="structured-results-header-meta">
            <div class="structured-results-meta-row">
              <span>${collection.items.length} shown</span>
              ${scrollControls}
            </div>
            ${collectionAction}
          </div>
        </div>
        <div class="structured-results-track">${cards}</div>
      </section>
    `;
  }
}

window.StructuredResultsRenderer = StructuredResultsRenderer;
window.structuredResultsRenderer = new StructuredResultsRenderer();

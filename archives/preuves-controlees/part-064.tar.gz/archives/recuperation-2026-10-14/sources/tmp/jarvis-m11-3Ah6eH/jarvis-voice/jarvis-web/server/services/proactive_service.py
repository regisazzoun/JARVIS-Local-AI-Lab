"""
Proactive Notification Service
Polls jarvis-api for alerts and reminders, broadcasts to connected web clients.
"""

import time
from dataclasses import dataclass, field
from typing import Callable, Optional

import requests
from internal_api import get_internal_api_base_url, get_internal_api_headers

# Polling interval in seconds
POLL_INTERVAL = 10


@dataclass
class ProactiveService:
    """Service to poll jarvis-api and track notification state"""
    
    # Track which items we've already notified about
    notified_alerts: set[int] = field(default_factory=set)
    notified_reminders: set[int] = field(default_factory=set)
    
    # Last check timestamps
    last_alert_check: float = 0
    last_reminder_check: float = 0
    
    # Callback for broadcasting
    broadcast_callback: Optional[Callable] = None
    
    def set_broadcast_callback(self, callback: Callable):
        """Set the callback used to broadcast to WebSocket clients"""
        self.broadcast_callback = callback
    
    def check_alerts(self) -> list[dict]:
        """Check for new pending alerts"""
        try:
            response = requests.get(
                f"{get_internal_api_base_url()}/api/alerts",
                params={"status": "pending"},
                headers=get_internal_api_headers(),
                timeout=5
            )
            
            if response.status_code == 200:
                data = response.json()
                alerts = data.get('alerts', [])
                
                # Find new alerts we haven't notified about
                new_alerts = []
                for alert in alerts:
                    alert_id = alert.get('id')
                    if alert_id and alert_id not in self.notified_alerts:
                        new_alerts.append(alert)
                        self.notified_alerts.add(alert_id)
                
                return new_alerts
            
        except requests.RequestException:
            # API not running is expected sometimes
            pass
        except Exception as e:
            print(f"[Proactive] Error checking alerts: {e}")
        
        return []
    
    def check_reminders(self) -> list[dict]:
        """Check for triggered reminders"""
        try:
            response = requests.get(
                f"{get_internal_api_base_url()}/api/reminders",
                params={"status": "triggered"},
                headers=get_internal_api_headers(),
                timeout=5
            )
            
            if response.status_code == 200:
                data = response.json()
                reminders = data.get('reminders', [])
                
                # Find new reminders we haven't notified about
                new_reminders = []
                for reminder in reminders:
                    reminder_id = reminder.get('id')
                    if reminder_id and reminder_id not in self.notified_reminders:
                        new_reminders.append(reminder)
                        self.notified_reminders.add(reminder_id)
                
                return new_reminders
            
        except requests.RequestException:
            # API not running is expected sometimes
            pass
        except Exception as e:
            print(f"[Proactive] Error checking reminders: {e}")
        
        return []
    
    def acknowledge_alert(self, alert_id: int) -> bool:
        """Acknowledge an alert via jarvis-api"""
        try:
            response = requests.put(
                f"{get_internal_api_base_url()}/api/alerts/{alert_id}/acknowledge",
                headers=get_internal_api_headers(),
                timeout=5
            )
            if response.status_code == 200:
                # Remove from notified set so we don't re-notify
                self.notified_alerts.discard(alert_id)
                return True
        except Exception as e:
            print(f"[Proactive] Error acknowledging alert {alert_id}: {e}")
        return False
    
    def acknowledge_reminder(self, reminder_id: int) -> bool:
        """Acknowledge a reminder via jarvis-api"""
        try:
            response = requests.post(
                f"{get_internal_api_base_url()}/api/reminders/{reminder_id}/acknowledge",
                headers=get_internal_api_headers(),
                timeout=5
            )
            if response.status_code == 200:
                self.notified_reminders.discard(reminder_id)
                return True
        except Exception as e:
            print(f"[Proactive] Error acknowledging reminder {reminder_id}: {e}")
        return False
    
    def get_pending_snapshot(self) -> dict:
        """Get the current items for the Web panel independently of notification history."""
        alerts = []
        reminders = []
        
        try:
            # Alerts
            response = requests.get(
                f"{get_internal_api_base_url()}/api/alerts",
                params={"status": "pending"},
                headers=get_internal_api_headers(),
                timeout=3
            )
            if response.status_code == 200:
                items = response.json().get('alerts', [])
                alerts = items if isinstance(items, list) else []
        except Exception:
            pass
        
        try:
            # Reminders
            response = requests.get(
                f"{get_internal_api_base_url()}/api/reminders",
                params={"status": "triggered"},
                headers=get_internal_api_headers(),
                timeout=3
            )
            if response.status_code == 200:
                items = response.json().get('reminders', [])
                reminders = items if isinstance(items, list) else []
        except Exception:
            pass
        
        return {
            'alerts': alerts,
            'reminders': reminders,
            'counts': {'alerts': len(alerts), 'reminders': len(reminders)}
        }

    def get_pending_counts(self) -> dict:
        """Get counts of pending alerts/reminders."""
        return self.get_pending_snapshot()['counts']
    
    def poll_and_notify(self) -> dict:
        """
        Main polling function - check for new alerts/reminders and broadcast.
        Returns dict with new items found.
        """
        result = {
            'new_alerts': [],
            'new_reminders': [],
            'counts': {'alerts': 0, 'reminders': 0},
            'snapshot': {'alerts': [], 'reminders': []},
        }
        
        # Check alerts
        new_alerts = self.check_alerts()
        if new_alerts:
            result['new_alerts'] = new_alerts
            print(f"[Proactive] Found {len(new_alerts)} new alert(s)")
        
        # Check reminders
        new_reminders = self.check_reminders()
        if new_reminders:
            result['new_reminders'] = new_reminders
            print(f"[Proactive] Found {len(new_reminders)} new reminder(s)")
        
        # Restore pending items in Web, including items already notified
        # to a previous page load. Only new_* items trigger OS notifications.
        snapshot = self.get_pending_snapshot()
        result['snapshot'] = snapshot
        result['counts'] = snapshot['counts']
        
        # Broadcast if we have new items and callback is set
        if self.broadcast_callback and (new_alerts or new_reminders):
            for alert in new_alerts:
                self.broadcast_callback('proactive:alert', {
                    'type': 'alert',
                    'alert': alert,
                    'timestamp': time.time()
                })
            
            for reminder in new_reminders:
                self.broadcast_callback('proactive:reminder', {
                    'type': 'reminder',
                    'reminder': reminder,
                    'timestamp': time.time()
                })
        
        return result
    
    def clear_notification_cache(self):
        """Clear the notification cache (for mode switches)"""
        self.notified_alerts.clear()
        self.notified_reminders.clear()


# Singleton instance
_proactive_service = None

def get_proactive_service() -> ProactiveService:
    """Get or create the singleton proactive service"""
    global _proactive_service
    if _proactive_service is None:
        _proactive_service = ProactiveService()
    return _proactive_service

def reset_proactive_service():
    """Reset the singleton (for mode switches)"""
    global _proactive_service
    if _proactive_service:
        _proactive_service.clear_notification_cache()

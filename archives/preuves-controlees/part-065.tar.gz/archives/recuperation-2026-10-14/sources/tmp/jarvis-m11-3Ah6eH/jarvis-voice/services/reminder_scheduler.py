#!/usr/bin/env python3
"""
Reminder Scheduler Daemon
Checks for reminders that are due and triggers them.

Checks every 60 seconds for reminders with trigger_time <= now.
"""

import sys
import time
import sqlite3
import subprocess
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any

# Add lib to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'lib'))
from config_loader import load_config, get_config_value, get_active_config_mode
from memory_db import MemoryDB
from service_logger import ServiceLogger
from tts_normalizer import normalize_tts_text
from time_utils import (
    add_days_local,
    add_months_local,
    format_utc_db,
    get_app_timezone,
    now_utc,
    parse_utc_timestamp,
    replace_day_safe,
)


def retry_on_db_lock(func, max_retries=5, base_delay=1.0):
    """
    Retry a function on database lock errors with exponential backoff.
    
    Args:
        func: Callable to execute
        max_retries: Maximum retry attempts (default 5)
        base_delay: Base delay in seconds (default 1.0)
    
    Returns:
        Result of func() or raises after max retries
    """
    last_error = None
    for attempt in range(max_retries):
        try:
            return func()
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e):
                last_error = e
                delay = base_delay * (2 ** attempt)  # Exponential backoff: 1, 2, 4, 8, 16 seconds
                print(f"    ⚠️  Database locked, retrying in {delay:.1f}s (attempt {attempt + 1}/{max_retries})")
                time.sleep(delay)
            else:
                raise
    if last_error is None:
        raise ValueError("max_retries must be at least 1")
    raise last_error


def get_due_reminders(db_path: str) -> List[Dict[str, Any]]:
    """Get reminders that are due (trigger_time <= now UTC)."""
    def _query():
        conn = sqlite3.connect(db_path, timeout=30)  # 30 second timeout
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        reminders = cursor.execute("""
            SELECT * FROM reminders 
            WHERE status = 'scheduled'
            ORDER BY trigger_time ASC
        """).fetchall()
        
        conn.close()

        now = now_utc()
        due = [dict(row) for row in reminders if parse_utc_timestamp(row['trigger_time']) <= now]
        due.sort(key=lambda r: parse_utc_timestamp(r['trigger_time']))
        return due
    
    return retry_on_db_lock(_query)


def _tts_script_timeout_seconds(default: int = 60) -> int:
    """Bound native TTS script execution without fighting normal playback."""
    try:
        return max(1, int(get_config_value("TTS_SCRIPT_TIMEOUT_SECONDS", str(default))))
    except (TypeError, ValueError):
        return default


def _parse_recurrence_rule(recurrence_rule: str | None) -> tuple[str, int | None] | None:
    """Parse a supported recurrence rule without raising on legacy bad data."""
    if recurrence_rule == "DAILY":
        return "DAILY", None

    if not recurrence_rule or ":" not in recurrence_rule:
        return None

    recurrence_type, raw_value = recurrence_rule.split(":", 1)
    try:
        value = int(raw_value)
    except ValueError:
        return None

    if recurrence_type == "WEEKLY" and 0 <= value <= 6:
        return "WEEKLY", value
    if recurrence_type == "MONTHLY" and 1 <= value <= 31:
        return "MONTHLY", value
    return None


def speak_reminder(reminder: Dict[str, Any], mode: str, project_root: Path) -> bool:
    """Speak reminder via TTS."""
    title = reminder.get('title', 'Reminder')
    description = reminder.get('description', '')
    recurrence_rule = reminder.get('recurrence_rule')
    
    # Build message
    message = f"Boss, reminder: {title}"
    if description:
        message += f". {description}"
    
    # Add recurring info if applicable
    if recurrence_rule:
        parsed_recurrence = _parse_recurrence_rule(recurrence_rule)
        if parsed_recurrence is None:
            message += ". Its recurrence schedule is invalid, so it will not be rescheduled."
        elif parsed_recurrence[0] == "DAILY":
            message += ". This is a daily reminder, rescheduled for tomorrow."
        elif parsed_recurrence[0] == "WEEKLY":
            days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
            day_num = parsed_recurrence[1]
            message += f". This is a weekly reminder, rescheduled for next {days[day_num]}."
        else:
            day = parsed_recurrence[1]
            message += f". This is a monthly reminder, rescheduled for the {day}th of next month."
    
    # Use appropriate TTS script
    if mode == 'local':
        say_script = project_root / 'bin' / 'say-local.sh'
    else:
        say_script = project_root / 'bin' / 'say.sh'

    if not say_script.exists():
        print(f"Warning: TTS script not found for reminder {reminder['id']}: {say_script}", file=sys.stderr)
        return False

    try:
        spoken_message = normalize_tts_text(message)
        if not spoken_message:
            print(f"Warning: TTS message empty after normalization for reminder {reminder['id']}", file=sys.stderr)
            return False
        result = subprocess.run(
            [str(say_script), spoken_message],
            check=False,
            capture_output=True,
            text=True,
            timeout=_tts_script_timeout_seconds()
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "").strip()
            if detail:
                print(f"Warning: TTS failed for reminder {reminder['id']}: {detail}", file=sys.stderr)
            else:
                print(f"Warning: TTS failed for reminder {reminder['id']} with exit {result.returncode}", file=sys.stderr)
            return False
        return True
    except Exception as e:
        print(f"Warning: TTS failed for reminder {reminder['id']}: {e}", file=sys.stderr)
        return False


def calculate_next_occurrence(
    current_trigger: str,
    recurrence_rule: str,
    reference_time: datetime | None = None,
) -> str | None:
    """Calculate the first recurring occurrence after ``reference_time``.
    
    Args:
        current_trigger: Current trigger time (ISO format UTC)
        recurrence_rule: "DAILY", "WEEKLY:X", or "MONTHLY:X"
        reference_time: Time that the next occurrence must be later than;
            defaults to the current occurrence for backward compatibility
    
    Returns:
        Next trigger time (ISO format UTC)
    """
    local_tz = get_app_timezone()
    current = parse_utc_timestamp(current_trigger).astimezone(local_tz)
    reference = reference_time.astimezone(local_tz) if reference_time else current
    parsed_recurrence = _parse_recurrence_rule(recurrence_rule)
    if parsed_recurrence is None:
        return None
    recurrence_type, recurrence_value = parsed_recurrence

    def _advance(trigger: datetime) -> datetime | None:
        if recurrence_type == "DAILY":
            return add_days_local(trigger, 1)

        if recurrence_type == "WEEKLY":
            # Advance in local time to preserve wall-clock scheduling across DST.
            return add_days_local(trigger, 7)

        if recurrence_type == "MONTHLY":
            return replace_day_safe(add_months_local(trigger, 1), recurrence_value)

        return None

    next_trigger = _advance(current)
    while next_trigger is not None and next_trigger <= reference:
        next_trigger = _advance(next_trigger)

    return format_utc_db(next_trigger) if next_trigger is not None else None


def mark_reminder_triggered(
    db_path: str,
    reminder_id: int,
    recurrence_rule: str = None,
    current_trigger: str = None,
    spoken: bool = True,
) -> bool:
    """Mark or reschedule a due reminder if its scheduled state is unchanged."""
    def _update():
        conn = sqlite3.connect(db_path, timeout=30)  # 30 second timeout
        cursor = conn.cursor()

        # Use UTC time for consistency
        current_time = now_utc()
        now = current_time.isoformat()
        
        spoken_value = 1 if spoken else 0
        spoken_at = now if spoken else None

        if recurrence_rule and spoken:
            # Skip missed intervals and reschedule at the first future occurrence.
            next_trigger = calculate_next_occurrence(
                current_trigger,
                recurrence_rule,
                reference_time=current_time,
            )
            
            if next_trigger:
                cursor.execute("""
                    UPDATE reminders
                    SET status = 'scheduled',
                        trigger_time = ?,
                        triggered_at = ?,
                        spoken = 1,
                        spoken_at = ?
                    WHERE id = ?
                      AND status = 'scheduled'
                      AND (? IS NULL OR trigger_time = ?)
                """, (
                    next_trigger,
                    now,
                    spoken_at,
                    reminder_id,
                    current_trigger,
                    current_trigger,
                ))
            else:
                # Fallback: just mark as triggered if calculation fails
                cursor.execute("""
                    UPDATE reminders
                    SET status = 'triggered',
                        triggered_at = ?,
                        spoken = 1,
                        spoken_at = ?
                    WHERE id = ?
                      AND status = 'scheduled'
                      AND (? IS NULL OR trigger_time = ?)
                """, (
                    now,
                    spoken_at,
                    reminder_id,
                    current_trigger,
                    current_trigger,
                ))
        else:
            # One-time reminder, or recurring reminder whose speech failed.
            # Keep failed speech visible as triggered + spoken=0 instead of
            # silently advancing recurrence and pretending audio played.
            cursor.execute("""
                UPDATE reminders
                SET status = 'triggered',
                    triggered_at = ?,
                    spoken = ?,
                    spoken_at = ?
                WHERE id = ?
                  AND status = 'scheduled'
                  AND (? IS NULL OR trigger_time = ?)
            """, (
                now,
                spoken_value,
                spoken_at,
                reminder_id,
                current_trigger,
                current_trigger,
            ))

        updated = cursor.rowcount > 0
        conn.commit()
        conn.close()
        return updated

    return retry_on_db_lock(_update)


def call_callback_url(url: str):
    """Call webhook callback URL if provided."""
    try:
        import requests
        response = requests.post(url, timeout=10)
        return response.ok
    except Exception as e:
        print(f"Warning: Callback failed: {e}", file=sys.stderr)
        return False


def main():
    """Reminder scheduler daemon main loop."""
    print("⏰ Reminder Scheduler Starting...")
    
    # Load config
    load_config()
    mode = get_active_config_mode()
    
    project_root = Path(__file__).parent.parent
    db = MemoryDB()
    db_path = db.db_path
    
    # Initialize logger
    logger = ServiceLogger('reminder_scheduler')
    logger.log_startup(mode, {
        "database": str(db_path),
        "check_interval": 60
    })
    
    print(f"   Mode: {mode}")
    print(f"   Database: {db_path}")
    print("   Check interval: 60 seconds")
    print()
    
    check_count = 0
    triggered_count = 0
    
    consecutive_errors = 0
    max_consecutive_errors = 10  # Only crash after 10 consecutive errors
    
    try:
        while True:
            try:
                check_count += 1
                
                # Get due reminders
                due_reminders = get_due_reminders(db_path)
                consecutive_errors = 0  # Reset on success
                
                logger.log_check(len(due_reminders), {"due_reminders": len(due_reminders)})
                
                if len(due_reminders) > 0:
                    print(f"[{datetime.now().strftime('%H:%M:%S')}] Check #{check_count}: {len(due_reminders)} due reminders")
                    
                    for reminder in due_reminders:
                        reminder_id = reminder['id']
                        title = reminder['title']
                        trigger_time = reminder['trigger_time']
                        callback_url = reminder.get('callback_url')
                        
                        print(f"  → Triggering reminder {reminder_id}: {title}")
                        print(f"    Scheduled for: {trigger_time}")
                        
                        try:
                            # Speak reminder
                            speech_ok = speak_reminder(reminder, mode, project_root)
                            
                            # Mark as triggered or reschedule if recurring
                            state_updated = mark_reminder_triggered(
                                db_path, 
                                reminder_id,
                                recurrence_rule=reminder.get('recurrence_rule'),
                                current_trigger=reminder['trigger_time'],
                                spoken=speech_ok
                            )
                            if not state_updated:
                                print(
                                    f"    State changed while reminder {reminder_id} was playing; "
                                    "leaving the newer state unchanged"
                                )
                                logger.log_action("preserve_reminder_state", {
                                    "reminder_id": reminder_id,
                                    "title": title,
                                    "trigger_time": trigger_time,
                                })
                                continue
                            if not speech_ok:
                                print(f"    TTS failed; reminder {reminder_id} marked triggered but unspoken")
                                logger.log_error(f"TTS failed for reminder {reminder_id}; marked unspoken", {
                                    "reminder_id": reminder_id,
                                    "title": title,
                                    "trigger_time": trigger_time,
                                })
                            
                            # Log trigger action
                            logger.log_action("trigger_reminder", {
                                "reminder_id": reminder_id,
                                "title": title,
                                "trigger_time": trigger_time,
                                "recurrence_rule": reminder.get('recurrence_rule'),
                                "spoken": speech_ok,
                            }, success=speech_ok)
                            
                            # Call callback if provided
                            if callback_url:
                                print(f"    Calling callback: {callback_url}")
                                success = call_callback_url(callback_url)
                                if success:
                                    print("    ✅ Callback succeeded")
                                else:
                                    print("    ⚠️  Callback failed")
                                    logger.log_error(f"Callback failed for reminder {reminder_id}", {
                                        "reminder_id": reminder_id,
                                        "callback_url": callback_url
                                    })
                            
                            triggered_count += 1
                        
                        except Exception as e:
                            logger.log_error(f"Failed to trigger reminder {reminder_id}", {
                                "reminder_id": reminder_id,
                                "error": str(e)
                            })
                            print(f"    ⚠️  Error: {e}")
                
                # Wait before next check
                time.sleep(60)
                
            except sqlite3.OperationalError as e:
                consecutive_errors += 1
                logger.log_error(f"Database error (attempt {consecutive_errors}): {e}")
                print(f"\n⚠️  Database error: {e} (attempt {consecutive_errors}/{max_consecutive_errors})", file=sys.stderr)
                if consecutive_errors >= max_consecutive_errors:
                    print("\n❌ Too many consecutive errors, shutting down", file=sys.stderr)
                    logger.log_shutdown({"reason": "too_many_errors", "last_error": str(e)})
                    sys.exit(1)
                time.sleep(30)  # Wait longer after DB errors
                
            except Exception as e:
                consecutive_errors += 1
                logger.log_error(f"Unexpected error (attempt {consecutive_errors}): {e}")
                print(f"\n⚠️  Error: {e} (attempt {consecutive_errors}/{max_consecutive_errors})", file=sys.stderr)
                if consecutive_errors >= max_consecutive_errors:
                    print("\n❌ Too many consecutive errors, shutting down", file=sys.stderr)
                    logger.log_shutdown({"reason": "too_many_errors", "last_error": str(e)})
                    sys.exit(1)
                time.sleep(60)  # Continue checking after transient errors
    
    except KeyboardInterrupt:
        print("\n✋ Reminder Scheduler stopped by user")
        print(f"   Total triggered: {triggered_count}")
        logger.log_shutdown({"total_triggered": triggered_count, "checks": check_count})


if __name__ == "__main__":
    main()

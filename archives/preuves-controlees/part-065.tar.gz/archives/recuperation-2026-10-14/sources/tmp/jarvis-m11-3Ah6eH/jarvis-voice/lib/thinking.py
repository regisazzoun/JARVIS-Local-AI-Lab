#!/usr/bin/env python3
"""Opt-in provider thinking configuration, extraction, display, and logging."""
import os
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

from model_catalog import get_model_metadata

logger = logging.getLogger(__name__)

# Non-streaming Anthropic SDK rejects max_tokens above ~16K (long-request guard).
ANTHROPIC_ADAPTIVE_MAX_TOKENS = 16384


def _anthropic_thinking_capabilities(model: str) -> dict[str, Any]:
    """Return audited Anthropic thinking metadata from the shared catalog."""
    metadata = get_model_metadata("anthropic", model)
    if not metadata:
        return {}
    capabilities = metadata.get("capabilities", {})
    thinking = capabilities.get("thinking", {})
    return thinking if isinstance(thinking, dict) else {}


def _anthropic_thinking_type_supported(model: str, thinking_type: str) -> bool:
    types = _anthropic_thinking_capabilities(model).get("types", {})
    type_capabilities = types.get(thinking_type, {}) if isinstance(types, dict) else {}
    return bool(type_capabilities.get("supported"))


def is_thinking_supported(provider: str, model: str) -> bool:
    """
    Check if a model supports extended thinking.
    
    Args:
        provider: Provider name (anthropic, openai, ollama)
        model: Model name
        
    Returns:
        True if thinking is supported, False otherwise
    """
    # Anthropic is the only provider whose optional visible-thinking request is
    # configured here. OpenAI/xAI reasoning controls and Ollama's native `think`
    # flag are owned by their provider implementations in llm_provider.py.
    if provider.lower() != "anthropic":
        return False
    capabilities = _anthropic_thinking_capabilities(model)
    return bool(
        capabilities.get("supported")
        and (
            _anthropic_thinking_type_supported(model, "adaptive")
            or _anthropic_thinking_type_supported(model, "enabled")
        )
    )


def should_enable_thinking() -> bool:
    """
    Check if thinking mode should be enabled.
    Priority: CLI flag > env variable
    
    Returns:
        True if thinking should be enabled
    """
    # Use the same request-scoped precedence as provider/model/effort settings.
    # Reading os.environ directly leaks one process-global value across
    # concurrent Web cloud/local requests and ignores config_scope overrides.
    from config_loader import get_bool

    return get_bool("JARVIS_DEBUG_THINKING", False)


def uses_adaptive_thinking(provider: str, model: str) -> bool:
    """Return whether the catalog says this Anthropic model supports adaptive thinking."""
    if provider.lower() != "anthropic":
        return False
    return _anthropic_thinking_type_supported(model, "adaptive")


def _anthropic_effort(model: str, requested_override: str | None = None) -> str | None:
    """Resolve and validate adaptive-thinking effort for an Anthropic model."""
    metadata = get_model_metadata("anthropic", model) or {}
    effort_capabilities = metadata.get("capabilities", {}).get("effort", {})
    if not effort_capabilities.get("supported"):
        return None

    supported = {
        level
        for level in ("low", "medium", "high", "max", "xhigh")
        if effort_capabilities.get(level, {}).get("supported")
    }
    if not supported:
        return None

    requested = (
        requested_override
        if requested_override is not None
        else os.getenv("ANTHROPIC_EFFORT", "")
    ).strip().lower()
    if requested and requested in supported:
        return requested
    if requested:
        logger.warning(
            "Ignoring unsupported ANTHROPIC_EFFORT=%r for %s; supported values: %s",
            requested,
            model,
            ", ".join(sorted(supported)),
        )

    # Prefer the strongest audited level when no valid override is present.
    return next(level for level in ("xhigh", "max", "high", "medium", "low") if level in supported)


def get_thinking_config(
    provider: str,
    model: str,
    effort_override: str | None = None,
) -> dict[str, Any] | None:
    """
    Get thinking configuration for a specific provider/model.
    
    Args:
        provider: Provider name
        model: Model name
        
    Returns:
        API params dict (thinking and optional output_config / max_tokens) or None
    """
    if not is_thinking_supported(provider, model):
        return None
    
    if provider.lower() == "anthropic":
        if uses_adaptive_thinking(provider, model):
            config = {
                "thinking": {"type": "adaptive", "display": "summarized"},
                "max_tokens": ANTHROPIC_ADAPTIVE_MAX_TOKENS,
            }
            effort = _anthropic_effort(model, requested_override=effort_override)
            if effort:
                config["output_config"] = {"effort": effort}
            return config
        if _anthropic_thinking_type_supported(model, "enabled"):
            return {
                "thinking": {"type": "enabled", "budget_tokens": 2000},
                "max_tokens": 8000,
            }

    return None


def extract_thinking(response: Any, provider: str) -> str | None:
    """
    Extract thinking content from LLM response.
    
    Args:
        response: LLM response object
        provider: Provider name
        
    Returns:
        Thinking text or None if not available
    """
    try:
        if provider == "anthropic":
            # Anthropic returns thinking as a content block with type="thinking"
            if hasattr(response, 'content'):
                for block in response.content:
                    if hasattr(block, 'type') and block.type == 'thinking':
                        # Extract text from thinking block
                        if hasattr(block, 'thinking'):
                            return block.thinking
                        elif hasattr(block, 'text'):
                            return block.text
            # Fallback: Check if thinking is a direct attribute (older API format)
            if hasattr(response, 'thinking') and response.thinking:
                return response.thinking[0].text
        
        elif provider == "ollama":
            # Ollama has TWO formats for thinking:
            # 1. Structured field (qwen3.5:latest, modern models) - preferred
            # 2. Tags in content (deepseek-r1, raw output) - fallback
            
            # Method 1: Check for structured thinking field (Ollama API format)
            if isinstance(response, dict):
                # Response is a dict (from JSON)
                if 'thinking' in response and response['thinking']:
                    return response['thinking']
                # Sometimes thinking is nested in message
                if 'message' in response and isinstance(response['message'], dict):
                    if 'thinking' in response['message']:
                        return response['message']['thinking']
            
            # Method 2: Check for thinking in message content (tags)
            if hasattr(response, 'message') and hasattr(response.message, 'content'):
                content = response.message.content
                
                # DeepSeek R1 uses <think> tags
                if '<think>' in content and '</think>' in content:
                    start = content.find('<think>') + len('<think>')
                    end = content.find('</think>')
                    return content[start:end].strip()
                
                # Generic <thinking> tags (other models)
                if '<thinking>' in content and '</thinking>' in content:
                    start = content.find('<thinking>') + len('<thinking>')
                    end = content.find('</thinking>')
                    return content[start:end].strip()
    
    except Exception as e:
        logger.warning(f"Failed to extract thinking: {e}")
    
    return None


def log_thinking(
    query: str,
    thinking: str,
    decision: dict[str, Any],
    provider: str,
    model: str
) -> None:
    """
    Log thinking to file for later analysis.
    
    Args:
        query: User query
        thinking: LLM thinking/reasoning
        decision: Decision made (tools called, saved, etc.)
        provider: Provider name
        model: Model name
    """
    try:
        # Create logs/thinking directory if it doesn't exist
        log_dir = Path("logs/thinking")
        log_dir.mkdir(parents=True, exist_ok=True)
        
        # Log file: YYYY-MM-DD_decisions.jsonl
        today = datetime.now().strftime("%Y-%m-%d")
        log_file = log_dir / f"{today}_decisions.jsonl"
        
        # Create log entry
        entry = {
            "timestamp": datetime.now().isoformat(),
            "provider": provider,
            "model": model,
            "query": query,
            "thinking": thinking,
            "decision": decision
        }
        
        # Append to log file (JSONL format)
        with open(log_file, "a") as f:
            f.write(json.dumps(entry) + "\n")
        
        logger.debug(f"Thinking logged to {log_file}")
    
    except Exception as e:
        logger.error(f"Failed to log thinking: {e}")


def format_thinking_display(thinking: str, compact: bool = False) -> str:
    """
    Format thinking for console display.
    
    Args:
        thinking: Thinking text
        compact: If True, show abbreviated version
        
    Returns:
        Formatted string for display
    """
    if not thinking:
        return ""
    
    # ANSI color codes
    CYAN = '\033[0;36m'
    YELLOW = '\033[1;33m'
    NC = '\033[0m'  # No Color
    
    if compact and len(thinking) > 200:
        # Show first 150 chars + "..."
        thinking = thinking[:150] + "..."
    
    # Format with box
    lines = thinking.split('\n')
    formatted = f"\n{CYAN}{'═' * 60}{NC}\n"
    formatted += f"{YELLOW}🧠 LLM Thinking:{NC}\n"
    formatted += f"{CYAN}{'─' * 60}{NC}\n"
    
    for line in lines:
        formatted += f"   {line}\n"
    
    formatted += f"{CYAN}{'═' * 60}{NC}\n"
    
    return formatted


def get_thinking_prompt_addition() -> str:
    """
    Get additional system prompt text to encourage thinking.
    
    Returns:
        Additional prompt text
    """
    return """
When making complex decisions (auto-save, tool selection, grey areas), explicitly reason through:
1. What is the user asking for?
2. What information do I need?
3. Should I save this? (check criteria)
4. What category/importance?
5. Which tool is best?

Think step-by-step before deciding.
"""


# Thinking analysis helpers

def analyze_thinking_logs(date: str = None) -> dict[str, Any]:
    """
    Analyze thinking logs to find patterns.
    
    Args:
        date: Date to analyze (YYYY-MM-DD) or None for today
        
    Returns:
        Analysis summary
    """
    if date is None:
        date = datetime.now().strftime("%Y-%m-%d")
    
    log_file = Path(f"logs/thinking/{date}_decisions.jsonl")
    
    if not log_file.exists():
        return {"error": "No thinking logs found for this date"}
    
    # Parse logs
    decisions = []
    with open(log_file, "r") as f:
        for line in f:
            if line.strip():
                decisions.append(json.loads(line))
    
    # Analyze
    total = len(decisions)
    saved = sum(1 for d in decisions if d['decision'].get('saved', False))
    tools_used = {}
    
    for decision in decisions:
        for tool in decision['decision'].get('tools', []):
            tools_used[tool] = tools_used.get(tool, 0) + 1
    
    return {
        "date": date,
        "total_decisions": total,
        "saved_to_memory": saved,
        "save_rate": f"{(saved/total*100):.1f}%" if total > 0 else "0%",
        "tools_used": tools_used,
        "recent_decisions": decisions[-5:]  # Last 5
    }


if __name__ == "__main__":
    # Test thinking support detection
    print("Testing thinking support detection:")
    print(f"Anthropic Sonnet 4.5: {is_thinking_supported('anthropic', 'claude-sonnet-4-5-20250929')}")
    print(f"Anthropic Fable 5: {is_thinking_supported('anthropic', 'claude-fable-5')}")

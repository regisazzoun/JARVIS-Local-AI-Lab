#!/usr/bin/env python3
"""
Acknowledge Reminders Tool
Mark reminders as acknowledged/completed.

Input: {
    "reminder_ids": [1, 2, 3],  # List of reminder IDs to acknowledge
    "all_triggered": false  # Optional: acknowledge ALL triggered reminders
}

Output: {
    "ok": bool,
    "speech": str,
    "data": {
        "acknowledged_count": int,
        "acknowledged_ids": [...]
    }
}
"""

import sys
import os
import json
import sqlite3
from datetime import datetime, timezone

# Add lib to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'lib'))
from config_loader import load_config
from memory_db import MemoryDB

# Levenshtein distance for fuzzy matching (typo tolerance)
def levenshtein_distance(s1: str, s2: str) -> int:
    """
    Calculate Levenshtein distance between two strings.
    Returns the minimum number of edits (insertions, deletions, substitutions).
    
    Examples:
    - levenshtein_distance("checkbook", "checkbbok") = 2
    - levenshtein_distance("dinner", "diner") = 1
    """
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)
    
    if len(s2) == 0:
        return len(s1)
    
    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            # Cost of insertions, deletions, or substitutions
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row
    
    return previous_row[-1]

def main():
    try:
        # Parse arguments
        if len(sys.argv) > 1:
            args = json.loads(sys.argv[1])
        else:
            args = json.load(sys.stdin)
        
        # Load config
        load_config()
        
        # Extract parameters
        reminder_ids = args.get('reminder_ids', [])
        title_search = args.get('title_search')
        all_triggered = args.get('all_triggered', False)
        
        if not reminder_ids and not all_triggered and not title_search:
            raise ValueError("Either 'reminder_ids', 'title_search', or 'all_triggered' must be specified")
        
        # Connect to database
        db = MemoryDB()
        conn = sqlite3.connect(db.db_path)
        cursor = conn.cursor()
        
        now = datetime.now(timezone.utc).isoformat()
        acknowledged_ids = []
        
        if title_search:
            # Phase 1: SQL LIKE fuzzy match (fast, gets candidates)
            cursor.execute("""
                SELECT id, title, description FROM reminders
                WHERE status IN ('triggered', 'scheduled')
                AND (title LIKE ? OR description LIKE ?)
            """, (f'%{title_search}%', f'%{title_search}%'))
            
            sql_matches = cursor.fetchall()
            
            # Phase 2: Levenshtein distance for typo tolerance
            # If SQL LIKE finds nothing, try Levenshtein on all reminders
            if not sql_matches:
                cursor.execute("""
                    SELECT id, title, description FROM reminders
                    WHERE status IN ('triggered', 'scheduled')
                """)
                all_reminders = cursor.fetchall()
                
                # Calculate Levenshtein distance for each reminder
                fuzzy_matches = []
                max_distance = 3  # Allow up to 3 typos
                
                for reminder in all_reminders:
                    rid, title, description = reminder
                    title_distance = levenshtein_distance(title_search.lower(), title.lower())
                    desc_distance = levenshtein_distance(title_search.lower(), (description or "").lower())
                    
                    # Use minimum distance (best match)
                    min_distance = min(title_distance, desc_distance)
                    
                    if min_distance <= max_distance:
                        fuzzy_matches.append((rid, title, description, min_distance))
                
                # Sort by distance (best matches first)
                fuzzy_matches.sort(key=lambda x: x[3])
                
                # Convert back to original format
                matching_reminders = [(r[0], r[1], r[2]) for r in fuzzy_matches]
            else:
                matching_reminders = sql_matches
            
            if not matching_reminders:
                # Check if there are already-acknowledged/cancelled reminders matching
                cursor.execute("""
                    SELECT id, title, status, acknowledged_at FROM reminders
                    WHERE status IN ('acknowledged', 'cancelled')
                    AND (title LIKE ? OR description LIKE ?)
                    ORDER BY acknowledged_at DESC
                    LIMIT 5
                """, (f'%{title_search}%', f'%{title_search}%'))
                
                already_done = cursor.fetchall()
                conn.close()
                
                if already_done:
                    # Found matching reminders but they're already done
                    count = len(already_done)
                    if count == 1:
                        r = already_done[0]
                        status_word = "acknowledged" if r[2] == "acknowledged" else "cancelled"
                        print(json.dumps({
                            "ok": True,  # Not an error - user's intent was already fulfilled
                            "speech": f"The reminder '{r[1]}' was already {status_word}. Nothing to do.",
                            "data": {
                                "already_done": True,
                                "reminder_id": r[0],
                                "title": r[1],
                                "status": r[2]
                            }
                        }))
                    else:
                        titles = [f"'{r[1]}' ({r[2]})" for r in already_done]
                        print(json.dumps({
                            "ok": True,
                            "speech": f"Found {count} reminders matching '{title_search}' but they're already done: {', '.join(titles)}",
                            "data": {
                                "already_done": True,
                                "count": count,
                                "reminders": [{"id": r[0], "title": r[1], "status": r[2]} for r in already_done]
                            }
                        }))
                    return 0
                
                # Truly not found anywhere
                print(json.dumps({
                    "ok": False,
                    "error": f"No reminders found matching '{title_search}'",
                    "speech": f"I couldn't find any reminder matching '{title_search}' - not active or past."
                }))
                return 1
            
            # SAFETY: If multiple matches, require user to be more specific
            if len(matching_reminders) > 1:
                conn.close()
                matched_titles = [f"'{row[1]}' (ID {row[0]})" for row in matching_reminders]
                titles_list = ", ".join(matched_titles)
                print(json.dumps({
                    "ok": False,
                    "error": f"Multiple reminders match '{title_search}': {titles_list}",
                    "speech": f"I found {len(matching_reminders)} reminders matching '{title_search}': {titles_list}. Which one do you want to cancel? Please be more specific or say the full name.",
                    "data": {
                        "matches": [{"id": row[0], "title": row[1], "description": row[2]} for row in matching_reminders],
                        "count": len(matching_reminders)
                    }
                }))
                return 1
            
            # Acknowledge the single matching reminder
            reminder_ids = [matching_reminders[0][0]]
            matched_titles = [matching_reminders[0][1]]
            
        if all_triggered:
            # Acknowledge all pending reminders (triggered or scheduled)
            cursor.execute("""
                UPDATE reminders
                SET status = 'acknowledged',
                    acknowledged_at = ?
                WHERE status IN ('triggered', 'scheduled')
            """, (now,))
            
            # Get IDs that were updated
            cursor.execute("""
                SELECT id FROM reminders
                WHERE status = 'acknowledged'
                AND acknowledged_at = ?
            """, (now,))
            
            acknowledged_ids = [row[0] for row in cursor.fetchall()]
        else:
            # Acknowledge specific reminders
            for reminder_id in reminder_ids:
                cursor.execute("""
                    UPDATE reminders
                    SET status = 'acknowledged',
                        acknowledged_at = ?
                    WHERE id = ?
                    AND status IN ('scheduled', 'triggered')
                """, (now, reminder_id))
                
                if cursor.rowcount > 0:
                    acknowledged_ids.append(reminder_id)
        
        conn.commit()
        conn.close()
        
        # Generate speech
        count = len(acknowledged_ids)
        
        if count == 0:
            speech = "No reminders were acknowledged. They may have already been completed or don't exist."
        elif count == 1:
            speech = f"Acknowledged 1 reminder (ID: {acknowledged_ids[0]})."
        else:
            speech = f"Acknowledged {count} reminders."
        
        print(json.dumps({
            "ok": True,
            "speech": speech,
            "data": {
                "acknowledged_count": count,
                "acknowledged_ids": acknowledged_ids
            }
        }))
        
    except Exception as e:
        print(json.dumps({
            "ok": False,
            "error": str(e),
            "speech": f"Failed to acknowledge reminders: {e}"
        }))
        sys.exit(1)


if __name__ == "__main__":
    main()


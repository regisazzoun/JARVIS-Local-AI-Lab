/* SPDX-License-Identifier: GPL-2.0 */

#ifndef __LINUX_USB_TYPEC_H
#define __LINUX_USB_TYPEC_H

#include <linux/types.h>

/* USB Type-C Specification releases */
#define USB_TYPEC_REV_1_0	0x100 /* 1.0 */
#define USB_TYPEC_REV_1_1	0x110 /* 1.1 */
#define USB_TYPEC_REV_1_2	0x120 /* 1.2 */
#define USB_TYPEC_REV_1_3	0x130 /* 1.3 */
#define USB_TYPEC_REV_1_4	0x140 /* 1.4 */
#define USB_TYPEC_REV_2_0	0x200 /* 2.0 */

struct typec_partner;
struct typec_cable;
struct typec_plug;
struct typec_port;
struct typec_altmode_ops;
struct typec_cable_ops;

struct fwnode_handle;
struct device;

struct usb_power_delivery;
struct usb_power_delivery_desc;

enum typec_port_type {
	TYPEC_PORT_SRC,
	TYPEC_PORT_SNK,
	TYPEC_PORT_DRP,
};

enum typec_port_data {
	TYPEC_PORT_DFP,
	TYPEC_PORT_UFP,
	TYPEC_PORT_DRD,
};

enum typec_plug_type {
	USB_PLUG_NONE,
	USB_PLUG_TYPE_A,
	USB_PLUG_TYPE_B,
	USB_PLUG_TYPE_C,
	USB_PLUG_CAPTIVE,
};

enum typec_data_role {
	TYPEC_DEVICE,
	TYPEC_HOST,
};

enum typec_role {
	TYPEC_SINK,
	TYPEC_SOURCE,
};

static inline int is_sink(enum typec_role role)
{
	return role == TYPEC_SINK;
}

static inline int is_source(enum typec_role role)
{
	return role == TYPEC_SOURCE;
}

enum typec_pwr_opmode {
	TYPEC_PWR_MODE_USB,
	TYPEC_PWR_MODE_1_5A,
	TYPEC_PWR_MODE_3_0A,
	TYPEC_PWR_MODE_PD,
};

enum typec_accessory {
	TYPEC_ACCESSORY_NONE,
	TYPEC_ACCESSORY_AUDIO,
	TYPEC_ACCESSORY_DEBUG,
};

#define TYPEC_MAX_ACCESSORY	3

enum typec_orientation {
	TYPEC_ORIENTATION_NONE,
	TYPEC_ORIENTATION_NORMAL,
	TYPEC_ORIENTATION_REVERSE,
};

enum usb_mode {
	USB_MODE_NONE,
	USB_MODE_USB2,
	USB_MODE_USB3,
	USB_MODE_USB4
};

#define USB_CAPABILITY_USB2	BIT(0)
#define USB_CAPABILITY_USB3	BIT(1)
#define USB_CAPABILITY_USB4	BIT(2)

/*
 * struct enter_usb_data - Enter_USB Message details
 * @eudo: Enter_USB Data Object
 * @active_link_training: Active Cable Plug Link Training
 *
 * @active_link_training is a flag that should be set with uni-directional SBRX
 * communication, and left 0 with passive cables and with bi-directional SBRX
 * communication.
 */
struct enter_usb_data {
	u32			eudo;
	unsigned char		active_link_training:1;
};

/*
 * struct usb_pd_identity - USB Power Delivery identity data
 * @id_header: ID Header VDO
 * @cert_stat: Cert Stat VDO
 * @product: Product VDO
 * @vdo: Product Type Specific VDOs
 *
 * USB power delivery Discover Identity command response data.
 *
 * REVISIT: This is USB Power Delivery specific information, so this structure
 * probable belongs to USB Power Delivery header file once we have them.
 */
struct usb_pd_identity {
	u32			id_header;
	u32			cert_stat;
	u32			product;
	u32			vdo[3];
};

int typec_partner_set_identity(struct typec_partner *partner);
int typec_cable_set_identity(struct typec_cable *cable);

/*
 * struct typec_altmode_desc - USB Type-C Alternate Mode Descriptor
 * @svid: Standard or Vendor ID
 * @mode: Index of the Mode
 * @vdo: VDO returned by Discover Modes USB PD command
 * @roles: Only for ports. DRP if the mode is available in both roles
 * @inactive: Only for ports. Make this port inactive (default is active).
 *
 * Description of an Alternate Mode which a connector, cable plug or partner
 * supports.
 */
struct typec_altmode_desc {
	u16			svid;
	u8			mode;
	u32			vdo;
	/* Only used with ports */
	enum typec_port_data	roles;
	bool			inactive;
};

void typec_partner_set_pd_revision(struct typec_partner *partner, u16 pd_revision);
int typec_partner_set_num_altmodes(struct typec_partner *partner, int num_altmodes);
struct typec_altmode
*typec_partner_register_altmode(struct typec_partner *partner,
				const struct typec_altmode_desc *desc);
int typec_plug_set_num_altmodes(struct typec_plug *plug, int num_altmodes);
struct typec_altmode
*typec_plug_register_altmode(struct typec_plug *plug,
			     const struct typec_altmode_desc *desc);
struct typec_altmode
*typec_port_register_altmode(struct typec_port *port,
			     const struct typec_altmode_desc *desc);

void typec_port_register_altmodes(struct typec_port *port,
	const struct typec_altmode_ops *ops, void *drvdata,
	struct typec_altmode **altmodes, size_t n);

void typec_port_register_cable_ops(struct typec_altmode **altmodes, int max_altmodes,
				   const struct typec_cable_ops *ops);

void typec_unregister_altmode(struct typec_altmode *altmode);

struct typec_port *typec_altmode2port(struct typec_altmode *alt);

void typec_altmode_update_active(struct typec_altmode *alt, bool active);

void typec_altmode_set_ops(struct typec_altmode *alt,
			   const struct typec_altmode_ops *ops);

enum typec_plug_index {
	TYPEC_PLUG_SOP_P,
	TYPEC_PLUG_SOP_PP,
};

/*
 * struct typec_plug_desc - USB Type-C Cable Plug Descriptor
 * @index: SOP Prime for the plug connected to DFP and SOP Double Prime for the
 *         plug connected to UFP
 *
 * Represents USB Type-C Cable Plug.
 */
struct typec_plug_desc {
	enum typec_plug_index	index;
};

/*
 * struct typec_cable_desc - USB Type-C Cable Descriptor
 * @type: The plug type from USB PD Cable VDO
 * @active: Is the cable active or passive
 * @identity: Result of Discover Identity command
 * @pd_revision: USB Power Delivery Specification revision if supported
 *
 * Represents USB Type-C Cable attached to USB Type-C port.
 */
struct typec_cable_desc {
	enum typec_plug_type	type;
	unsigned int		active:1;
	struct usb_pd_identity	*identity;
	u16			pd_revision; /* 0300H = "3.0" */

};

/*
 * struct typec_partner_desc - USB Type-C Partner Descriptor
 * @usb_pd: USB Power Delivery support
 * @accessory: Audio, Debug or none.
 * @identity: Discover Identity command data
 * @pd_revision: USB Power Delivery Specification Revision if supported
 * @usb_capability: Supported USB Modes
 * @attach: Notification about attached USB device
 * @deattach: Notification about removed USB device
 *
 * Details about a partner that is attached to USB Type-C port. If @identity
 * member exists when partner is registered, a directory named "identity" is
 * created to sysfs for the partner device.
 *
 * @pd_revision is based on the setting of the "Specification Revision" field
 * in the message header on the initial "Source Capabilities" message received
 * from the partner, or a "Request" message received from the partner, depending
 * on whether our port is a Sink or a Source.
 */
struct typec_partner_desc {
	unsigned int		usb_pd:1;
	enum typec_accessory	accessory;
	struct usb_pd_identity	*identity;
	u16			pd_revision; /* 0300H = "3.0" */
	u8			usb_capability;

	void (*attach)(struct typec_partner *partner, struct device *dev);
	void (*deattach)(struct typec_partner *partner, struct device *dev);
};

/**
 * struct typec_operations - USB Type-C Port Operations
 * @try_role: Set data role preference for DRP port
 * @dr_set: Set Data Role
 * @pr_set: Set Power Role
 * @vconn_set: Source VCONN
 * @port_type_set: Set port type
 * @pd_get: Get available USB Power Delivery Capabilities.
 * @pd_set: Set USB Power Delivery Capabilities.
 * @default_usb_mode_set: USB Mode to be used by default with Enter_USB Message
 * @enter_usb_mode: Change the active USB Mode
 */
struct typec_operations {
	int (*try_role)(struct typec_port *port, int role);
	int (*dr_set)(struct typec_port *port, enum typec_data_role role);
	int (*pr_set)(struct typec_port *port, enum typec_role role);
	int (*vconn_set)(struct typec_port *port, enum typec_role role);
	int (*port_type_set)(struct typec_port *port,
			     enum typec_port_type type);
	struct usb_power_delivery **(*pd_get)(struct typec_port *port);
	int (*pd_set)(struct typec_port *port, struct usb_power_delivery *pd);
	int (*default_usb_mode_set)(struct typec_port *port, enum usb_mode mode);
	int (*enter_usb_mode)(struct typec_port *port, enum usb_mode mode);
};

enum usb_pd_svdm_ver {
	SVDM_VER_1_0 = 0,
	SVDM_VER_2_0 = 1,
	SVDM_VER_MAX = SVDM_VER_2_0,
};

/*
 * struct typec_capability - USB Type-C Port Capabilities
 * @type: Supported power role of the port
 * @data: Supported data role of the port
 * @revision: USB Type-C Specification release. Binary coded decimal
 * @pd_revision: USB Power Delivery Specification revision if supported
 * @svdm_version: USB PD Structured VDM version if supported
 * @prefer_role: Initial role preference (DRP ports).
 * @accessory: Supported Accessory Modes
 * @usb_capability: Supported USB Modes
 * @fwnode: Optional fwnode of the port
 * @driver_data: Private pointer for driver specific info
 * @pd: Optional USB Power Delivery Support
 * @ops: Port operations vector
 *
 * Static capabilities of a single USB Type-C port.
 */
struct typec_capability {
	enum typec_port_type	type;
	enum typec_port_data	data;
	u16			revision; /* 0120H = "1.2" */
	u16			pd_revision; /* 0300H = "3.0" */
	enum usb_pd_svdm_ver	svdm_version;
	int			prefer_role;
	enum typec_accessory	accessory[TYPEC_MAX_ACCESSORY];
	unsigned int		orientation_aware:1;
	u8			usb_capability;

	struct fwnode_handle	*fwnode;
	void			*driver_data;

	struct usb_power_delivery *pd;

	const struct typec_operations	*ops;
};

/* Specific to try_role(). Indicates the user want's to clear the preference. */
#define TYPEC_NO_PREFERRED_ROLE	(-1)

struct typec_port *typec_register_port(struct device *parent,
				       const struct typec_capability *cap);
void typec_unregister_port(struct typec_port *port);

struct typec_partner *typec_register_partner(struct typec_port *port,
					     struct typec_partner_desc *desc);
void typec_unregister_partner(struct typec_partner *partner);

struct typec_cable *typec_register_cable(struct typec_port *port,
					 struct typec_cable_desc *desc);
void typec_unregister_cable(struct typec_cable *cable);

struct typec_cable *typec_cable_get(struct typec_port *port);
void typec_cable_put(struct typec_cable *cable);
int typec_cable_is_active(struct typec_cable *cable);

struct typec_plug *typec_register_plug(struct typec_cable *cable,
				       struct typec_plug_desc *desc);
void typec_unregister_plug(struct typec_plug *plug);

void typec_set_data_role(struct typec_port *port, enum typec_data_role role);
void typec_set_pwr_role(struct typec_port *port, enum typec_role role);
void typec_set_vconn_role(struct typec_port *port, enum typec_role role);
void typec_set_pwr_opmode(struct typec_port *port, enum typec_pwr_opmode mode);

int typec_set_orientation(struct typec_port *port,
			  enum typec_orientation orientation);
enum typec_orientation typec_get_orientation(struct typec_port *port);
int typec_set_mode(struct typec_port *port, int mode);

void *typec_get_drvdata(struct typec_port *port);

int typec_get_fw_cap(struct typec_capability *cap,
		     struct fwnode_handle *fwnode);

int typec_find_pwr_opmode(const char *name);
int typec_find_orientation(const char *name);
int typec_find_port_power_role(const char *name);
int typec_find_power_role(const char *name);
int typec_find_port_data_role(const char *name);

void typec_partner_set_svdm_version(struct typec_partner *partner,
				    enum usb_pd_svdm_ver svdm_version);
int typec_get_negotiated_svdm_version(struct typec_port *port);

int typec_get_cable_svdm_version(struct typec_port *port);
void typec_cable_set_svdm_version(struct typec_cable *cable, enum usb_pd_svdm_ver svdm_version);

struct usb_power_delivery *typec_partner_usb_power_delivery_register(struct typec_partner *partner,
							struct usb_power_delivery_desc *desc);

int typec_port_set_usb_power_delivery(struct typec_port *port, struct usb_power_delivery *pd);
int typec_partner_set_usb_power_delivery(struct typec_partner *partner,
					 struct usb_power_delivery *pd);

void typec_partner_set_usb_mode(struct typec_partner *partner, enum usb_mode usb_mode);
void typec_port_set_usb_mode(struct typec_port *port, enum usb_mode mode);

/**
 * struct typec_connector - Representation of Type-C port for external drivers
 * @attach: notification about device removal
 * @deattach: notification about device removal
 *
 * Drivers that control the USB and other ports (DisplayPorts, etc.), that are
 * connected to the Type-C connectors, can use these callbacks to inform the
 * Type-C connector class about connections and disconnections. That information
 * can then be used by the typec-port drivers to power on or off parts that are
 * needed or not needed - as an example, in USB mode if USB2 device is
 * enumerated, USB3 components (retimers, phys, and what have you) do not need
 * to be powered on.
 *
 * The attached (enumerated) devices will be liked with the typec-partner device.
 */
struct typec_connector {
	void (*attach)(struct typec_connector *con, struct device *dev);
	void (*deattach)(struct typec_connector *con, struct device *dev);
};

static inline void typec_attach(struct typec_connector *con, struct device *dev)
{
	if (con && con->attach)
		con->attach(con, dev);
}

static inline void typec_deattach(struct typec_connector *con, struct device *dev)
{
	if (con && con->deattach)
		con->deattach(con, dev);
}

#endif /* __LINUX_USB_TYPEC_H */

"""Workflow API endpoints - Execute predefined multi-tool workflows"""

from fastapi import APIRouter, HTTPException
import sys
import json
from pathlib import Path
from datetime import datetime, timedelta

sys.path.insert(0, str(Path(__file__).parent.parent.parent / 'lib'))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / 'orchestrator'))

from api.models.workflows import (
    WorkflowInfo,
    WorkflowExecuteRequest,
    WorkflowExecuteResponse,
    WorkflowExecution,
    WorkflowListResponse,
    WorkflowHistoryResponse
)

router = APIRouter(prefix="/api/workflows", tags=["workflows"])


def _workflow_info_from_definition(wf: dict, fallback_id: str | None = None) -> WorkflowInfo:
    workflow_id = wf.get("id") or fallback_id or "unknown"

    tools_used = []
    for step in wf.get("steps", []):
        tool = step.get("tool")
        if tool and tool not in tools_used:
            tools_used.append(tool)

    explicit_triggers = wf.get("triggers", {}).get("explicit", [])
    primary_trigger = explicit_triggers[0] if explicit_triggers else f"/{workflow_id}"

    variables = wf.get("variables", {})
    requires_input = any(
        isinstance(v, dict) and v.get("extract") == "main_subject"
        for v in variables.values()
    )

    return WorkflowInfo(
        id=workflow_id,
        name=wf.get("name", workflow_id),
        description=wf.get("description"),
        trigger=primary_trigger,
        triggers=explicit_triggers if explicit_triggers else [f"/{workflow_id}"],
        requires_input=requires_input,
        version=wf.get("version"),
        tools_used=tools_used,
    )


def _resolve_workflow(loader, workflow_id: str) -> dict | None:
    workflow = loader.get_workflow(workflow_id)
    if workflow:
        return workflow

    search_trigger = workflow_id if workflow_id.startswith("/") else f"/{workflow_id}"
    for candidate in loader.workflows.values():
        triggers = candidate.get("triggers", {}).get("explicit", [])
        if search_trigger in triggers or workflow_id in triggers:
            return candidate
    return None


def get_workflow_logs(limit: int = 20, workflow_id: str | None = None, days: int = 7) -> list:
    """Get recent workflow execution logs from JSONL files."""
    logs_dir = Path(__file__).parent.parent.parent / "logs"
    workflow_logs = []
    
    cutoff_date = datetime.now() - timedelta(days=days)
    
    for log_file in sorted(logs_dir.glob("workflows-*.jsonl"), reverse=True):
        try:
            date_str = log_file.stem.replace("workflows-", "")
            file_date = datetime.strptime(date_str, "%Y-%m-%d")
            if file_date < cutoff_date:
                continue
        except ValueError:
            continue
        
        try:
            with open(log_file, 'r') as f:
                for line in f:
                    if line.strip():
                        try:
                            entry = json.loads(line)
                            if workflow_id and entry.get('workflow_id') != workflow_id:
                                continue
                            workflow_logs.append(entry)
                        except json.JSONDecodeError:
                            continue
        except IOError:
            continue
    
    workflow_logs.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
    return workflow_logs[:limit]


@router.get("", response_model=WorkflowListResponse)
@router.get("/", response_model=WorkflowListResponse, include_in_schema=False)
async def list_workflows():
    """
    List all available workflows.
    
    Workflows are predefined multi-tool pipelines triggered by commands like `/crypto`, `/research`.
    They execute deterministically without LLM routing decisions.
    
    **Use cases**:
    - Discover available automation workflows
    - Get workflow IDs for execution
    - See what tools each workflow uses
    """
    try:
        from config_loader import get_active_config_mode
        from tool_schema import get_tool_registry
        from workflow_availability import check_workflow_registry_availability
        from workflow_loader import WorkflowLoader
        
        loader = WorkflowLoader(explicit_only=True)
        registry = get_tool_registry(mode=get_active_config_mode())
        workflows = [
            _workflow_info_from_definition(wf, workflow_id)
            for workflow_id, wf in loader.workflows.items()
            if check_workflow_registry_availability(wf, registry)["available"]
        ]
        
        return WorkflowListResponse(
            workflows=workflows,
            count=len(workflows)
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/history", response_model=WorkflowHistoryResponse)
async def get_workflow_history(
    limit: int = 20,
    workflow_id: str | None = None,
    days: int = 7
):
    """
    Get recent workflow execution history.
    
    **Parameters**:
    - `limit`: Maximum executions to return (default: 20)
    - `workflow_id`: Filter by specific workflow (e.g., 'crypto_market_report')
    - `days`: How many days back to search (default: 7)
    
    **Use cases**:
    - Monitor workflow success/failure rates
    - Debug failed workflow executions
    - Track execution times
    """
    try:
        logs = get_workflow_logs(limit=limit, workflow_id=workflow_id, days=days)
        
        executions = []
        success_count = 0
        failure_count = 0
        
        for log in logs:
            result = log.get('result', {})
            ok = result.get('ok', False)
            
            if ok:
                success_count += 1
            else:
                failure_count += 1
            
            executions.append(WorkflowExecution(
                timestamp=log.get('timestamp', ''),
                workflow_id=log.get('workflow_id', 'unknown'),
                workflow_name=log.get('workflow_name'),
                user_query=log.get('user_query'),
                ok=ok,
                speech=result.get('speech'),
                steps_completed=result.get('steps_completed', 0),
                tools_used=result.get('tools_used', []),
                duration_ms=log.get('duration_ms', 0)
            ))
        
        return WorkflowHistoryResponse(
            executions=executions,
            count=len(executions),
            success_count=success_count,
            failure_count=failure_count
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{workflow_id}", response_model=WorkflowInfo)
async def get_workflow(workflow_id: str):
    """
    Get details about a specific workflow.
    
    **Parameters**:
    - `workflow_id`: The workflow ID (e.g., 'crypto_market_report', 'web_archive')
    """
    try:
        from config_loader import get_active_config_mode
        from tool_schema import get_tool_registry
        from workflow_availability import (
            check_workflow_registry_availability,
            workflow_unavailable_message,
        )
        from workflow_loader import WorkflowLoader
        
        loader = WorkflowLoader(explicit_only=True)
        wf = _resolve_workflow(loader, workflow_id)
        if not wf:
            raise HTTPException(status_code=404, detail=f"Workflow '{workflow_id}' not found")
        availability = check_workflow_registry_availability(
            wf,
            get_tool_registry(mode=get_active_config_mode()),
        )
        if not availability["available"]:
            raise HTTPException(
                status_code=409,
                detail=workflow_unavailable_message(wf, availability),
            )
        
        return _workflow_info_from_definition(wf, workflow_id)
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{workflow_id}/execute", response_model=WorkflowExecuteResponse)
async def execute_workflow(workflow_id: str, request: WorkflowExecuteRequest = None):
    """
    Execute a workflow by ID.
    
    **Parameters**:
    - `workflow_id`: The workflow to execute (e.g., 'crypto_market_report')
    - `query`: Optional parameters to pass (e.g., 'ethereum solana' for crypto workflow)
    - `mode`: LLM mode for any LLM-powered steps ('cloud' or 'local')
    
    **Example**:
    ```bash
    # Default crypto report (Bitcoin, Solana)
    curl -X POST http://localhost:8880/api/workflows/crypto_market_report/execute
    
    # Custom coins
    curl -X POST http://localhost:8880/api/workflows/crypto_market_report/execute \\
      -H "Content-Type: application/json" \\
      -d '{"query": "ethereum xrp"}'
    ```
    
    **Note**: Workflow execution can take 30-120+ seconds depending on the workflow.
    """
    if request is None:
        request = WorkflowExecuteRequest()

    from config_loader import config_scope
    with config_scope(request.mode):
        return await _execute_workflow_scoped(workflow_id, request)


async def _execute_workflow_scoped(workflow_id: str, request: WorkflowExecuteRequest):
    """Execute one workflow inside its immutable mode/config scope."""
    import time

    try:
        # Load workflow
        from workflow_loader import WorkflowLoader

        loader = WorkflowLoader(explicit_only=True)
        workflow = _resolve_workflow(loader, workflow_id)
        if not workflow:
            available = []
            for wf in loader.workflows.values():
                triggers = wf.get("triggers", {}).get("explicit", [])
                available.append(f"{wf.get('id')} (triggers: {', '.join(triggers) or 'none'})")
            raise HTTPException(
                status_code=404,
                detail=f"Workflow '{workflow_id}' not found. Available: {'; '.join(available[:5])}"
            )

        from tool_schema import get_tool_registry
        from workflow_availability import (
            check_workflow_registry_availability,
            workflow_unavailable_message,
        )

        registry = get_tool_registry(mode=request.mode)
        availability = check_workflow_registry_availability(workflow, registry)
        if not availability["available"]:
            raise HTTPException(
                status_code=409,
                detail=workflow_unavailable_message(workflow, availability),
            )
        
        # Build transcript (trigger + optional query)
        # Use first explicit trigger if available, otherwise fall back to /{workflow_id}
        explicit_triggers = workflow.get("triggers", {}).get("explicit", [])
        all_triggers = explicit_triggers + [f"/{workflow_id}"]
        trigger = explicit_triggers[0] if explicit_triggers else f"/{workflow_id}"
        
        # Clean up query - remove trigger prefix if user accidentally included it
        query = request.query.strip() if request.query else ""
        for t in all_triggers:
            if query.lower().startswith(t.lower()):
                query = query[len(t):].strip()
                break
        
        # Check if workflow requires a topic/query
        variables = workflow.get("variables", {})
        requires_topic = any(
            isinstance(v, dict) and v.get("extract") == "main_subject" 
            for v in variables.values()
        )
        
        if requires_topic and not query:
            # Return helpful error for workflows that need input
            raise HTTPException(
                status_code=400,
                detail={
                    "error": f"Workflow '{workflow_id}' requires a topic/query parameter",
                    "hint": f"Example: POST /api/workflows/{workflow_id}/execute with body: {{\"query\": \"your topic here\"}}",
                    "workflow_description": workflow.get("description", "")
                }
            )
        
        if query:
            transcript = f"{trigger} {query}"
        else:
            transcript = trigger
        
        # Import and execute
        from executor import ToolExecutor
        from pipeline_executor import PipelineExecutor
        
        executor = ToolExecutor(mode=request.mode, registry=registry)
        pipeline = PipelineExecutor(request.mode, executor)
        
        start_time = time.time()
        result = pipeline.execute(workflow, transcript)
        duration_ms = (time.time() - start_time) * 1000
        
        return WorkflowExecuteResponse(
            ok=result.get("ok", False),
            workflow_id=workflow_id,
            speech=result.get("speech"),
            tools_used=result.get("tools_used", []),
            steps_completed=result.get("steps_completed", 0),
            duration_ms=duration_ms,
            data=result.get("data"),
            usage=result.get("usage"),
            server_side_tools=result.get("server_side_tools"),
            error=result.get("error")
        )
        
    except HTTPException:
        raise
    except Exception as e:
        return WorkflowExecuteResponse(
            ok=False,
            workflow_id=workflow_id,
            error=str(e)
        )

"""Scheduled task management business logic"""

import json
import os
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).parent.parent.parent / 'lib'))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / 'orchestrator'))
from config_loader import config_scope, load_config, get_config_value, get_active_config_mode
from memory_db import get_memory_db
from schedule_parser import calculate_next_run, parse_schedule_expression
from time_utils import format_utc_db, now_utc
from workflow_loader import WorkflowLoader


class ScheduledTaskManager:
    """Manages scheduled tasks and run history."""

    RUN_ONCE_PENDING_STATUS = 'run_once_pending'

    def __init__(self, mode: str | None = None):
        if not mode:
            mode = os.environ.get('JARVIS_API_MODE')

        if mode:
            load_config(mode)
            self.mode = mode
        else:
            load_config()
            self.mode = get_active_config_mode()

        self.db = get_memory_db(self.mode)
        self._ensure_tables()

    def _ensure_tables(self):
        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS scheduled_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                enabled BOOLEAN DEFAULT 1,
                task_type TEXT NOT NULL,
                task_target TEXT,
                task_payload TEXT,
                schedule_type TEXT NOT NULL,
                schedule_expr TEXT NOT NULL,
                timezone TEXT DEFAULT 'America/Los_Angeles',
                mode TEXT DEFAULT 'cloud',
                allow_overlap BOOLEAN DEFAULT 0,
                max_retries INTEGER DEFAULT 1,
                timeout_seconds INTEGER DEFAULT 300,
                last_run_at TEXT,
                next_run_at TEXT,
                last_status TEXT,
                last_error TEXT,
                last_duration_ms REAL,
                last_result_summary TEXT,
                lock_owner TEXT,
                lock_acquired_at TEXT,
                metadata TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS scheduled_task_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                started_at TEXT NOT NULL,
                finished_at TEXT,
                status TEXT NOT NULL,
                mode TEXT,
                provider TEXT,
                model TEXT,
                workflow_id TEXT,
                tools_used TEXT,
                speech TEXT,
                raw_llm_response TEXT,
                result_data TEXT,
                error TEXT,
                duration_ms REAL,
                completion_guard_applied BOOLEAN DEFAULT 0,
                feedback_collected BOOLEAN DEFAULT 0,
                metadata TEXT,
                FOREIGN KEY(task_id) REFERENCES scheduled_tasks(id)
            )
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_scheduled_tasks_next_run ON scheduled_tasks(enabled, next_run_at)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_scheduled_tasks_mode ON scheduled_tasks(mode)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_scheduled_task_runs_task ON scheduled_task_runs(task_id, started_at DESC)")
        conn.commit()
        conn.close()

    def _resolve_workflow_id(self, workflow_id: str, *, mode: str | None = None) -> str:
        """Resolve a workflow by exact ID or explicit trigger alias like /crypto."""
        if not workflow_id:
            raise ValueError("workflow_id is required for workflow scheduled tasks")

        loader = WorkflowLoader(explicit_only=True)
        workflow = loader.get_workflow(workflow_id)
        if not workflow:
            normalized = workflow_id if workflow_id.startswith("/") else f"/{workflow_id}"
            for candidate in loader.workflows.values():
                explicit = candidate.get("triggers", {}).get("explicit", [])
                if workflow_id in explicit or normalized in explicit:
                    workflow = candidate
                    break

        if not workflow:
            raise ValueError(f"Workflow '{workflow_id}' not found")

        from tool_schema import get_tool_registry
        from workflow_availability import (
            check_workflow_registry_availability,
            workflow_unavailable_message,
        )

        execution_mode = mode or self.mode
        with config_scope(execution_mode):
            availability = check_workflow_registry_availability(
                workflow,
                get_tool_registry(mode=execution_mode),
            )
        if not availability["available"]:
            raise ValueError(workflow_unavailable_message(workflow, availability))
        return workflow["id"]

    def create_task(self, *, name: str, task_type: str, query: str | None = None,
                    workflow_id: str | None = None, when: str, timezone_name: str | None = None,
                    mode: str | None = None, enabled: bool = True, allow_overlap: bool = False,
                    max_retries: int = 1, timeout_seconds: int = 300,
                    metadata: dict[str, Any] | None = None) -> int:
        mode = mode or self.mode
        if mode != self.mode:
            raise ValueError(
                f"This scheduler belongs to {self.mode} mode and cannot create a {mode} task"
            )
        timezone_name = timezone_name or get_config_value("JARVIS_TIMEZONE", "America/Los_Angeles")
        schedule = parse_schedule_expression(when, tz_name=timezone_name)

        if task_type == 'query' and not query:
            raise ValueError("query is required for query scheduled tasks")
        if task_type == 'workflow' and not workflow_id:
            raise ValueError("workflow_id is required for workflow scheduled tasks")
        if task_type == 'workflow':
            workflow_id = self._resolve_workflow_id(workflow_id, mode=mode)

        payload = {"query": query} if task_type == 'query' else {"workflow_id": workflow_id}
        if task_type == 'workflow' and query:
            payload["query"] = query
        payload["when_original"] = when
        payload["schedule_summary"] = schedule["summary"]

        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        now = datetime.now().isoformat()
        cursor.execute("""
            INSERT INTO scheduled_tasks (
                name, enabled, task_type, task_target, task_payload,
                schedule_type, schedule_expr, timezone, mode,
                allow_overlap, max_retries, timeout_seconds,
                next_run_at, metadata, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            name,
            1 if enabled else 0,
            task_type,
            workflow_id if task_type == 'workflow' else None,
            json.dumps(payload),
            schedule["schedule_type"],
            json.dumps(schedule["schedule_expr"]),
            timezone_name,
            mode,
            1 if allow_overlap else 0,
            max_retries,
            timeout_seconds,
            schedule["next_run_at"],
            json.dumps(metadata or {}),
            now,
            now,
        ))
        task_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return task_id

    def get_task(self, task_id: int) -> dict[str, Any] | None:
        conn = sqlite3.connect(self.db.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        row = cursor.execute(
            "SELECT * FROM scheduled_tasks WHERE id = ? AND mode = ?",
            (task_id, self.mode),
        ).fetchone()
        conn.close()
        return dict(row) if row else None

    def list_tasks(self, status: str = 'all', limit: int = 100) -> list[dict[str, Any]]:
        conn = sqlite3.connect(self.db.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        query = "SELECT * FROM scheduled_tasks WHERE mode = ?"
        params: list[Any] = [self.mode]
        if status == 'enabled':
            query += " AND enabled = 1"
        elif status == 'disabled':
            query += " AND enabled = 0"
        query += " ORDER BY next_run_at ASC, id DESC LIMIT ?"
        params.append(limit)
        rows = cursor.execute(query, params).fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def update_task(self, task_id: int, **updates) -> bool:
        existing = self.get_task(task_id)
        if not existing:
            return False

        fields: dict[str, Any] = {}
        timezone_name = updates.get('timezone') or existing['timezone']
        task_payload = json.loads(existing['task_payload'] or "{}")
        schedule_changed = updates.get('when') is not None and (
            updates['when'] != task_payload.get('when_original')
            or timezone_name != existing['timezone']
        )
        if updates.get('name') is not None:
            fields['name'] = updates['name']
        if updates.get('enabled') is not None:
            fields['enabled'] = 1 if updates['enabled'] else 0
            if updates['enabled'] and not existing.get('enabled'):
                if existing.get('last_status') == self.RUN_ONCE_PENDING_STATUS:
                    fields['last_status'] = None
                    if not schedule_changed:
                        expr = json.loads(existing['schedule_expr'])
                        fields['next_run_at'] = calculate_next_run(
                            existing['schedule_type'], expr, tz_name=timezone_name
                        )
                elif not schedule_changed and not existing.get('next_run_at'):
                    if existing.get('schedule_type') != 'once':
                        expr = json.loads(existing['schedule_expr'])
                        fields['next_run_at'] = calculate_next_run(
                            existing['schedule_type'], expr, tz_name=timezone_name
                        )
        if updates.get('allow_overlap') is not None:
            fields['allow_overlap'] = 1 if updates['allow_overlap'] else 0
        if updates.get('max_retries') is not None:
            fields['max_retries'] = updates['max_retries']
        if updates.get('timeout_seconds') is not None:
            fields['timeout_seconds'] = updates['timeout_seconds']
        if updates.get('mode') is not None and updates['mode'] != self.mode:
            raise ValueError(
                f"This scheduler belongs to {self.mode} mode and cannot move a task to {updates['mode']}"
            )

        if updates.get('timezone') is not None:
            fields['timezone'] = timezone_name

        if existing['task_type'] in {'query', 'workflow'} and updates.get('query') is not None:
            task_payload['query'] = updates['query']
        if existing['task_type'] == 'workflow' and (
            updates.get('workflow_id') is not None
            or updates.get('mode') is not None
        ):
            requested_workflow_id = (
                updates.get('workflow_id')
                or task_payload.get('workflow_id')
                or existing.get('task_target')
            )
            resolved_workflow_id = self._resolve_workflow_id(
                requested_workflow_id,
                mode=updates.get('mode') or existing['mode'],
            )
            if updates.get('workflow_id') is not None:
                fields['task_target'] = resolved_workflow_id
                task_payload['workflow_id'] = resolved_workflow_id

        if updates.get('metadata') is not None:
            fields['metadata'] = json.dumps(updates['metadata'])

        # Forms resend the schedule during notification edits; keep its existing slot.
        if schedule_changed:
            schedule = parse_schedule_expression(updates['when'], tz_name=timezone_name)
            fields['schedule_type'] = schedule['schedule_type']
            fields['schedule_expr'] = json.dumps(schedule['schedule_expr'])
            fields['next_run_at'] = schedule['next_run_at']
            task_payload['when_original'] = updates['when']
            task_payload['schedule_summary'] = schedule['summary']

        if task_payload != json.loads(existing['task_payload'] or "{}"):
            fields['task_payload'] = json.dumps(task_payload)

        if not fields:
            return True

        fields['updated_at'] = datetime.now().isoformat()
        clauses = ", ".join(f"{key} = ?" for key in fields)
        values = list(fields.values()) + [task_id]

        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        cursor.execute(f"UPDATE scheduled_tasks SET {clauses} WHERE id = ?", values)
        conn.commit()
        updated = cursor.rowcount > 0
        conn.close()
        return updated

    def cancel_task(self, task_id: int) -> bool:
        existing = self.get_task(task_id)
        if not existing:
            return False

        now = datetime.now().isoformat()
        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        if existing.get('last_status') == self.RUN_ONCE_PENDING_STATUS:
            cursor.execute("""
                UPDATE scheduled_tasks
                SET enabled = 0, last_status = 'cancelled', next_run_at = NULL, updated_at = ?
                WHERE id = ?
            """, (now, task_id))
        else:
            cursor.execute("""
                UPDATE scheduled_tasks
                SET enabled = 0, last_status = 'cancelled', updated_at = ?
                WHERE id = ?
            """, (now, task_id))
        conn.commit()
        updated = cursor.rowcount > 0
        conn.close()
        return updated

    def delete_task(self, task_id: int) -> bool:
        if not self.get_task(task_id):
            return False

        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM scheduled_task_runs WHERE task_id = ?", (task_id,))
        cursor.execute("DELETE FROM scheduled_tasks WHERE id = ?", (task_id,))
        conn.commit()
        deleted = cursor.rowcount > 0
        conn.close()
        return deleted

    def is_manual_run_once(self, task: dict[str, Any]) -> bool:
        return task.get('last_status') == self.RUN_ONCE_PENDING_STATUS

    def run_now(self, task_id: int) -> bool:
        task = self.get_task(task_id)
        if not task:
            return False

        now = format_utc_db(now_utc())
        updated_at = datetime.now().isoformat()
        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        if not task.get('enabled'):
            cursor.execute("""
                UPDATE scheduled_tasks
                SET last_status = ?,
                    next_run_at = ?,
                    updated_at = ?
                WHERE id = ?
            """, (self.RUN_ONCE_PENDING_STATUS, now, updated_at, task_id))
        else:
            cursor.execute("""
                UPDATE scheduled_tasks
                SET enabled = 1,
                    next_run_at = ?,
                    updated_at = ?
                WHERE id = ?
            """, (now, updated_at, task_id))
        conn.commit()
        updated = cursor.rowcount > 0
        conn.close()
        return updated

    def skip_missed_tasks(
        self,
        *,
        now_utc_value: datetime | None = None,
        grace_seconds: int = 300,
    ) -> list[dict[str, Any]]:
        """Skip overdue scheduled occurrences instead of replaying them after downtime."""
        current_utc = now_utc_value or now_utc()
        grace_seconds = max(0, int(grace_seconds))
        cutoff = format_utc_db(current_utc - timedelta(seconds=grace_seconds))
        current_text = format_utc_db(current_utc)
        updated_at = datetime.now().isoformat()

        conn = sqlite3.connect(self.db.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        rows = cursor.execute("""
            SELECT * FROM scheduled_tasks
            WHERE mode = ?
              AND enabled = 1
              AND next_run_at IS NOT NULL
              AND next_run_at < ?
              AND (lock_owner IS NULL OR lock_owner = '')
              AND (last_status IS NULL OR last_status != ?)
            ORDER BY next_run_at ASC
        """, (self.mode, cutoff, self.RUN_ONCE_PENDING_STATUS)).fetchall()

        skipped: list[dict[str, Any]] = []
        for row in rows:
            task = dict(row)
            if task['schedule_type'] == 'once':
                next_run_at = None
                enabled = 0
            else:
                expr = json.loads(task['schedule_expr'])
                next_run_at = calculate_next_run(
                    task['schedule_type'],
                    expr,
                    from_utc=current_text,
                    tz_name=task['timezone'],
                )
                enabled = 1

            cursor.execute("""
                UPDATE scheduled_tasks
                SET enabled = ?,
                    next_run_at = ?,
                    last_status = 'missed',
                    last_error = NULL,
                    updated_at = ?
                WHERE id = ?
                  AND mode = ?
                  AND next_run_at = ?
            """, (
                enabled,
                next_run_at,
                updated_at,
                task['id'],
                self.mode,
                task['next_run_at'],
            ))
            if cursor.rowcount:
                skipped.append({
                    "task_id": task['id'],
                    "name": task['name'],
                    "scheduled_for": task['next_run_at'],
                    "next_run_at": next_run_at,
                })

        conn.commit()
        conn.close()
        return skipped

    def get_due_tasks(self, limit: int = 20) -> list[dict[str, Any]]:
        conn = sqlite3.connect(self.db.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        now = format_utc_db(now_utc())
        rows = cursor.execute("""
            SELECT * FROM scheduled_tasks
            WHERE mode = ?
              AND next_run_at IS NOT NULL
              AND next_run_at <= ?
              AND (lock_owner IS NULL OR lock_owner = '')
              AND (enabled = 1 OR last_status = ?)
            ORDER BY next_run_at ASC
            LIMIT ?
        """, (self.mode, now, self.RUN_ONCE_PENDING_STATUS, limit)).fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def acquire_lock(self, task_id: int, owner: str) -> bool:
        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        now = datetime.now().isoformat()
        cursor.execute("""
            UPDATE scheduled_tasks
            SET lock_owner = ?, lock_acquired_at = ?, last_status = 'running', updated_at = ?
            WHERE id = ?
              AND mode = ?
              AND (lock_owner IS NULL OR lock_owner = '')
        """, (owner, now, now, task_id, self.mode))
        conn.commit()
        ok = cursor.rowcount > 0
        conn.close()
        return ok

    def list_locked_tasks(self) -> list[dict[str, Any]]:
        """Return locks owned by runners for this manager's execution mode."""
        conn = sqlite3.connect(self.db.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        rows = cursor.execute("""
            SELECT id, name, lock_owner, lock_acquired_at
            FROM scheduled_tasks
            WHERE mode = ?
              AND lock_owner IS NOT NULL
              AND lock_owner != ''
            ORDER BY id
        """, (self.mode,)).fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def release_abandoned_lock(self, task_id: int, owner: str, *, reason: str) -> bool:
        """Release one lock only if it is still owned by the crashed runner."""
        now = datetime.now().isoformat()
        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE scheduled_tasks
            SET lock_owner = NULL,
                lock_acquired_at = NULL,
                last_status = 'failure',
                last_error = ?,
                updated_at = ?
            WHERE id = ? AND lock_owner = ?
        """, (reason, now, task_id, owner))
        released = cursor.rowcount > 0
        if released:
            cursor.execute("""
                UPDATE scheduled_task_runs
                SET finished_at = ?,
                    status = 'failure',
                    error = CASE
                        WHEN error IS NULL OR error = '' THEN ?
                        ELSE error
                    END
                WHERE task_id = ?
                  AND status = 'running'
                  AND finished_at IS NULL
            """, (now, reason, task_id))
        conn.commit()
        conn.close()
        return released

    def fail_run_and_release_lock(
        self,
        task_id: int,
        run_id: int,
        owner: str,
        *,
        reason: str,
        duration_ms: float | None = None,
        summary: str | None = None,
        next_run_at: str | None = None,
    ) -> bool:
        """Atomically fail an unfinished run and release its owned task lock."""
        now = datetime.now().isoformat()
        conn = sqlite3.connect(self.db.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE scheduled_tasks
                SET lock_owner = NULL,
                    lock_acquired_at = NULL,
                    last_run_at = ?,
                    next_run_at = ?,
                    last_status = 'failure',
                    last_error = ?,
                    last_duration_ms = ?,
                    last_result_summary = ?,
                    updated_at = ?
                WHERE id = ?
                  AND mode = ?
                  AND lock_owner = ?
            """, (
                now,
                next_run_at,
                reason,
                duration_ms,
                summary,
                now,
                task_id,
                self.mode,
                owner,
            ))
            released = cursor.rowcount > 0
            if released:
                cursor.execute("""
                    UPDATE scheduled_task_runs
                    SET finished_at = ?,
                        status = 'failure',
                        error = ?,
                        duration_ms = COALESCE(?, duration_ms)
                    WHERE id = ?
                      AND task_id = ?
                      AND status = 'running'
                      AND finished_at IS NULL
                """, (now, reason, duration_ms, run_id, task_id))
            conn.commit()
            return released
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def release_lock_and_update(self, task_id: int, *, status: str, error: str | None = None,
                                duration_ms: float | None = None, summary: str | None = None,
                                next_run_at: str | None = None):
        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE scheduled_tasks
            SET lock_owner = NULL,
                lock_acquired_at = NULL,
                last_run_at = ?,
                next_run_at = ?,
                last_status = ?,
                last_error = ?,
                last_duration_ms = ?,
                last_result_summary = ?,
                updated_at = ?
            WHERE id = ?
        """, (
            datetime.now().isoformat(),
            next_run_at,
            status,
            error,
            duration_ms,
            summary,
            datetime.now().isoformat(),
            task_id
        ))
        conn.commit()
        conn.close()

    def create_run(self, task_id: int, *, status: str = 'running', metadata: dict[str, Any] | None = None) -> int:
        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO scheduled_task_runs (task_id, started_at, status, metadata)
            VALUES (?, ?, ?, ?)
        """, (task_id, datetime.now().isoformat(), status, json.dumps(metadata or {})))
        run_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return run_id

    def finish_run(self, run_id: int, *, status: str, mode: str | None = None, provider: str | None = None,
                   model: str | None = None, workflow_id: str | None = None, tools_used: list[str] | None = None,
                   speech: str | None = None, raw_llm_response: str | None = None,
                   result_data: dict[str, Any] | None = None, error: str | None = None,
                   duration_ms: float | None = None, completion_guard_applied: bool = False,
                   feedback_collected: bool = False, metadata: dict[str, Any] | None = None):
        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE scheduled_task_runs
            SET finished_at = ?, status = ?, mode = ?, provider = ?, model = ?, workflow_id = ?,
                tools_used = ?, speech = ?, raw_llm_response = ?, result_data = ?, error = ?,
                duration_ms = ?, completion_guard_applied = ?, feedback_collected = ?, metadata = ?
            WHERE id = ?
        """, (
            datetime.now().isoformat(),
            status,
            mode,
            provider,
            model,
            workflow_id,
            json.dumps(tools_used or []),
            speech,
            raw_llm_response,
            json.dumps(result_data or {}),
            error,
            duration_ms,
            1 if completion_guard_applied else 0,
            1 if feedback_collected else 0,
            json.dumps(metadata or {}),
            run_id
        ))
        conn.commit()
        conn.close()

    def list_runs(self, task_id: int, limit: int = 20) -> list[dict[str, Any]]:
        if not self.get_task(task_id):
            return []

        conn = sqlite3.connect(self.db.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        rows = cursor.execute("""
            SELECT * FROM scheduled_task_runs
            WHERE task_id = ?
            ORDER BY started_at DESC
            LIMIT ?
        """, (task_id, limit)).fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def calculate_followup_next_run(self, task: dict[str, Any], reference_utc: str | None = None) -> str | None:
        if task.get('schedule_type') == 'once':
            return None
        expr = json.loads(task['schedule_expr'])
        return calculate_next_run(task['schedule_type'], expr, from_utc=reference_utc or task['next_run_at'], tz_name=task['timezone'])

    def resolve_followup_next_run(
        self,
        task: dict[str, Any],
        *,
        reference_utc: str | None = None,
        manual_run_once: bool = False,
    ) -> str | None:
        if manual_run_once:
            return None
        return self.calculate_followup_next_run(task, reference_utc=reference_utc)

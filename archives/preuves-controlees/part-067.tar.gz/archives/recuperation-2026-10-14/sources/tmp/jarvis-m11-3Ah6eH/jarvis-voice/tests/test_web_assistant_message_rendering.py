"""Exercise the real assistant-message entry point with browser I/O isolated."""

import json
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]

HARNESS = r"""
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const effects = [], timers = [];
const escape = value => String(value).replaceAll('&', '&amp;')
  .replaceAll('<', '&lt;').replaceAll('>', '&gt;');
// Only the DOM operations used by message insertion and its disclosure buttons.
// Result selection, HTML generation, IDs and pending-tool cleanup are production code.
class Element {
  constructor() {
    this.children = []; this.dataset = {}; this.style = {}; this.events = {};
    this.className = ''; this._html = ''; this.parentElement = null;
    this.classList = {
      contains: name => this.className.split(' ').includes(name),
      add: name => { if (!this.classList.contains(name)) this.className += ' ' + name; },
      remove: name => { this.className = this.className.split(' ').filter(x => x !== name).join(' '); },
      toggle: name => this.classList.contains(name) ? this.classList.remove(name) : this.classList.add(name)
    };
  }
  set textContent(value) { this._text = value; this._html = escape(value); }
  get textContent() { return this._text || ''; }
  set innerHTML(value) {
    this._html = value; this.parts = {};
    this.headers = [...value.matchAll(/<div class="tool-card ([^"]*)">/g)].map(match => {
      const card = new Element(), header = new Element();
      card.className = 'tool-card ' + match[1]; header.parentElement = card;
      return header;
    });
    this.convertedImages = [...value.matchAll(/<div\b[^>]*data-converted-image-url="([^"]*)"/g)].map(match => {
      const image = new Element();
      image.dataset.convertedImageUrl = match[1].replace(/&(?:amp|quot|#39|lt|gt);/g,
        entity => ({'&amp;':'&', '&quot;':'"', '&#39;':"'", '&lt;':'<', '&gt;':'>'}[entity]));
      return image;
    });
    if (value.includes('class="details-toggle"')) {
      const details = new Element(), toggle = new Element();
      details.className = 'message-details collapsed'; toggle.parentElement = details;
      toggle.parts = {'.toggle-icon': new Element(), '.toggle-text': new Element()};
      this.parts['.details-toggle'] = toggle;
    }
  }
  get innerHTML() { return this._html; }
  querySelector(selector) { return this.parts?.[selector] || null; }
  querySelectorAll(selector) {
    if (selector === 'button') return this.children;
    if (selector === '.tool-card-header') return this.headers || [];
    if (selector === '.message-image.converted-file[data-converted-image-url]') return this.convertedImages || [];
    return [];
  }
  closest() { return this.parentElement; }
  addEventListener(name, handler) { this.events[name] = handler; }
  appendChild(child) { this.children.push(child); child.parentElement = this; child.isConnected = true; effects.push('append'); }
  append(...children) { children.forEach(child => this.appendChild(child)); }
  get nextSibling() { const siblings = this.parentElement?.children || []; return siblings[siblings.indexOf(this) + 1] || null; }
  insertBefore(child, before) { const index = before ? this.children.indexOf(before) : -1; if (index < 0) this.children.push(child); else this.children.splice(index, 0, child); child.parentElement = this; child.isConnected = true; }
  setAttribute(name, value) { this[name] = value; }
  remove() { if (this.parentElement) this.parentElement.children = this.parentElement.children.filter(child => child !== this); this.isConnected = false; }
}
const storage = {getItem: () => null, setItem() {}, removeItem() {}};
const sandbox = {
  console, URL, Event, localStorage: storage,
  // Shipped scripts publish registry updates while their async startup settles.
  document: Object.assign(new EventTarget(), {
    createElement: () => new Element(), querySelectorAll: () => []
  }),
  window: {sessionStorage: storage, location:{origin:'https://jarvis.test'}, addEventListener() {}},
  setTimeout: fn => {timers.push(fn); return timers.length;}, clearTimeout() {},
  setInterval: () => 1, clearInterval() {},
  fetch: async () => ({ok: true, json: async () => ({tools: [], prompts: {}, workflows: {}})})
};
vm.createContext(sandbox);
const clientPath = ROOT + '/jarvis-web/client';
// Use the shipped order so a new renderer dependency must be wired in HTML too.
const html = fs.readFileSync(clientPath + '/index.html', 'utf8');
const scripts = [...html.matchAll(/<script\b[^>]*src="(\/js\/[^"?]+|\/ui-navigation\.js)"[^>]*>/g)].map(m => m[1]);
for (const path of scripts.slice(0, scripts.indexOf('/js/chat.js'))) {
  const sourcePath = path === '/ui-navigation.js' ? ROOT + '/lib/static/ui-navigation.js' : clientPath + path;
  vm.runInContext(fs.readFileSync(sourcePath, 'utf8'), sandbox, {filename: path});
}
const Utils = vm.runInContext('Utils', sandbox);
Utils.hydrateRichContent = () => effects.push('hydrate');
Utils.scrollToBottom = () => effects.push('scroll');
function loadClass(file, name, terminator) {
  const source = fs.readFileSync(clientPath + '/js/' + file, 'utf8');
  return vm.runInContext(source.slice(0, source.lastIndexOf(terminator)) + '\n' + name, sandbox);
}
const ChatUI = loadClass('chat.js', 'ChatUI', '// Create global instance');
const JarvisApp = loadClass('app.js', 'JarvisApp', '// Initialize app');
const socket = sandbox.window.jarvisSocket;
socket.conversationId = 'thread';
function chat() {
  const ui = Object.create(ChatUI.prototype);
  Object.assign(ui, {
    messagesContainer: new Element(), pendingTools: {}, pendingToolsByMessage: new Map(),
    pendingToolMessageId: null, chatOnlyEnabled: false,
    _clearMessageResponseActions: () => effects.push('clear-actions'),
    _attachCompletionGuardCard: (_el, data) => effects.push(['guard', data.completion_guard]),
    _attachMessageResponseActions: (_el, text, _data, options) => effects.push(['actions', text, options]),
    _hydrateCanvasPreview: () => effects.push('canvas-hydrate')
  });
  return ui;
}
function message(ui) { return ui.messagesContainer.children.at(-1); }
function render(ui, text, tools, payload, live = true, options = {}) {
  const data = live
    ? {message_id: 'answer', conversation_id: 'thread', data: payload}
    : {...payload, _web_message_id: 'answer'};
  ui._activatePendingToolsForMessage('answer');
  ui.addAssistantMessage(text, tools, data, options);
  return message(ui).innerHTML;
}
"""


def run_message_browser(body: str) -> None:
    script = f"const ROOT = {json.dumps(str(ROOT))};\n" + HARNESS
    script += "\n(async () => {\n" + body + "\n})().catch(error => {console.error(error); process.exit(1);});"
    result = subprocess.run(["node", "-e", script], cwd=ROOT, capture_output=True, text=True, timeout=15)
    assert result.returncode == 0, result.stdout + result.stderr


def test_shipped_command_registry_load_dispatches_document_event():
    run_message_browser(r"""
const updates = [];
sandbox.document.addEventListener('jarvis:commands-updated', event => updates.push(event));
const commands = sandbox.window.commandSystem;
await commands.refreshTools('local');
assert.equal(commands.loaded, true);
assert.equal(updates.length, 1);
assert.ok(updates[0] instanceof Event);
assert.equal(updates[0].target, sandbox.document);
""")


def test_web_approval_card_shows_prepared_call_and_sends_one_denial():
    run_message_browser(r"""
const ui = chat();
const sent = [];
sandbox.window.jarvisSocket = {connected: true, conversationId: 'thread', emit: (...args) => sent.push(args)};
ui.currentMessageId = 'turn';
const owner = sandbox.document.createElement('div'); owner.className = 'message user'; owner.dataset.requestId = 'turn';
const next = sandbox.document.createElement('div'); next.className = 'message user'; next.dataset.requestId = 'other';
ui.messagesContainer.append(owner, next);
const approval = {approval_id: 'once', conversation_id: 'thread', message_id: 'turn',
  tool: 'api_call', summary: 'Send a GET request to <img src=x onerror=alert(1)>?',
  detail: ['Content: safe text'], warning: 'This call may connect to the network.',
  expires_at: Date.now()/1000 + 60, permissions: {network: true, auto_approve: false}};
ui._showToolApproval({...approval, approval_id:'wrong', conversation_id:'other'});
ui._showToolApproval({...approval, approval_id:'wrong', message_id:'other'});
assert.equal(ui.messagesContainer.children.length, 2);
ui._showToolApproval(approval);
const card = ui.messagesContainer.children[1];
assert.equal(ui.messagesContainer.children[2], next);
assert.equal(card.children[0].textContent, approval.summary);
assert.ok(card.children[0].innerHTML.includes('&lt;img'));
assert.equal(card.children[1].textContent, approval.detail[0]);
assert.equal(card.children[2].textContent, approval.warning);
assert.match(card.children[3].textContent, /left to decide/);
assert.ok(!card.children.map(item => item.textContent).join(' ').includes('auto approve'));
card.children[4].children[1].events.click();
assert.equal(JSON.stringify(sent), JSON.stringify([['tool:approval_decide', {approval_id:'once', conversation_id:'thread',
  message_id:'turn', approved:false}]]));
assert.equal(card.children[4].children[0].disabled, true);
ui.pendingToolApproval.decisionPending = false;
sandbox.window.jarvisSocket.connected = false;
ui._approvalUpdateRemaining();
assert.equal(card.children[4].children[0].disabled, true);
sandbox.window.jarvisSocket.connected = true;
ui._approvalUpdateRemaining();
assert.equal(card.children[4].children[0].disabled, false);
ui._clearToolApproval();
assert.equal(ui.messagesContainer.children.length, 2);
ui._showToolApproval({...approval, approval_id:'expired', expires_at: Date.now()/1000 - 1});
const expired = ui.messagesContainer.children[1];
assert.equal(expired.children[4].children[0].disabled, true);
expired.children[4].children[0].events.click();
assert.equal(sent.length, 1);
""")


@pytest.mark.parametrize('live', [True, False])
def test_foreground_openclaw_result_is_visible_in_live_and_saved_tool_cards(live):
    run_message_browser(f'const live = {json.dumps(live)};\n' + r"""
const ui = chat();
const payload = {openclaw: {response: 'Sources: <A>', model: 'openclaw/main', session: 'jarvis-review'}};
const html = render(ui, 'OpenClaw replied.', ['openclaw'], payload, live);
assert.match(html, /Sources: &lt;A&gt;/);
assert.match(html, /jarvis-review/);
assert.ok(!html.includes('<pre class="tool-card-body">{}</pre>'));
""")


@pytest.mark.parametrize("live", [True, False])
@pytest.mark.parametrize("target,tag,mime", [
    ("PNG", "img", None), ("mp4", "video", "video/mp4"),
    ("ogg", "audio", "audio/ogg"), ("pdf", "a", None),
])
def test_converted_result_display_for_live_and_saved_messages(live, target, tag, mime):
    run_message_browser(f"const live = {json.dumps(live)}, target = {json.dumps(target)}, tag = {json.dumps(tag)}, mime = {json.dumps(mime)};\n" + r"""
const ui = chat();
const payload = {convert_file: {stash_ref: 'stash://space_test/f_converted',
  filename: 'Converted <example>.' + target, target_format: target, size_change: '-25%'}};
const before = JSON.stringify(payload);
const html = render(ui, 'Ready', ['convert_file'], payload, live);
assert.ok(html.includes('<' + tag));
assert.ok(html.includes('/api/stash/space_test/f_converted'));
assert.ok(html.includes('Converted &lt;example&gt;'));
assert.ok(html.includes('-25%'));
if (mime) assert.ok(html.includes('type="' + mime + '"'));
assert.equal((html.match(/class="(?:message-image|message-video|message-audio|message-file) converted-file"/g) || []).length, 1);
assert.ok(html.indexOf('converted-file') < html.indexOf('class="message-bubble"'));
assert.equal(JSON.stringify(payload), before);
assert.equal(message(ui).dataset.messageId, 'answer');
assert.equal(message(ui).dataset.conversationId, 'thread');
assert.ok(ui._renderedMessageIds.has('assistant:answer'));
assert.equal(ui.pendingToolsByMessage.has('answer'), false);
assert.deepEqual(effects.filter(x => typeof x === 'string'), ['clear-actions', 'append', 'hydrate', 'scroll']);
""")


def test_missing_invalid_or_unannounced_conversion_has_no_preview():
    run_message_browser(r"""
for (const [tools, result] of [
  [[], {stash_ref:'stash://space_test/f_file', target_format:'png'}],
  [['convert_file'], {}], [['convert_file'], {stash_ref:'invalid'}]
]) {
  const html = render(chat(), 'Ready', tools, {convert_file:result});
  assert.ok(!html.includes('converted-file'));
}
const ui = chat();
ui._activatePendingToolsForMessage('answer');
ui.pendingTools.convert_file_step2 = {toolName:'convert_file',status:'success'};
ui.addAssistantMessage('Ready', [], {message_id:'answer', data:{convert_file:{
  stash_ref:'stash://space_test/f_file',target_format:'png'
}}});
assert.ok(message(ui).innerHTML.includes('converted-file'));
""")


@pytest.mark.parametrize("live", [True, False])
@pytest.mark.parametrize("tool_name", ["document_ocr", "docling_convert"])
def test_ocr_artifacts_keep_file_links_without_image_previews(live, tool_name):
    run_message_browser(f"const live = {json.dumps(live)}, toolName = {json.dumps(tool_name)};\n" + r"""
for (const [action, artifactKey] of [
  ['ocr', 'markdown_stash_ref'], ['extract', 'output_stash_ref'], ['archive', 'archive_stash_ref']
]) {
  const result = {action, filename:'screenshot.jpg', document_type:'image',
    stash_ref:'stash://space_test/f_document', [artifactKey]:'stash://space_test/f_document',
    json_stash_ref:'stash://space_test/f_json'};
  const payload = {[toolName]:result}, before = JSON.stringify(payload);
  const html = render(chat(), 'Saved the document artifacts.', [toolName], payload, live);
  assert.ok(html.includes('tool-card success'));
  assert.ok(html.includes('href="/stash/view/space_test/f_document"'));
  assert.ok(html.includes('href="/stash/view/space_test/f_json"'));
  assert.ok(!html.includes('<img'), action + ' must not treat the input filename as an output image');
  assert.ok(!html.includes('showImageLightbox'));
  assert.equal(JSON.stringify(payload), before);
}
""")


@pytest.mark.parametrize("live", [True, False])
def test_stash_image_preview_uses_artifact_mime_before_filename(live):
    run_message_browser(f"const live = {json.dumps(live)};\n" + r"""
for (const [metadata, expected] of [
  [{filename:'screenshot.png'}, true],
  [{mime_type:'IMAGE/PNG'}, true],
  [{filename:'drawing', mime_type:'image/svg+xml'}, true],
  [{filename:'screenshot.jpg', mime_type:'text/plain'}, false],
  [{filename:'result.json', mime_type:'application/json'}, false],
  [{filename:'source.png', tool_origin:'web_upload', action:'analyze'}, false]
]) {
  const html = render(chat(), 'Saved.', ['stash'], {
    stash:{stash_ref:'stash://space_test/f_artifact', ...metadata}
  }, live);
  assert.equal(html.includes('<img src="/api/stash/space_test/f_artifact"'), expected,
    JSON.stringify(metadata));
  assert.equal(html.includes('showImageLightbox'), expected);
}
""")


@pytest.mark.parametrize("live", [True, False])
def test_repeated_crypto_chart_results_render_each_chart(live):
    run_message_browser(f"const live = {json.dumps(live)};\n" + r"""
const chart = (coin, id, price) => ({
  coin, coin_id:id, vs_currency:'usd', days:'7', range_label:'7-day',
  current_price:price, change_percent:1.25, points_returned:2,
  series:{prices:[{iso:'2026-09-21T00:00:00Z',value:price - 1},
                  {iso:'2026-09-22T00:00:00Z',value:price}]}
});
const payload = {crypto_chart:[chart('Solana', 'solana', 118.46),
                               chart('Bitcoin', 'bitcoin', 86169)]};
const before = JSON.stringify(payload);
const html = render(chat(), 'Both charts are loaded above.',
  ['crypto_chart', 'crypto_chart'], payload, live);
const configs = [...html.matchAll(/data-crypto-chart="([^"]+)"/g)]
  .map(match => JSON.parse(decodeURIComponent(match[1])));
assert.equal(configs.length, 2);
assert.deepEqual(configs.map(config => config.coin), ['Solana', 'Bitcoin']);
assert.deepEqual(configs.map(config => config.series.prices.length), [2, 2]);
assert.equal(JSON.stringify(payload), before);
""")


def test_single_crypto_chart_result_still_renders():
    run_message_browser(r"""
const payload = {crypto_chart:{data:{
  coin:'Solana', coin_id:'solana', vs_currency:'usd', days:'7', range_label:'7-day',
  current_price:118.46, change_percent:1.25, points_returned:2,
  series:{prices:[{iso:'2026-09-21T00:00:00Z',value:117.46},
                  {iso:'2026-09-22T00:00:00Z',value:118.46}]}
}}};
const html = render(chat(), 'The chart is loaded above.', ['crypto_chart'], payload);
const matches = [...html.matchAll(/data-crypto-chart="([^"]+)"/g)];
assert.equal(matches.length, 1);
const config = JSON.parse(decodeURIComponent(matches[0][1]));
assert.equal(config.coin, 'Solana');
assert.equal(config.series.prices.length, 2);
""")


@pytest.mark.parametrize("live", [True, False])
def test_converted_image_lightbox_uses_bound_url_data_for_live_and_saved_messages(live):
    run_message_browser(f"const live = {json.dumps(live)};\n" + r"""
const ui = chat(), opened = [];
sandbox.window.showImageLightbox = url => opened.push(url);
const html = render(ui, 'Ready', ['convert_file'], {
  convert_file: {stash_ref:"stash://Custom space/image');window.__injected=1;('.png", target_format:'png'}
}, live);
assert.ok(!html.includes('onclick='));
const images = message(ui).querySelectorAll('.message-image.converted-file[data-converted-image-url]');
assert.equal(images.length, 1);
images[0].events.click();
assert.deepEqual(opened, ["/api/stash/Custom%20space/image')%3Bwindow.__injected%3D1%3B('.png"]);
assert.equal(sandbox.window.__injected, undefined);
assert.equal(ui.pendingToolsByMessage.has('answer'), false);
""")


@pytest.mark.parametrize("live", [True, False])
def test_repeated_tool_results_keep_trace_order_and_per_message_cleanup(live):
    run_message_browser(f"const live = {json.dumps(live)};\n" + r"""
const ui = chat();
const other = {later_step1:{toolName:'later',status:'pending'}};
ui.pendingToolsByMessage.set('other-answer', other);
const html = render(ui, 'Done', ['search_web'], {
  search_web:[{title:'FIRST_SUCCESS'}, {title:'SECOND_SUCCESS'}],
  _tool_trace:[
    {tool:'search_web',ok:true,duration_ms:12},
    {tool:'search_web',ok:false,error:'MIDDLE_FAILURE'},
    {tool:'search_web',skipped:true,reason:'DO_NOT_RUN'},
    {tool:'search_web',ok:true,duration_ms:24}
  ]
}, live);
const markers = ['FIRST_SUCCESS','MIDDLE_FAILURE','DO_NOT_RUN','SECOND_SUCCESS'];
for (const marker of markers) assert.ok(html.includes(marker), marker);
for (let i=1;i<markers.length;i++) assert.ok(html.indexOf(markers[i-1]) < html.indexOf(markers[i]));
assert.equal((html.match(/class="tool-card success"/g)||[]).length,2);
assert.equal((html.match(/class="tool-card error"/g)||[]).length,1);
assert.equal((html.match(/class="tool-card skipped"/g)||[]).length,1);
assert.equal(ui.pendingToolsByMessage.get('other-answer'),other);
assert.equal(ui.pendingToolsByMessage.has('answer'),false);
const header = message(ui).querySelectorAll('.tool-card-header')[0];
header.events.click();
assert.ok(header.parentElement.classList.contains('expanded'));
""")


@pytest.mark.parametrize("family", ["amazon", "home_depot", "ebay"])
def test_product_fallback_only_runs_without_shared_renderer(family):
    run_message_browser(f"const family = {json.dumps(family)};\n" + r"""
const payloads = {
  amazon: {serpapi_search:{engine:'amazon',results:[{title:'PRODUCT <safe>',url:'https://example.test/amazon'}]}},
  home_depot: {serpapi_home_depot:{product_details:{title:'PRODUCT <safe>',url:'https://example.test/depot'}}},
  ebay: {serpapi_ebay_product:{product_summary:{title:'PRODUCT <safe>',url:'https://example.test/ebay'}}}
};
const payload = payloads[family], tools = Object.keys(payload), before = JSON.stringify(payload);
const shared = render(chat(), 'Found it', tools, payload);
assert.ok(!shared.includes('class="product-preview-card"'));
delete sandbox.window.structuredResultsRenderer;
const fallback = render(chat(), 'Found it', tools, payload, false);
assert.ok(fallback.includes('class="product-preview-card"'));
assert.ok(fallback.includes('PRODUCT &lt;safe&gt;'));
assert.equal(JSON.stringify(payload), before);
""")


@pytest.mark.parametrize("live", [True, False])
def test_dedicated_media_details_and_message_hooks_keep_their_order(live):
    run_message_browser(f"const live = {json.dumps(live)};\n" + r"""
const ui = chat();
const html = render(ui, 'A short answer', ['serpapi_youtube_search'], {
  raw_llm_response:'A different, much longer raw response with further context and explanation.',
  serpapi_youtube_search:{results:[{title:'VIDEO <safe>',url:'https://www.youtube.com/watch?v=dQw4w9WgXcQ'}]},
  recording:{stash_ref:'stash://space_test/f_audio', filename:'recording.ogg', mime_type:'audio/ogg'}
}, live, {allowReaction:false});
assert.equal((html.match(/class="video-embed-frame"/g)||[]).length,1);
assert.ok(html.includes('src="https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ"'));
assert.ok(html.includes('VIDEO &lt;safe&gt;'));
assert.ok(html.indexOf('youtube-embed') < html.indexOf('class="message-bubble"'));
assert.ok(html.indexOf('class="message-bubble"') < html.indexOf('class="message-audio"'));
assert.ok(!html.includes('structured-results-section'));
const toggle = message(ui).querySelector('.details-toggle');
assert.ok(toggle);
let stopped = false;
toggle.events.click({stopPropagation:()=>{stopped=true;}});
assert.equal(stopped,true);
assert.equal(toggle.parentElement.classList.contains('collapsed'),false);
assert.equal(toggle.querySelector('.toggle-text').textContent,'Hide details');
const actions = effects.find(x=>Array.isArray(x)&&x[0]==='actions');
assert.equal(actions[1],'A short answer');
assert.equal(actions[2].allowReaction,false);
assert.equal(actions[2].allowCanvas,true);
timers.forEach(fn=>fn());
assert.equal(message(ui).classList.contains('new-message'),false);
""")


def test_conversation_replay_calls_real_message_renderer_and_reconciles_once():
    run_message_browser(r"""
const ui = chat();
Object.assign(ui, {
  setConversationLoading(){}, restoreRunState(){}, reconcileLiveActions(){},
  clearChat(){this.messagesContainer.children=[];this._renderedMessageIds=new Set();}
});
const app = Object.create(JarvisApp.prototype);
Object.assign(app, {chat:ui,socket,_completedResponseIds:new Set(),
  _updateActiveConversation(){},_updateConvIdBadge(){},_loadConversationHistory(){}});
const conversation = {id:'thread',reaction_message_id:'answer',messages:[{
  role:'assistant',content:'Saved result',tools_used:['convert_file'],data:{
    _web_message_id:'answer',convert_file:{stash_ref:'stash://space_test/f_saved',filename:'saved.pdf',target_format:'pdf'}
  }
}]};
await app._displayLoadedConversation(conversation);
assert.equal(ui.messagesContainer.children.length,1);
assert.ok(message(ui).innerHTML.includes('saved.pdf'));
assert.ok(message(ui).innerHTML.includes('Saved result'));
await app._displayLoadedConversation(conversation,{reconcile:true});
assert.equal(ui.messagesContainer.children.length,1);
assert.ok(app._completedResponseIds.has('answer'));
""")


def test_conversation_replay_keeps_tool_cards_in_their_saved_turns():
    run_message_browser(r"""
const ui = chat();
Object.assign(ui, {
  setConversationLoading(){}, restoreRunState(){}, reconcileLiveActions(){},
  clearChat(){this.messagesContainer.children=[];this._renderedMessageIds=new Set();this._resetPendingToolState();}
});
const app = Object.create(JarvisApp.prototype);
Object.assign(app, {chat:ui,socket,_completedResponseIds:new Set(),
  _updateActiveConversation(){},_updateConvIdBadge(){},_loadConversationHistory(){}});
const conversation = {id:'thread',messages:[
  {role:'assistant',content:'Memory response',tools_used:['semantic_recall'],data:{
    _web_message_id:'earlier-1',semantic_recall:{count:7},
    _tool_trace:[{tool:'semantic_recall',ok:true,duration_ms:503}]}},
  {role:'assistant',content:'Memory search response',tools_used:['search_memory'],data:{
    _web_message_id:'earlier-2',search_memory:{count:2},
    _tool_trace:[{tool:'search_memory',ok:true,duration_ms:254}]}},
  {role:'assistant',content:'Amazon response',tools_used:['serpapi_amazon_search','serpapi_amazon_search'],data:{
    _web_message_id:'last',
    _tool_trace:[
      {tool:'serpapi_amazon_search',ok:true,duration_ms:60076},
      {tool:'serpapi_google_shopping_light',ok:false,duration_ms:6262,error:'No results'},
      {tool:'serpapi_amazon_search',ok:true,duration_ms:28786},
      {tool:'serpapi_google_shopping_light',ok:false,duration_ms:10018,error:'No results'}
    ]}}
]};
await app._displayLoadedConversation(conversation);
assert.equal(ui.messagesContainer.children.length,3);
const cards = ui.messagesContainer.children.map(item =>
  [...item.innerHTML.matchAll(/<span class="tool-card-title">([^<]*)<\/span>/g)].map(match => match[1]));
assert.deepEqual(cards,[
  ['semantic_recall'], ['search_memory'],
  ['serpapi_amazon_search','serpapi_google_shopping_light',
   'serpapi_amazon_search','serpapi_google_shopping_light']
]);
const last = ui.messagesContainer.children[2].innerHTML;
assert.ok(last.includes('1.0m') && last.includes('28.8s'));
assert.ok(!last.includes('254ms') && !last.includes('503ms'));
""")


def test_saving_reflections_off_clears_visible_thumbs():
    run_message_browser(r"""
const removed = [];
ChatUI.prototype.clearIntelligenceReactions.call({
  messagesContainer: {
    querySelectorAll(selector) {
      assert.equal(
        selector,
        '.message-response-actions [data-reaction], .message-response-actions .message-reaction-status'
      );
      return [
        {remove() { removed.push('up'); }},
        {remove() { removed.push('down'); }},
        {remove() { removed.push('status'); }}
      ];
    }
  }
});
assert.deepEqual(removed, ['up', 'down', 'status']);

const cleared = [];
const chatUi = chat();
chatUi.clearIntelligenceReactions = () => cleared.push('cleared');
chatUi.refreshContextWindow = async () => {};
sandbox.window.chatUI = chatUi;
let reflectionsOn = false;
sandbox.document.getElementById = (id) => ({
  value: id === 'setting-mode' ? 'cloud'
    : (id === 'setting-history-limit' ? '20'
    : (id === 'setting-glow-intensity' ? 'low' : '')),
  checked: id === 'setting-intelligence-reflections' ? reflectionsOn : false,
  classList: {remove() {}, add() {}}
});
sandbox.fetch = async () => ({ok: true, status: 200, json: async () => ({ok: true})});
Utils.toast = () => {};
Utils.storage.set = () => {};
const app = Object.create(JarvisApp.prototype);
Object.assign(app, {
  socket: {mode: 'cloud', setMode() {}},
  settingsModal: {classList: {remove() {}}},
  _settingsData: {mode: 'cloud', response: {style: {default: 'auto'}}},
  audioEnabled: false,
  glowIntensity: 'low',
  _loadSettings: async () => {},
  _updateAudioButton() {},
  _applyGlowIntensity() {}
});
await app._saveSettings();
assert.deepEqual(cleared, ['cleared']);
reflectionsOn = true;
await app._saveSettings();
assert.deepEqual(cleared, ['cleared']);
""")


@pytest.mark.parametrize("live", [True, False])
@pytest.mark.parametrize("structured", [True, False])
def test_speech_tags_stay_hidden_in_raw_fallback_and_details(live, structured):
    run_message_browser(f"const live = {json.dumps(live)}, structured = {json.dumps(structured)};\n" + r"""
const raw = structured
  ? '[CURIOUS] Full answer\n\n- [clears throat] Item one\n- <whisper>Item two</whisper>'
  : '[curious] A longer raw explanation that belongs in the details pane. [clears throat] It has several useful sentences.';
const speech = '[whispers] Brief answer.';
const payload = {speech, raw_llm_response:raw};
const html = render(chat(), 'Brief answer.', [], payload, live);
assert.ok(!/\[(?:curious|clears throat|whispers)\]/i.test(html));
assert.ok(!html.includes('&lt;whisper&gt;'));
if (structured) {
  assert.ok(html.includes('Item one'));
  assert.ok(html.includes('Item two'));
} else {
  assert.ok(html.includes('details-toggle'));
  assert.ok(html.includes('several useful sentences'));
}
assert.equal(payload.speech, speech); // Playback keeps the original cues.
assert.equal(payload.raw_llm_response, raw);
assert.equal(Utils.stripSpeechTagsForDisplay('[curious](https://example.test) [1, 2]'),
  '[curious](https://example.test) [1, 2]');
assert.equal(Utils.stripSpeechTagsForDisplay('[slow>Hi</slow> [laugh]'), 'Hi');
""")


def test_client_speech_tag_cleanup_matches_reviewed_python_vocabulary():
    import sys
    sys.path.insert(0, str(ROOT / "lib"))
    from tts_style_tags import all_inline_speech_tags, all_wrapping_speech_tags
    inline = sorted(all_inline_speech_tags())
    wrapping = sorted(all_wrapping_speech_tags())
    run_message_browser(
        f"assert.deepEqual(Array.from(Utils._speechInlineTags), {json.dumps(inline)});\n"
        f"assert.deepEqual(Array.from(Utils._speechWrappingTags), {json.dumps(wrapping)});\n"
        + r"""
for (const tag of Utils._speechInlineTags) {
  assert.equal(Utils.stripSpeechTagsForDisplay(`[${tag}] Hello`), 'Hello');
}
for (const tag of Utils._speechWrappingTags) {
  assert.equal(Utils.stripSpeechTagsForDisplay(`<${tag}>Hello</${tag}>`), 'Hello');
}
"""
    )



@pytest.mark.parametrize("live", [True, False])
def test_duplicate_cue_brackets_are_hidden_in_live_and_existing_history(live):
    run_message_browser(f"const live = {json.dumps(live)};\n" + r"""
const raw = '[curious]] Did that just happen?\n[excited] It worked.\n[clears throat]]] Anyway.';
const payload = {speech:raw, raw_llm_response:raw};
// Older servers already stripped the tags, leaving the duplicate closers behind.
const oldDisplay = '] Did that just happen?\n It worked.\n]] Anyway.';
for (const display of [raw, oldDisplay]) {
  const html = render(chat(), display, [], payload, live);
  assert.ok(html.includes('Did that just happen?'));
  assert.ok(html.includes('Anyway.'));
  assert.ok(!html.includes(']'));
}
assert.equal(payload.speech, raw);
assert.equal(payload.raw_llm_response, raw);
assert.equal(Utils.stripSpeechTagsForDisplay('[laugh]] Funny.'), 'Funny.');
const ordinary = '] A bracket, [1, 2], [unknown]] and [curious](https://example.test).';
assert.equal(Utils.stripSpeechTagsForDisplay(ordinary), ordinary);
assert.equal(Utils.stripSpeechTagsForDisplay('] Separate answer.', raw), '] Separate answer.');
""")

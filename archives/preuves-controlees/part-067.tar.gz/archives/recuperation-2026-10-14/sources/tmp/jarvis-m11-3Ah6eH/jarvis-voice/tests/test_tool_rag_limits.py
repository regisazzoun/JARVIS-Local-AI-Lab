#!/usr/bin/env python3
"""Regression tests for Tool RAG final schema limits."""

import logging
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT / "lib"))
sys.path.insert(0, str(PROJECT_ROOT / "orchestrator"))

from router_v2 import (  # noqa: E402
    _cap_tool_names_for_schema,
    _log_tool_rag_signal_meta,
    _resolve_tool_rag_limit,
    expand_prerequisite_tool_names,
)


class ToolRagLimitTests(unittest.TestCase):
    def test_enabled_prerequisite_is_added_before_dependent_and_bounded(self):
        tools = {
            "detail_tool": SimpleNamespace(
                prerequisite_tools=["lookup_tool", "blocked_tool", "extra_tool"]
            ),
            "lookup_tool": SimpleNamespace(prerequisite_tools=[]),
            "extra_tool": SimpleNamespace(prerequisite_tools=[]),
        }
        registry = SimpleNamespace(get_tool=lambda name: tools.get(name))

        names, added = expand_prerequisite_tool_names(
            ["search_memory", "detail_tool"],
            registry,
            {"search_memory", "detail_tool", "lookup_tool", "blocked_tool", "extra_tool"},
            excluded_tools={"blocked_tool"},
            max_added=1,
        )

        self.assertEqual(names, ["search_memory", "lookup_tool", "detail_tool"])
        self.assertEqual(added, ["detail_tool:lookup_tool"])

    def test_prerequisite_respects_exclusions(self):
        dependent = SimpleNamespace(prerequisite_tools=["lookup_tool"])
        registry = SimpleNamespace(
            get_tool=lambda name: dependent if name == "detail_tool" else None
        )

        names, added = expand_prerequisite_tool_names(
            ["detail_tool"],
            registry,
            {"detail_tool", "lookup_tool"},
            excluded_tools={"lookup_tool"},
        )

        self.assertEqual(names, ["detail_tool"])
        self.assertEqual(added, [])

    def test_final_cap_prioritizes_explicit_tool_and_discovery(self):
        names = [
            "search_memory",
            "update_memory",
            "semantic_recall",
            "remember",
            "canvas",
            "tool_search",
            "workflow",
            "generate_video",
            "stash",
        ]

        capped = _cap_tool_names_for_schema(
            names,
            3,
            positive_tools={"canvas"},
            ghost_tools={
                "search_memory",
                "update_memory",
                "semantic_recall",
                "remember",
                "canvas",
                "tool_search",
                "workflow",
            },
        )

        self.assertEqual(capped, ["canvas", "tool_search", "workflow"])

    def test_mode_limits_are_configurable(self):
        with patch.dict(os.environ, {
            "JARVIS_OVERRIDE_CLOUD_TOOL_RAG_LIMIT": "9",
            "JARVIS_OVERRIDE_LOCAL_TOOL_RAG_LIMIT": "4",
        }):
            self.assertEqual(_resolve_tool_rag_limit("cloud"), 9)
            self.assertEqual(_resolve_tool_rag_limit("local"), 4)

    def test_full_local_action_budget_leaves_discovery_but_no_optional_memory_ghosts(self):
        ghosts = ["search_memory", "remember", "tool_search", "workflow"]
        actions = ["youtube_video", "text_summarizer", "send_email", "pdf_read"]
        self.assertEqual(
            _cap_tool_names_for_schema(ghosts + actions, 6, ghost_tools=ghosts),
            ["tool_search", "workflow", *actions],
        )

    def test_local_default_covers_default_ghosts_plus_discovery(self):
        with patch.dict(os.environ, {}, clear=True):
            self.assertEqual(_resolve_tool_rag_limit("local"), 6)

    def test_request_override_wins_for_one_turn(self):
        with patch.dict(os.environ, {"JARVIS_OVERRIDE_CLOUD_TOOL_RAG_LIMIT": "15"}):
            self.assertEqual(_resolve_tool_rag_limit("cloud", override=3), 3)

    def test_request_override_is_bounded(self):
        self.assertEqual(_resolve_tool_rag_limit("cloud", override=999), 50)

    def test_cap_only_signal_meta_is_logged(self):
        logger = logging.getLogger("test.tool_rag_limits")
        with self.assertLogs(logger, level="INFO") as captured:
            _log_tool_rag_signal_meta(
                logger,
                {"capped_to": ["3"], "dropped_by_cap": ["remember"]},
            )

        self.assertIn("dropped_by_cap", "\n".join(captured.output))


if __name__ == "__main__":
    unittest.main()

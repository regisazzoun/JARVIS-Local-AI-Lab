#!/usr/bin/env python3
"""
Regression tests for workflow placeholder resolution.

Run:
    python3 tests/test_pipeline_executor.py
"""

import json
import os
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT))

from orchestrator.pipeline_executor import PipelineExecutor
from config_loader import config_scope, get_config_value
from llm_provider import has_usage_accounting_data


class DummyProvider:
    pass


class UnknownCostProvider:
    def __init__(self):
        self.tool_calls = 0
        self.fallback_calls = 0

    def chat_with_tools(self, **_kwargs):
        self.tool_calls += 1
        return (
            "first response",
            None,
            {
                "input_tokens": 3,
                "output_tokens": 2,
                "total_tokens": 5,
                "cost_usd": None,
                "cost_known": False,
                "billing_mode": "ollama_cloud_subscription",
            },
            None,
        )

    def chat(self, *_args):
        self.fallback_calls += 1
        return "unexpected fallback"


class CachedCostProvider:
    def chat_with_tools(self, **_kwargs):
        return (
            "cached response",
            None,
            {
                "input_tokens": 10,
                "output_tokens": 2,
                "total_tokens": 1_012,
                "cost_usd": 0.02,
                "cache_creation_tokens": 1_000,
                "cache_read_tokens": 0,
                "cache_write_cost_usd": 0.0125,
                "cache_read_cost_usd": 0.0,
                "cache_cost_usd": 0.0125,
                "cache_savings_usd": 0.0,
            },
            None,
        )


class SequencedUsageProvider:
    def __init__(self):
        self.usages = iter((
            {"input_tokens": 100, "output_tokens": 10, "total_tokens": 110, "cost_usd": 0.01},
            {"input_tokens": 240, "output_tokens": 20, "total_tokens": 260, "cost_usd": 0.02},
        ))

    def chat_with_tools(self, **_kwargs):
        return "response", None, next(self.usages), None


class DiagnosticOnlyUsageProvider:
    def chat_with_tools(self, **_kwargs):
        return "response", None, {"reasoning_effort_sent": False}, None


class EnvCapturingProvider:
    def __init__(self):
        self.enable_search = True
        self.calls = []

    def chat_with_tools(self, **kwargs):
        self.calls.append(
            {
                "enable_search": self.enable_search,
                "xai_disabled": os.environ.get("XAI_DISABLE_SERVER_SIDE_TOOLS"),
                "openai_disabled": os.environ.get("OPENAI_RESPONSES_DISABLE_SERVER_SIDE_TOOLS"),
                "xai_search_override": os.environ.get("JARVIS_OVERRIDE_XAI_SEARCH"),
                "anthropic_search_override": os.environ.get("JARVIS_OVERRIDE_ANTHROPIC_SEARCH"),
                "xai_reasoning_effort": os.environ.get("XAI_REASONING_EFFORT"),
                "xai_request_timeout": os.environ.get("XAI_REQUEST_TIMEOUT_SECONDS"),
                "resolved_xai_reasoning_effort": get_config_value(
                    "XAI_REASONING_EFFORT"
                ),
                "resolved_xai_request_timeout": get_config_value(
                    "XAI_REQUEST_TIMEOUT_SECONDS"
                ),
                "tools": kwargs.get("tools"),
            }
        )
        return "Solana", None, {"input_tokens": 1, "output_tokens": 1, "total_tokens": 2}, None

    def chat(self, *_args):
        raise AssertionError("chat fallback should not be used")


class ErrorTextProvider:
    def chat_with_tools(self, **_kwargs):
        return "Error: Request timed out.", None, None, None

    def chat(self, *_args):
        raise AssertionError("provider error text must not trigger a duplicate request")


class TimeoutRaisingProvider:
    def chat_with_tools(self, **_kwargs):
        raise TimeoutError("primary request timed out")

    def chat(self, *_args):
        raise TimeoutError("fallback request timed out")


class PromptCapturingProvider:
    def __init__(self, response="generated canvas"):
        self.response = response
        self.prompts = []

    def chat_with_tools(self, **kwargs):
        self.prompts.append(kwargs["messages"][0]["content"])
        return self.response, None, {"input_tokens": 1, "output_tokens": 1, "total_tokens": 2}, None


class PipelineExecutorResolutionTests(unittest.TestCase):
    def setUp(self):
        self.executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=lambda *args, **kwargs: {}),
            provider=DummyProvider(),
        )

    def test_unrelated_workflow_does_not_inject_article_count(self):
        result = self.executor._build_success_response(
            {"id": "structured_watch", "success_speech": "Watch complete."},
            [{"step": 1, "tool": "watch", "ok": True}], {}, ["watch"],
        )
        self.assertNotIn("article_count", result["data"]["variables"])
        self.assertIsNone(result["usage"])

    def test_article_workflow_still_counts_validated_sources(self):
        for sources in ([], [{"title": "A"}, {"title": "B"}]):
            result = self.executor._build_success_response(
                {"id": "research", "success_speech": "Found ${article_count} sources."},
                [], {"validated_articles": sources}, [],
            )
            self.assertEqual(result["data"]["variables"]["article_count"], len(sources))
            self.assertEqual(result["speech"], f"Found {len(sources)} sources.")

    def test_explicit_article_count_consumer_keeps_zero_fallback(self):
        result = self.executor._build_success_response(
            {"id": "research", "success_speech": "Found ${article_count} sources."},
            [], {}, [],
        )
        self.assertEqual(result["speech"], "Found 0 sources.")

    def test_embedded_indexed_placeholders_resolve(self):
        variables = {
            "location": "Portland, Oregon",
            "forecast_lows": [33, 36, 41],
            "forecast_dates": ["2026-04-03", "2026-04-04", "2026-04-05"],
        }

        resolved = self.executor._resolve_variable(
            "Cold watch for ${location}: tonight ${forecast_lows[0]}F on ${forecast_dates[0]}",
            variables,
        )

        self.assertEqual(
            resolved,
            "Cold watch for Portland, Oregon: tonight 33F on 2026-04-03",
        )

    def test_usage_accounting_ignores_only_request_diagnostics(self):
        self.assertFalse(
            has_usage_accounting_data({"reasoning_effort_sent": False})
        )
        self.assertFalse(
            has_usage_accounting_data({
                "reasoning_effort_sent": "low",
                "xai_reasoning_effort": "low",
            })
        )
        self.assertTrue(
            has_usage_accounting_data({
                "reasoning_effort_sent": "low",
                "server_side_tools": {"SERVER_SIDE_TOOL_WEB_SEARCH": 1},
            })
        )
        self.assertTrue(has_usage_accounting_data({"input_tokens": 0}))

    def test_filename_timestamp_and_kebab_transform_are_filesystem_safe(self):
        variables = self.executor._extract_workflow_variables(
            "test",
            {"id": "test", "variables": {}},
            "test",
        )

        self.assertRegex(variables["filename_timestamp"], r"^\d{8}-\d{6}$")
        self.assertEqual(
            self.executor._apply_transform("Example.COM / Docker CLI", "kebab"),
            "example-com-docker-cli",
        )

    def test_location_date_context_is_nested_and_prefers_explicit_location(self):
        target_date = (datetime.now().date() + timedelta(days=4)).isoformat()
        workflow = {
            "id": "reusable_planning_workflow",
            "variables": {
                "planning_context": {
                    "from": "query",
                    "extract": "location_date_context",
                    "allow_default_location": True,
                    "forecast_horizon_days": 10,
                },
            },
        }

        with patch.object(
            self.executor,
            "_chat_with_usage",
            return_value=json.dumps(
                {"location": "Seaside, Oregon", "target_date": target_date}
            ),
        ):
            variables = self.executor._extract_workflow_variables(
                "/night_out Seaside Oregon August 25 anniversary",
                workflow,
                "Seaside Oregon August 25 anniversary",
            )

        context = variables["planning_context"]
        self.assertEqual(context["location"], "Seaside, Oregon")
        self.assertEqual(context["location_source"], "query")
        self.assertEqual(context["target_date"], target_date)
        self.assertTrue(context["forecast_eligible"])
        self.assertNotIn("location", variables)

    def test_location_date_context_uses_default_only_when_enabled(self):
        workflow = {
            "id": "reusable_planning_workflow",
            "variables": {
                "planning_context": {
                    "from": "query",
                    "extract": "location_date_context",
                    "allow_default_location": True,
                    "forecast_horizon_days": 10,
                },
            },
        }

        def config_value(key, default=None):
            return {
                "JARVIS_DEFAULT_LOCATION": "Portland, Oregon",
                "JARVIS_DEFAULT_POSTAL_CODE": "97205",
            }.get(key, default)

        with (
            patch.object(
                self.executor,
                "_chat_with_usage",
                return_value='{"location": null, "target_date": null}',
            ),
            patch(
                "orchestrator.pipeline_executor.get_config_value",
                side_effect=config_value,
            ),
        ):
            variables = self.executor._extract_workflow_variables(
                "/night_out anniversary dinner",
                workflow,
                "anniversary dinner",
            )

        context = variables["planning_context"]
        self.assertEqual(context["location"], "Portland, Oregon")
        self.assertEqual(context["location_source"], "jarvis_default_location")
        self.assertEqual(context["target_date"], "not specified")
        self.assertTrue(context["forecast_eligible"])

    def test_location_date_context_skips_forecast_beyond_configured_horizon(self):
        target_date = (datetime.now().date() + timedelta(days=20)).isoformat()
        with patch.object(
            self.executor,
            "_chat_with_usage",
            return_value=json.dumps(
                {"location": "Newport, Oregon", "target_date": target_date}
            ),
        ):
            context = self.executor._extract_location_date_context(
                "Newport Oregon anniversary dinner in three weeks",
                forecast_horizon_days=10,
            )

        self.assertEqual(context["location"], "Newport, Oregon")
        self.assertEqual(context["target_date"], target_date)
        self.assertFalse(context["forecast_eligible"])
        self.assertIn("beyond the 10-day forecast window", context["forecast_skip_reason"])
        should_execute, _reason = self.executor._should_execute_step(
            {
                "step": 2,
                "condition": {
                    "op": "eq",
                    "left": "${planning_context.forecast_eligible}",
                    "right": True,
                },
            },
            {"planning_context": context},
        )
        self.assertFalse(should_execute)

    def test_location_date_context_defaults_are_opt_in_and_forecast_is_optional(self):
        def config_value(key, default=None):
            return {
                "JARVIS_DEFAULT_LOCATION": "Portland, Oregon",
                "JARVIS_DEFAULT_POSTAL_CODE": "97205",
            }.get(key, default)

        with (
            patch.object(
                self.executor,
                "_chat_with_usage",
                return_value='{"location": null, "target_date": null}',
            ),
            patch(
                "orchestrator.pipeline_executor.get_config_value",
                side_effect=config_value,
            ),
        ):
            context = self.executor._extract_location_date_context(
                "anniversary dinner"
            )

        self.assertIsNone(context["location"])
        self.assertEqual(context["location_source"], "unresolved")
        self.assertNotIn("forecast_eligible", context)

    def test_location_or_default_falls_back_to_active_mode_postal_code(self):
        def config_value(key, default=None):
            return {
                "JARVIS_DEFAULT_LOCATION": "",
                "JARVIS_DEFAULT_POSTAL_CODE": "10001",
            }.get(key, default)

        with (
            patch.object(self.executor, "_chat_with_usage", return_value="NONE"),
            patch(
                "orchestrator.pipeline_executor.get_config_value",
                side_effect=config_value,
            ),
        ):
            location, source = self.executor._extract_location_or_default(
                "quiet rooftop dinner"
            )

        self.assertEqual(location, "10001")
        self.assertEqual(source, "jarvis_default_postal_code")

    def test_mixed_placeholder_string_starting_with_placeholder_resolves(self):
        variables = {
            "alert_source": "weather_watch",
            "location": "Portland, Oregon",
            "forecast_dates": ["2026-04-03"],
        }

        resolved = self.executor._resolve_variable(
            "${alert_source}:cold:${location}:${forecast_dates[0]}",
            variables,
        )

        self.assertEqual(
            resolved,
            "weather_watch:cold:Portland, Oregon:2026-04-03",
        )

    def test_url_extraction_ignores_grouped_non_web_search_results(self):
        search_data = {
            "results": {
                "memory": [{"id": 1, "value": "stored fact"}],
                "intel": [{"file": "topic.md", "content": "stored intel"}],
            }
        }

        self.assertEqual(self.executor._extract_urls_from_search(search_data), [])

    def test_url_extraction_keeps_standard_result_arrays(self):
        search_data = {
            "results": [
                {"url": "https://example.com/one"},
                "unexpected scalar",
                {"title": "No URL"},
                {"url": "https://example.com/two"},
            ]
        }

        self.assertEqual(
            self.executor._extract_urls_from_search(search_data),
            ["https://example.com/one", "https://example.com/two"],
        )

    def test_search_index_name_uses_workflow_search_url_extraction(self):
        variables = {}
        result = {
            "ok": True,
            "data": {
                "results": [
                    {"url": "https://example.test/source-one"},
                    {"url": "https://example.test/source-two"},
                ]
            },
        }

        self.assertTrue(self.executor._is_search_tool("serpapi_search_index"))
        self.executor._apply_output_transforms(
            {}, result, variables, "serpapi_search_index", None
        )
        self.assertEqual(
            variables["search_results"]["urls"],
            [
                "https://example.test/source-one",
                "https://example.test/source-two",
            ],
        )

    def test_google_news_light_uses_workflow_search_url_extraction(self):
        variables = {}
        result = {
            "ok": True,
            "data": {
                "results": [
                    {"url": "https://news.example/article-one"},
                    {"url": "https://news.example/article-two"},
                ]
            },
        }

        self.assertTrue(self.executor._is_search_tool("serpapi_google_news_light"))
        self.executor._apply_output_transforms(
            {}, result, variables, "serpapi_google_news_light", None
        )
        self.assertEqual(
            variables["search_results"]["urls"],
            [
                "https://news.example/article-one",
                "https://news.example/article-two",
            ],
        )

    def test_google_shopping_light_uses_workflow_offer_url_extraction(self):
        variables = {}
        result = {
            "ok": True,
            "data": {
                "results": [
                    {"url": "https://shop.example/offer-one"},
                    {"url": "https://shop.example/offer-two"},
                ]
            },
        }

        self.assertTrue(
            self.executor._is_search_tool("serpapi_google_shopping_light")
        )
        self.executor._apply_output_transforms(
            {}, result, variables, "serpapi_google_shopping_light", None
        )
        self.assertEqual(
            variables["search_results"]["urls"],
            [
                "https://shop.example/offer-one",
                "https://shop.example/offer-two",
            ],
        )

    def test_google_images_light_extracts_original_assets_for_workflows(self):
        variables = {}
        result = {
            "ok": True,
            "data": {
                "results": [
                    {
                        "url": "https://images.example/full-one.jpg",
                        "source_url": "https://pages.example/one",
                    },
                    {
                        "url": "https://images.example/full-two.jpg",
                        "source_url": "https://pages.example/two",
                    },
                ]
            },
        }

        self.assertTrue(self.executor._is_search_tool("serpapi_google_images_light"))
        self.executor._apply_output_transforms(
            {}, result, variables, "serpapi_google_images_light", None
        )
        self.assertEqual(
            variables["search_results"]["urls"],
            [
                "https://images.example/full-one.jpg",
                "https://images.example/full-two.jpg",
            ],
        )

    def test_google_local_uses_workflow_search_url_extraction(self):
        variables = {}
        result = {
            "ok": True,
            "data": {
                "results": [
                    {"url": "https://local.example/place-one"},
                    {"url": "https://local.example/place-two"},
                ]
            },
        }

        self.assertTrue(self.executor._is_search_tool("serpapi_google_local"))
        self.executor._apply_output_transforms(
            {}, result, variables, "serpapi_google_local", None
        )
        self.assertEqual(
            variables["search_results"]["urls"],
            [
                "https://local.example/place-one",
                "https://local.example/place-two",
            ],
        )

    def test_google_local_services_uses_workflow_search_url_extraction(self):
        variables = {}
        result = {
            "ok": True,
            "data": {
                "results": [
                    {"url": "https://services.example/provider-one"},
                    {"url": "https://services.example/provider-two"},
                ]
            },
        }

        self.assertTrue(
            self.executor._is_search_tool("serpapi_google_local_services")
        )
        self.executor._apply_output_transforms(
            {}, result, variables, "serpapi_google_local_services", None
        )
        self.assertEqual(
            variables["search_results"]["urls"],
            [
                "https://services.example/provider-one",
                "https://services.example/provider-two",
            ],
        )

    def test_google_trends_does_not_use_search_url_fallback(self):
        self.assertFalse(self.executor._is_search_tool("serpapi_google_trends"))
        self.assertFalse(self.executor._is_search_tool("serpapi_google_trending_now"))

    def test_web_attachment_context_extracts_stash_ref_and_filename(self):
        topic = """[ATTACHED PDF ARTIFACT]
Filename: docker-cheatsheet.pdf
Stash reference: stash://space_web_pdf_123/f_456
MIME type: application/pdf
"""
        workflow = {
            "id": "pdf_ingest",
            "variables": {
                "pdf_stash_ref": {
                    "from": "query",
                    "extract": "stash_ref",
                    "default": "",
                },
                "attachment_filename": {
                    "from": "query",
                    "extract": "attachment_filename",
                    "default": "source.pdf",
                },
            },
        }

        variables = self.executor._extract_workflow_variables(
            f"/pdf_ingest\n\n{topic}",
            workflow,
            topic,
        )

        self.assertEqual(
            variables["pdf_stash_ref"],
            "stash://space_web_pdf_123/f_456",
        )
        self.assertEqual(
            variables["attachment_filename"],
            "docker-cheatsheet.pdf",
        )
        self.assertNotIn("url", variables)

    def test_direct_stash_ref_extracts_without_attachment_context(self):
        topic = "stash://space_manual_123/f_abc"
        workflow = {
            "id": "pdf_ingest",
            "variables": {
                "pdf_stash_ref": {
                    "from": "query",
                    "extract": "stash_ref",
                },
            },
        }

        variables = self.executor._extract_workflow_variables(
            f"/pdf_ingest {topic}",
            workflow,
            topic,
        )

        self.assertEqual(variables["pdf_stash_ref"], topic)

    def test_deterministic_numeric_condition(self):
        variables = {
            "forecast_lows": [34, 41],
            "cold_threshold_f": 34,
        }

        should_execute = self.executor._evaluate_condition(
            {
                "any": [
                    {"op": "lte", "left": "${forecast_lows[0]}", "right": "${cold_threshold_f}"},
                    {"op": "lte", "left": "${forecast_lows[1]}", "right": "${cold_threshold_f}"},
                ]
            },
            variables,
        )

        self.assertTrue(should_execute)

    def test_contains_any_condition(self):
        variables = {
            "forecast_conditions": ["partly cloudy", "freezing rain"],
        }

        should_execute = self.executor._evaluate_condition(
            {
                "any": [
                    {"op": "contains_any", "left": "${forecast_conditions[0]}", "right": ["thunderstorm", "snow"]},
                    {"op": "contains_any", "left": "${forecast_conditions[1]}", "right": ["thunderstorm", "freezing rain"]},
                ]
            },
            variables,
        )

        self.assertTrue(should_execute)

    def test_missing_numeric_value_does_not_trigger_threshold(self):
        variables = {
            "forecast_wind_maxes": ["n/a", "n/a"],
            "wind_threshold_mph": 25,
        }

        should_execute = self.executor._evaluate_condition(
            {
                "any": [
                    {"op": "gte", "left": "${forecast_wind_maxes[0]}", "right": "${wind_threshold_mph}"},
                    {"op": "gte", "left": "${forecast_wind_maxes[1]}", "right": "${wind_threshold_mph}"},
                ]
            },
            variables,
        )

        self.assertFalse(should_execute)

    def test_unknown_subscription_cost_does_not_retry_llm_call(self):
        provider = UnknownCostProvider()
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=lambda *args, **kwargs: {}),
            provider=provider,
        )

        result = executor._chat_with_usage("probe")

        self.assertEqual(result, "first response")
        self.assertEqual(provider.tool_calls, 1)
        self.assertEqual(provider.fallback_calls, 0)
        self.assertEqual(executor._total_usage["cost_usd"], 0.0)
        self.assertTrue(executor._total_usage["has_unknown_cost"])
        self.assertFalse(executor._total_usage["cost_known"])
        self.assertEqual(
            executor._total_usage["billing_mode"],
            "ollama_cloud_subscription",
        )
        self.assertEqual(executor._total_usage["model_calls"], 1)
        self.assertEqual(executor._total_usage["peak_context_tokens"], 5)

    def test_reasoning_diagnostic_alone_is_not_counted_as_usage(self):
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=lambda *args, **kwargs: {}),
            provider=DiagnosticOnlyUsageProvider(),
        )

        result = executor._chat_with_usage("probe")

        self.assertEqual(result, "response")
        self.assertEqual(executor._total_usage["model_calls"], 0)
        self.assertEqual(executor._total_usage["peak_context_tokens"], 0)
        self.assertFalse(executor._total_usage["has_unknown_cost"])
        self.assertTrue(executor._total_usage["cost_known"])

    def test_cache_cost_breakdown_survives_workflow_aggregation(self):
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=lambda *args, **kwargs: {}),
            provider=CachedCostProvider(),
        )

        result = executor._chat_with_usage("probe")

        self.assertEqual(result, "cached response")
        self.assertEqual(executor._total_usage["cost_usd"], 0.02)
        self.assertEqual(executor._total_usage["cache_creation_tokens"], 1_000)
        self.assertEqual(executor._total_usage["cache_write_cost_usd"], 0.0125)
        self.assertEqual(executor._total_usage["model_calls"], 1)
        self.assertEqual(executor._total_usage["peak_context_tokens"], 1_012)

    def test_usage_tracks_calls_and_largest_single_call_context(self):
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=lambda *args, **kwargs: {}),
            provider=SequencedUsageProvider(),
        )

        executor._chat_with_usage("first")
        executor._chat_with_usage("second")

        self.assertEqual(executor._total_usage["total_tokens"], 370)
        self.assertEqual(executor._total_usage["model_calls"], 2)
        self.assertEqual(executor._total_usage["peak_context_tokens"], 260)

    def test_workflow_can_disable_provider_native_tools_for_internal_llm_calls(self):
        provider = EnvCapturingProvider()
        executed = []

        previous_xai_disable = os.environ.get("XAI_DISABLE_SERVER_SIDE_TOOLS")
        previous_reasoning_effort = os.environ.get("XAI_REASONING_EFFORT")
        previous_request_timeout = os.environ.get("XAI_REQUEST_TIMEOUT_SECONDS")
        try:
            executor = PipelineExecutor(
                mode="cloud",
                executor=SimpleNamespace(
                    execute=lambda tool, params: executed.append((tool, params))
                    or {"ok": True, "data": {"coin_id": params["coin"]}}
                ),
                provider=provider,
            )
            # The constructor loads cloud.env; set sentinels afterward so this
            # checks workflow restoration regardless of the mode's defaults.
            os.environ["XAI_DISABLE_SERVER_SIDE_TOOLS"] = "previous"
            os.environ["XAI_REASONING_EFFORT"] = "high"
            os.environ["XAI_REQUEST_TIMEOUT_SECONDS"] = "90"
            result = executor.execute(
                {
                    "id": "native_tool_free_internal_llm",
                    "disable_server_side_tools": True,
                    "workflow_llm_options": {
                        "xai_reasoning_effort": "low",
                        "xai_request_timeout_seconds": 600,
                    },
                    "steps": [
                        {
                            "step": 1,
                            "tool": "crypto_price",
                            "params": {},
                            "llm_prompt": "Extract the second crypto coin.",
                            "extract": {"coin_id": "coin_id"},
                        }
                    ],
                },
                "/crypto bitcoin solana",
            )
            restored_xai_disable = os.environ.get("XAI_DISABLE_SERVER_SIDE_TOOLS")
            restored_reasoning_effort = os.environ.get("XAI_REASONING_EFFORT")
            restored_request_timeout = os.environ.get("XAI_REQUEST_TIMEOUT_SECONDS")
        finally:
            if previous_xai_disable is None:
                os.environ.pop("XAI_DISABLE_SERVER_SIDE_TOOLS", None)
            else:
                os.environ["XAI_DISABLE_SERVER_SIDE_TOOLS"] = previous_xai_disable
            if previous_reasoning_effort is None:
                os.environ.pop("XAI_REASONING_EFFORT", None)
            else:
                os.environ["XAI_REASONING_EFFORT"] = previous_reasoning_effort
            if previous_request_timeout is None:
                os.environ.pop("XAI_REQUEST_TIMEOUT_SECONDS", None)
            else:
                os.environ["XAI_REQUEST_TIMEOUT_SECONDS"] = previous_request_timeout

        self.assertTrue(result["ok"])
        self.assertEqual(executed, [("crypto_price", {"coin": "solana"})])
        self.assertEqual(provider.calls[0]["tools"], [])
        self.assertFalse(provider.calls[0]["enable_search"])
        self.assertEqual(provider.calls[0]["xai_disabled"], "true")
        self.assertEqual(provider.calls[0]["openai_disabled"], "true")
        self.assertEqual(provider.calls[0]["xai_search_override"], "false")
        self.assertEqual(provider.calls[0]["anthropic_search_override"], "false")
        self.assertEqual(provider.calls[0]["xai_reasoning_effort"], "low")
        self.assertEqual(provider.calls[0]["xai_request_timeout"], "600")
        self.assertEqual(provider.calls[0]["resolved_xai_reasoning_effort"], "low")
        self.assertEqual(provider.calls[0]["resolved_xai_request_timeout"], "600")
        self.assertTrue(provider.enable_search)
        self.assertEqual(restored_xai_disable, "previous")
        self.assertEqual(restored_reasoning_effort, "high")
        self.assertEqual(restored_request_timeout, "90")

    def test_workflow_internal_llm_provider_error_aborts_before_tool_execution(self):
        executed = []
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(
                execute=lambda tool, params: executed.append((tool, params))
                or {"ok": True}
            ),
            provider=ErrorTextProvider(),
        )

        result = executor.execute(
            {
                "id": "workflow_llm_error",
                "steps": [
                    {
                        "step": 1,
                        "tool": "stash",
                        "action": "save",
                        "params": {"space_id": "space_test"},
                        "llm_prompt": "Generate the report.",
                    }
                ],
            },
            "/workflow_llm_error",
        )

        self.assertFalse(result["ok"])
        self.assertEqual(executed, [])
        self.assertIn("Workflow-internal LLM failed", result["error"])
        self.assertIn("Request timed out", result["error"])

    def test_workflow_llm_options_override_blank_mode_timeout_inside_config_scope(self):
        provider = EnvCapturingProvider()
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(
                execute=lambda _tool, params: {
                    "ok": True,
                    "data": {"coin_id": params["coin"]},
                }
            ),
            provider=provider,
        )

        def scoped_mode_config(mode):
            if mode == "cloud":
                return {
                    "XAI_REASONING_EFFORT": "high",
                    "XAI_REQUEST_TIMEOUT_SECONDS": "",
                }
            return {}

        with (
            patch("config_loader._load_mode_config", side_effect=scoped_mode_config),
            config_scope("cloud"),
        ):
            result = executor.execute(
                {
                    "id": "scoped_workflow_llm_options",
                    "workflow_llm_options": {
                        "xai_reasoning_effort": "low",
                        "xai_request_timeout_seconds": 600,
                    },
                    "steps": [
                        {
                            "step": 1,
                            "tool": "crypto_price",
                            "llm_prompt": "Extract the coin.",
                        }
                    ],
                },
                "/scoped_workflow_llm_options solana",
            )

        self.assertTrue(result["ok"])
        self.assertEqual(provider.calls[0]["resolved_xai_reasoning_effort"], "low")
        self.assertEqual(provider.calls[0]["resolved_xai_request_timeout"], "600")

    def test_workflow_internal_llm_error_fails_validation_closed(self):
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(
                execute=lambda _tool, _params: {
                    "ok": True,
                    "speech": "Fetched candidate content",
                    "data": {"content": "candidate content"},
                }
            ),
            provider=ErrorTextProvider(),
        )

        result = executor.execute(
            {
                "id": "validation_error",
                "steps": [
                    {
                        "step": 1,
                        "tool": "crawl_url",
                        "validation": {
                            "type": "llm",
                            "llm_prompt": "Is this content usable?",
                        },
                    }
                ],
            },
            "/validation_error",
        )

        self.assertFalse(result["ok"])
        self.assertEqual(result["data"]["aborted_at_step"], 1)
        self.assertTrue(result["data"]["results"][0]["data"]["content"])

    def test_workflow_internal_llm_timeout_skips_llm_decided_step(self):
        executed = []
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(
                execute=lambda tool, params: executed.append((tool, params))
                or {"ok": True}
            ),
            provider=TimeoutRaisingProvider(),
        )

        result = executor.execute(
            {
                "id": "decision_error",
                "steps": [
                    {
                        "step": 1,
                        "tool": "send_email",
                        "condition": "${llm_decides}",
                        "llm_prompt": "Should this email be sent?",
                    }
                ],
            },
            "/decision_error",
        )

        self.assertTrue(result["ok"])
        self.assertEqual(executed, [])
        self.assertTrue(result["data"]["results"][0]["skipped"])

    def test_workflow_results_keep_step_actions_for_tool_cards(self):
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(
                execute=lambda *_args, **_kwargs: {"ok": True, "data": {}}
            ),
            provider=DummyProvider(),
        )
        result = executor.execute(
            {
                "id": "existing_page",
                "variables": {"page_id": "saved-page"},
                "steps": [
                    {"step": 1, "tool": "stash", "action": "list", "params": {}},
                    {
                        "step": 2,
                        "tool": "canvas",
                        "action": "create",
                        "condition": {"op": "not_exists", "left": "${page_id}"},
                    },
                    {
                        "step": 3,
                        "tool": "canvas",
                        "action": "update",
                        "condition": {"op": "exists", "left": "${page_id}"},
                    },
                ],
            },
            "/existing_page",
        )

        steps = result["data"]["results"]
        self.assertEqual([step["action"] for step in steps], ["list", "create", "update"])
        self.assertTrue(steps[0]["ok"])
        self.assertTrue(steps[1]["skipped"])
        self.assertTrue(steps[2]["ok"])

    def test_workflow_success_speech_error_uses_static_fallback(self):
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(
                execute=lambda _tool, _params: {"ok": True, "data": {}}
            ),
            provider=ErrorTextProvider(),
        )

        result = executor.execute(
            {
                "id": "speech_error",
                "success_speech_llm_prompt": "Summarize completion.",
                "success_speech": "Workflow completed safely.",
                "steps": [{"step": 1, "tool": "get_time"}],
            },
            "/speech_error",
        )

        self.assertTrue(result["ok"])
        self.assertEqual(result["speech"], "Workflow completed safely.")

    def test_workflow_internal_llm_calls_leave_native_tools_enabled_by_default(self):
        provider = EnvCapturingProvider()
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=lambda *_args, **_kwargs: {"ok": True}),
            provider=provider,
        )

        executor._chat_with_usage("probe")

        self.assertTrue(provider.calls[0]["enable_search"])

    def test_recovered_search_applies_success_variables(self):
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(
                execute=lambda *_args, **_kwargs: {
                    "ok": False,
                    "data": {"results": [{"url": "https://example.test"}]},
                    "error": "temporary search failure",
                }
            ),
            provider=DummyProvider(),
        )

        result = executor.execute(
            {
                "id": "recovered_search_success_variables",
                "steps": [
                    {
                        "step": 1,
                        "tool": "brave_search",
                        "required": False,
                        "output_var": "search_output",
                        "set_variables_on_success": {
                            "search_completed": True,
                        },
                    }
                ],
            },
            "find example",
        )

        self.assertTrue(result["ok"])
        self.assertTrue(result["data"]["results"][0]["ok"])
        self.assertTrue(result["data"]["variables"]["search_completed"])
        self.assertEqual(
            result["data"]["variables"]["search_output"],
            {"results": [{"url": "https://example.test"}]},
        )
        self.assertEqual(
            result["data"]["variables"]["search_results"]["urls"],
            ["https://example.test"],
        )

    def test_search_output_var_preserves_normalized_urls_for_crawl_loop(self):
        calls = []

        def execute(tool, params):
            calls.append((tool, dict(params)))
            if tool == "mcp_brave_search_brave_web_search":
                return {
                    "ok": True,
                    "data": {
                        "results": [
                            {"url": "https://one.example/article"},
                            {"url": "https://two.example/article"},
                        ]
                    },
                }
            if tool == "crawl_url":
                return {
                    "ok": True,
                    "data": {
                        "results": [
                            {
                                "url": params["url"],
                                "markdown": "validated article body " * 20,
                            }
                        ]
                    },
                }
            return {"ok": True, "data": {}}

        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=execute),
            provider=DummyProvider(),
        )

        result = executor.execute(
            {
                "id": "search_to_crawl",
                "steps": [
                    {
                        "step": 1,
                        "tool": "mcp_brave_search_brave_web_search",
                        "params": {"query": "crypto news", "count": 2},
                        "output_var": "search_results",
                    },
                    {
                        "step": 2,
                        "tool": "crawl_url",
                        "for_each": "${search_results.urls[:2]}",
                        "output_var": "articles",
                        "validated_output_var": "validated_articles",
                        "validation": {
                            "type": "heuristic",
                            "heuristic": {"min_length": 20},
                        },
                        "process_all": True,
                    },
                ],
            },
            "research crypto news",
        )

        crawled_urls = [
            params["url"] for tool, params in calls if tool == "crawl_url"
        ]
        self.assertTrue(result["ok"])
        self.assertEqual(
            crawled_urls,
            ["https://one.example/article", "https://two.example/article"],
        )
        self.assertEqual(
            result["data"]["variables"]["search_results"]["urls"],
            ["https://one.example/article", "https://two.example/article"],
        )
        self.assertEqual(len(result["data"]["variables"]["validated_articles"]), 2)

    def test_crawl_output_var_preserves_flattened_content_for_followup_params(self):
        content = "Fetched article content " * 20
        calls = []

        def execute(tool, params):
            calls.append((tool, dict(params)))
            if tool == "crawl_url":
                return {
                    "ok": True,
                    "data": {
                        "results": [
                            {
                                "title": "Fetched Title",
                                "url": "https://example.test/page",
                                "markdown": content,
                            }
                        ]
                    },
                }
            if tool == "stash":
                return {"ok": True, "data": {"ref": "stash://space/file"}}
            return {"ok": True, "data": {}}

        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=execute),
            provider=DummyProvider(),
        )

        result = executor.execute(
            {
                "id": "crawl_to_stash",
                "steps": [
                    {
                        "step": 1,
                        "tool": "crawl_url",
                        "params": {"url": "https://example.test/page"},
                        "output_var": "article",
                    },
                    {
                        "step": 2,
                        "tool": "stash",
                        "action": "save",
                        "params": {
                            "kind": "text",
                            "text": "${article.content}",
                            "name": "article.txt",
                        },
                    },
                ],
            },
            "archive https://example.test/page",
        )

        stash_params = next(params for tool, params in calls if tool == "stash")
        self.assertTrue(result["ok"])
        self.assertEqual(stash_params["text"], content)
        self.assertEqual(result["data"]["variables"]["article"]["content"], content)
        self.assertEqual(
            result["data"]["variables"]["article"]["url"],
            "https://example.test/page",
        )

    def test_extract_by_path_supports_indexed_array_segments(self):
        data = {
            "results": [
                {"url": "https://first.example", "metadata": {"title": "First"}},
                {"url": "https://second.example", "metadata": {"title": "Second"}},
            ]
        }

        self.assertEqual(
            self.executor._extract_by_path(data, "results[0].url"),
            "https://first.example",
        )
        self.assertEqual(
            self.executor._extract_by_path(data, "results[1].metadata.title"),
            "Second",
        )
        self.assertIsNone(self.executor._extract_by_path(data, "results[2].url"))

    def test_output_transforms_apply_indexed_extract_paths(self):
        variables = {}
        result = {
            "ok": True,
            "data": {
                "results": [
                    {"url": "https://first.example", "markdown": "# First"},
                    {"url": "https://second.example", "markdown": "# Second"},
                ]
            },
        }

        self.executor._apply_output_transforms(
            {
                "extract": {
                    "first_url": "results[0].url",
                    "second_markdown": "results[1].markdown",
                    "all_urls": "results[*].url",
                }
            },
            result,
            variables,
            "example_tool",
            None,
        )

        self.assertEqual(variables["first_url"], "https://first.example")
        self.assertEqual(variables["second_markdown"], "# Second")
        self.assertEqual(
            variables["all_urls"],
            ["https://first.example", "https://second.example"],
        )

    def test_process_all_for_each_runs_every_item(self):
        calls = []

        def execute(tool, params):
            calls.append((tool, params["value"]))
            return {"ok": True, "data": {"saved": params["value"]}}

        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=execute),
            provider=None,
        )
        result = executor._execute_for_each(
            {
                "tool": "stash",
                "for_each": "${items}",
                "process_all": True,
                "params": {},
            },
            "stash",
            None,
            {},
            {"items": [{"value": "one"}, {"value": "two"}]},
            {},
            0,
            10,
        )

        self.assertEqual(calls, [("stash", "one"), ("stash", "two")])
        self.assertEqual(result["items_succeeded"], 2)

    def test_process_all_for_each_handles_missing_items(self):
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=lambda *_args, **_kwargs: {}),
            provider=None,
        )

        result = executor._execute_for_each(
            {
                "tool": "stash",
                "for_each": "${missing_items}",
                "process_all": True,
                "params": {},
            },
            "stash",
            None,
            {},
            {},
            {},
            0,
            10,
        )

        self.assertEqual(result["items_processed"], 0)
        self.assertEqual(result["items_succeeded"], 0)
        self.assertEqual(result["outputs"], [])
        self.assertFalse(result["abort"])

    def test_for_each_respects_explicit_step_max_attempts(self):
        calls = []

        def execute(_tool, params):
            calls.append(params["url"])
            return {"ok": False, "error": "unavailable"}

        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=execute),
            provider=None,
        )
        result = executor._execute_for_each(
            {
                "tool": "crawl_url",
                "for_each": "${urls}",
                "params": {},
                "retry": {"max_attempts": 2, "strategy": "next_url"},
                "required_success_count": 1,
                "on_all_fail": "abort_with_message",
            },
            "crawl_url",
            None,
            {},
            {"urls": ["https://one.test", "https://two.test", "https://three.test"]},
            {},
            0,
            10,
        )

        self.assertEqual(calls, ["https://one.test", "https://two.test"])
        self.assertEqual(result["items_processed"], 2)
        self.assertEqual(result["retries"], 2)
        self.assertTrue(result["abort"])

    def test_for_each_default_required_failure_aborts_before_later_step(self):
        calls = []

        def execute(tool, _params):
            calls.append(tool)
            if tool == "always_fail":
                return {"ok": False, "error": "probe failure"}
            return {"ok": True, "data": {"ran": True}}

        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=execute),
            provider=None,
        )
        workflow = {
            "id": "for_each_failure_probe",
            "name": "for_each failure probe",
            "abort_speech": "Workflow aborted",
            "success_speech": "Workflow reported success",
            "steps": [
                {
                    "step": 1,
                    "tool": "always_fail",
                    "for_each": "${items}",
                    "output_var": "attempts",
                },
                {
                    "step": 2,
                    "tool": "must_not_run",
                    "required": True,
                },
            ],
        }

        with patch.object(
            executor,
            "_extract_workflow_variables",
            return_value={"items": ["one", "two"]},
        ):
            result = executor.execute(workflow, "probe")

        self.assertFalse(result["ok"])
        self.assertEqual(result["speech"], "Workflow aborted")
        self.assertEqual(calls, ["always_fail", "always_fail"])
        self.assertIn("0 of 2", result["error"])
        self.assertIn("probe failure", result["error"])
        self.assertEqual(result["tools_used"], ["always_fail"])
        failed_step = result["data"]["results"][0]
        self.assertEqual(failed_step["step"], 1)
        self.assertFalse(failed_step["ok"])
        self.assertEqual(failed_step["items_processed"], 2)
        self.assertEqual(failed_step["items_succeeded"], 0)
        self.assertEqual([output["error"] for output in failed_step["outputs"]], ["probe failure"] * 2)
        self.assertEqual(failed_step["error"], result["error"])
        self.assertIn("probe failure", result["data"]["reason"])

    def test_for_each_partial_failure_reports_attempts_before_abort(self):
        responses = iter([
            {"ok": True, "data": {"url": "https://one.test"}},
            {"ok": False, "error": "second source unavailable"},
        ])
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=lambda *_args: next(responses)),
            provider=None,
        )
        workflow = {
            "id": "for_each_partial_failure_probe",
            "name": "for_each partial failure probe",
            "steps": [{
                "step": 1,
                "tool": "crawl_url",
                "for_each": "${items}",
                "required_success_count": 2,
            }],
        }

        with patch.object(
            executor,
            "_extract_workflow_variables",
            return_value={"items": ["https://one.test", "https://two.test"]},
        ):
            result = executor.execute(workflow, "probe")

        self.assertFalse(result["ok"])
        self.assertIn("1 of 2", result["error"])
        self.assertIn("second source unavailable", result["error"])
        failed_step = result["data"]["results"][0]
        self.assertEqual(failed_step["items_processed"], 2)
        self.assertEqual(failed_step["items_succeeded"], 1)
        self.assertEqual([output["ok"] for output in failed_step["outputs"]], [True, False])

    def test_for_each_failure_honors_required_and_continue_overrides(self):
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(
                execute=lambda *_args, **_kwargs: {"ok": False, "error": "failed"}
            ),
            provider=None,
        )
        step = {
            "tool": "probe",
            "for_each": "${items}",
        }

        def execute(overrides):
            return executor._execute_for_each(
                {**step, **overrides},
                "probe",
                None,
                {},
                {"items": ["one"]},
                {},
                0,
                10,
            )

        self.assertTrue(execute({})["abort"])
        self.assertFalse(execute({"required": False})["abort"])
        self.assertFalse(execute({"on_fail": "continue"})["abort"])
        self.assertFalse(execute({"on_all_fail": "continue"})["abort"])
        self.assertTrue(
            execute({"required": False, "on_all_fail": "abort_with_message"})[
                "abort"
            ]
        )

    def test_for_each_empty_items_honors_on_all_fail_abort(self):
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=lambda *_args, **_kwargs: {"ok": True}),
            provider=None,
        )
        step = {
            "tool": "crawl_url",
            "for_each": "${urls}",
            "on_all_fail": "abort_with_message",
            "required_success_count": 1,
        }

        empty_result = executor._execute_for_each(
            step, "crawl_url", None, {}, {"urls": []}, {}, 0, 10
        )
        self.assertTrue(empty_result["abort"])
        self.assertEqual(empty_result["validated_outputs"], [])

        missing_result = executor._execute_for_each(
            step, "crawl_url", None, {}, {}, {}, 0, 10
        )
        self.assertTrue(missing_result["abort"])

        continue_step = {**step, "on_all_fail": "continue"}
        continue_result = executor._execute_for_each(
            continue_step, "crawl_url", None, {}, {"urls": []}, {}, 0, 10
        )
        self.assertFalse(continue_result["abort"])

    def test_for_each_still_respects_workflow_retry_budget(self):
        calls = []
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(
                execute=lambda _tool, params: calls.append(params["url"])
                or {"ok": False}
            ),
            provider=None,
        )

        result = executor._execute_for_each(
            {
                "tool": "crawl_url",
                "for_each": "${urls}",
                "retry": {"max_attempts": 5},
            },
            "crawl_url",
            None,
            {},
            {"urls": ["https://one.test", "https://two.test"]},
            {},
            3,
            3,
        )

        self.assertEqual(calls, [])
        self.assertEqual(result["items_processed"], 0)

    def test_non_crawl_for_each_does_not_replace_validated_articles(self):
        article = {"ok": True, "data": {"results": [{"url": "https://example.test", "markdown": "source"}]}}
        variables = {"validated_articles": [article], "items": [{"value": "saved"}]}
        workflow = {
            "id": "preserve_articles",
            "steps": [
                {
                    "step": 1,
                    "tool": "stash",
                    "for_each": "${items}",
                    "process_all": True,
                    "output_var": "saved_files",
                }
            ],
        }
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=lambda *_args, **_kwargs: {"ok": True, "data": {"saved": True}}),
            provider=None,
        )

        step = workflow["steps"][0]
        step_result = executor._execute_for_each(step, "stash", None, {}, variables, {}, 0, 10)
        executor._store_validated_outputs(step, "stash", step_result, variables)

        self.assertEqual(variables["validated_articles"], [article])
        formatted = executor._format_articles_for_llm(variables["validated_articles"])
        self.assertIn("https://example.test", formatted)
        self.assertIn("source", formatted)

    def test_empty_explicit_validated_outputs_are_available_to_llm_prompts(self):
        provider = PromptCapturingProvider(response="rendered report")
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=lambda *_args, **_kwargs: {"ok": True}),
            provider=provider,
        )
        variables = {}
        step = {
            "tool": "crawl_url",
            "validated_output_var": "validated_articles",
        }

        executor._store_validated_outputs(
            step,
            "crawl_url",
            {"validated_outputs": []},
            variables,
        )
        params = executor._llm_fill_params(
            {
                "tool": "canvas",
                "llm_prompt": "News input:\n${validated_articles}",
            },
            variables,
        )

        self.assertEqual(variables["validated_articles"], [])
        self.assertEqual(params["content"], "rendered report")
        self.assertIn("[No articles gathered]", provider.prompts[0])
        self.assertNotIn("${validated_articles}", provider.prompts[0])

    def test_llm_prompt_structured_variable_limit_can_be_raised_per_step(self):
        provider = PromptCapturingProvider(response="rendered report")
        executor = PipelineExecutor(
            mode="cloud",
            executor=SimpleNamespace(execute=lambda *_args, **_kwargs: {"ok": True}),
            provider=provider,
        )
        variables = {"products": [{"description": "x" * 4_000}]}

        executor._llm_fill_params(
            {
                "tool": "canvas",
                "llm_prompt": "Products:\n${products}",
            },
            variables,
        )
        default_prompt = provider.prompts[-1]

        executor._llm_fill_params(
            {
                "tool": "canvas",
                "llm_variable_max_chars": 5_000,
                "llm_prompt": "Products:\n${products}",
            },
            variables,
        )
        expanded_prompt = provider.prompts[-1]

        self.assertLess(len(default_prompt), len(expanded_prompt))
        self.assertNotIn("x" * 3_200, default_prompt)
        self.assertIn("x" * 3_200, expanded_prompt)

    def test_builtin_research_workflows_declare_validated_article_ownership(self):
        workflows_dir = PROJECT_ROOT / "data" / "workflows"
        deep = json.loads((workflows_dir / "deep_research.json").read_text())
        crypto = json.loads((workflows_dir / "crypto_market_report.json").read_text())

        deep_crawl = next(step for step in deep["steps"] if step["tool"] == "crawl_url")
        deep_stash = next(
            step for step in deep["steps"]
            if step["tool"] == "stash" and step.get("action") == "save"
        )
        crypto_crawl = next(step for step in crypto["steps"] if step["tool"] == "crawl_url")

        self.assertTrue(crypto["disable_server_side_tools"])
        self.assertNotIn("helper_llm", crypto)
        self.assertEqual(
            crypto["workflow_llm_options"]["xai_reasoning_effort"], "low"
        )
        self.assertEqual(
            crypto["workflow_llm_options"]["xai_request_timeout_seconds"], 600
        )
        self.assertEqual(deep_crawl["validated_output_var"], "validated_articles")
        self.assertTrue(deep_stash["process_all"])
        self.assertEqual(crypto_crawl["validated_output_var"], "validated_articles")

        deep_canvas = next(step for step in deep["steps"] if step["tool"] == "canvas")
        crypto_canvas = next(step for step in crypto["steps"] if step["tool"] == "canvas")
        self.assertEqual(deep_canvas["llm_output_validation"]["param"], "content")
        for required_pattern in crypto_canvas["llm_output_validation"][
            "required_patterns"
        ]:
            self.assertIn(required_pattern, crypto_canvas["llm_prompt"])

    def test_github_ai_radar_refreshes_single_canvas_page(self):
        workflow = json.loads(
            (PROJECT_ROOT / "data" / "workflows" / "github_ai_radar_daily.json").read_text()
        )
        canvas_steps = [step for step in workflow["steps"] if step["tool"] == "canvas"]
        canvas_actions = [step.get("action") for step in canvas_steps]
        brave_step = next(
            step for step in workflow["steps"]
            if step["tool"] == "mcp_brave_search_brave_web_search"
        )
        youtube_step = next(
            step for step in workflow["steps"] if step["tool"] == "serpapi_youtube_search"
        )

        self.assertEqual(canvas_actions, ["read", "create", "update"])
        self.assertNotIn("append", canvas_actions)
        self.assertEqual(canvas_steps[1]["condition"]["op"], "not_exists")
        self.assertEqual(canvas_steps[2]["condition"]["op"], "exists")
        self.assertEqual(canvas_steps[2]["params"]["page_id"], "${radar_page_id}")
        self.assertTrue(canvas_steps[2]["params"]["allow_content_shrink"])
        self.assertTrue(workflow["disable_server_side_tools"])
        self.assertTrue(brave_step["required"])
        self.assertEqual(brave_step["output_var"], "search_results")
        self.assertFalse(youtube_step["required"])
        self.assertEqual(youtube_step["on_fail"], "continue")
        self.assertEqual(youtube_step["params"]["search_query"], "${youtube_query}")
        self.assertEqual(youtube_step["extract"]["youtube_top_url"], "top_url")
        self.assertEqual(youtube_step["extract"]["youtube_top_results"], "top_results")

        fresh_step = next(
            step for step in workflow["steps"]
            if step["tool"] == "stash" and step.get("llm_prompt")
        )
        self.assertEqual(canvas_steps[1]["params"]["content"].split("\n")[0], "${fresh_radar_content}")
        self.assertNotIn("llm_prompt", canvas_steps[1])
        history_step = next(
            step for step in workflow["steps"]
            if step["tool"] == "stash" and step.get("description", "").startswith("Summarize previous runs")
        )
        self.assertNotIn("${radar_existing_content}", fresh_step["llm_prompt"])
        self.assertIn("tavily search results", fresh_step["llm_prompt"].lower())
        self.assertIn("${radar_existing_content}", history_step["llm_prompt"])
        self.assertNotIn("${fresh_radar_content}", history_step["llm_prompt"])
        self.assertNotIn("llm_prompt", canvas_steps[2])
        self.assertEqual(canvas_steps[2]["params"]["content"], "${fresh_radar_content}\n\n${radar_history_content}")
        self.assertIn("<summary>Advanced details</summary>", fresh_step["llm_prompt"])
        self.assertIn("<summary>Recent history</summary>", history_step["llm_prompt"])
        self.assertEqual(youtube_step["search_output_var"], "youtube_search_results")
        for step in [fresh_step, history_step]:
            rejects = step["llm_output_validation"]["reject_patterns"]
            self.assertIn("```", rejects)
            self.assertIn("<!doctype", rejects)
            self.assertIn("<html", rejects)


    def test_jarvis_self_check_uses_health_issues_alerts_and_single_canvas_page(self):
        workflow = json.loads(
            (PROJECT_ROOT / "data" / "workflows" / "jarvis_self_check.json").read_text()
        )

        health_step = next(step for step in workflow["steps"] if step["tool"] == "system_monitor")
        alert_step = next(step for step in workflow["steps"] if step["tool"] == "create_alert")
        canvas_steps = [step for step in workflow["steps"] if step["tool"] == "canvas"]
        canvas_actions = [step.get("action") for step in canvas_steps]
        step_tools = [step["tool"] for step in workflow["steps"]]

        self.assertEqual(health_step["params"]["action"], "health_check")
        self.assertEqual(health_step["extract"]["issue_count"], "issue_count")
        self.assertEqual(health_step["extract"]["alert_severity"], "alert_severity")
        self.assertEqual(health_step["extract"]["alert_dedupe_key"], "alert_dedupe_key")
        self.assertLess(step_tools.index("canvas"), step_tools.index("create_alert"))
        self.assertEqual(alert_step["condition"]["op"], "gte")
        self.assertEqual(alert_step["condition"]["left"], "${issue_count}")
        self.assertEqual(alert_step["condition"]["right"], 1)
        self.assertEqual(alert_step["params"]["severity"], "${alert_severity}")
        self.assertEqual(alert_step["params"]["metadata"]["dedupe_key"], "${alert_dedupe_key}")
        self.assertTrue(alert_step["required"])
        self.assertEqual(canvas_actions, ["read", "create", "update"])
        self.assertEqual(canvas_steps[1]["condition"]["op"], "not_exists")
        self.assertEqual(canvas_steps[2]["condition"]["op"], "exists")
        self.assertTrue(all(step["required"] for step in canvas_steps))
        self.assertTrue(canvas_steps[2]["params"]["allow_content_shrink"])
        self.assertIn("## Current Status", canvas_steps[2]["params"]["content"])
        self.assertIn("## Active Issues", canvas_steps[2]["params"]["content"])
        self.assertIn("## Alert Policy", canvas_steps[2]["params"]["content"])
        self.assertIn("## Raw Health Snapshot", canvas_steps[2]["params"]["content"])
        self.assertIn("## Run Log", canvas_steps[2]["params"]["content"])

    def test_opt_in_llm_output_validation_rejects_refusal_content(self):
        step = {
            "llm_output_validation": {
                "param": "content",
                "min_length": 20,
                "reject_patterns": ["unable to complete this research summary"],
            }
        }
        error = self.executor._validate_llm_filled_params(
            step,
            {"content": "I am unable to complete this research summary without URLs."},
        )
        self.assertIn("refusal", error)

    def test_opt_in_llm_output_validation_requires_structure(self):
        step = {
            "llm_output_validation": {
                "param": "content",
                "min_length": 20,
                "required_patterns": ["# GitHub AI Radar", "## Run Log"],
            }
        }

        error = self.executor._validate_llm_filled_params(
            step,
            {"content": "# GitHub AI Radar\n\n## Sources\nA source list without the log."},
        )
        self.assertIn("missing required structure", error)

        error = self.executor._validate_llm_filled_params(
            step,
            {"content": "# GitHub AI Radar\n\n## Run Log\nA complete enough update."},
        )
        self.assertIsNone(error)

    def test_llm_output_validation_is_opt_in(self):
        self.assertIsNone(
            self.executor._validate_llm_filled_params({}, {"content": "short"})
        )


if __name__ == "__main__":
    unittest.main()

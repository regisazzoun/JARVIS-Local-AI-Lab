#!/usr/bin/env python3
"""Regression tests for in-flight tool turn budgets."""

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from zoneinfo import ZoneInfo


PROJECT_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / "orchestrator"))

from orchestrator_v2 import Orchestrator


class FakeExecutor:
    def __init__(self, fail_on_calls=None):
        self.calls = 0
        self.fail_on_calls = set(fail_on_calls or [])

    def set_excluded_tools(self, _tools):
        pass

    def set_allowed_tools(self, tools):
        self.allowed_tools = tools

    def execute(self, tool_name, arguments):
        self.calls += 1
        if self.calls not in self.fail_on_calls:
            return {
                "ok": True,
                "speech": f"{tool_name} succeeded.",
                "data": {"call": self.calls},
            }
        return {
            "ok": False,
            "error": "SerpApi error: Yelp hasn't returned any results for this query.",
            "speech": "No Yelp results.",
            "data": {},
        }


class FakeRouter:
    provider_type = "test"
    model_name = "fake-model"
    system_prompt_version = "test"
    provider = None

    def __init__(self, tool_name="serpapi_yelp_search", usage_info=None):
        self.calls = 0
        self.tool_name = tool_name
        self.usage_info = usage_info or {
            "input_tokens": 1,
            "output_tokens": 1,
            "total_tokens": 2,
        }

    def route(self, *_args, **_kwargs):
        self.calls += 1
        return {
            "intent": "tool",
            "tool_name": self.tool_name,
            "arguments": {"find_desc": f"arcade games kids {self.calls}"},
            "usage_info": self.usage_info,
        }


class FakeStatusUpdater:
    def reset(self):
        pass

    def set_turn(self, _turn):
        pass

    def update(self, **_kwargs):
        pass

    def update_error(self, **_kwargs):
        pass

    def mark_complete(self):
        pass


class ToolTurnBudgetTests(unittest.TestCase):
    def test_request_allowlist_survives_retry_and_disables_workflows_and_hosted_tools(self):
        orchestrator = self._build_orchestrator(fail_on_calls={1}, tool_name="stock_price")
        orchestrator.registry = SimpleNamespace(list_tools=lambda: ["stock_price", "send_email"], get_tool=lambda _name: None)
        orchestrator._try_workflow = lambda _query: self.fail("Restricted request dispatched a workflow")
        allowed = []
        original_set = orchestrator.executor.set_allowed_tools
        orchestrator.executor.set_allowed_tools = lambda tools: (allowed.append(tools), original_set(tools))
        routes = []
        original_route = orchestrator.router.route
        def route(*args, **kwargs):
            routes.append(kwargs)
            return original_route(*args, **kwargs)
        orchestrator.router.route = route
        with patch("orchestrator_v2.get_int", side_effect=lambda key, default=0: 2 if key == "MAX_TOOL_TURNS" else default):
            orchestrator.process("/some_workflow stock price", allowed_tools=["stock_price"])
        self.assertGreaterEqual(len(allowed), 2)
        self.assertTrue(all(names == ["stock_price"] for names in allowed))
        self.assertTrue(all(call["disable_server_side_tools"] for call in routes))
        self.assertTrue(all("send_email" in call["excluded_tools"] for call in routes))

    def test_webhook_retry_router_receives_nested_payload_contract(self):
        orchestrator = self._build_orchestrator(fail_on_calls=set(), tool_name='send_webhook')
        pattern = r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$'
        schema = {'type': 'object', 'properties': {'notification': {'type': 'object',
                  'properties': {'scheduled_at': {'type': 'string', 'pattern': pattern}}}}}
        failure = {'ok': False, 'error': 'Missing required notification field. No webhook was sent.',
                   'data': {'webhook': 'sample_notification', 'request_sent': False,
                            'required_fields': ['notification'], 'payload_schema': schema,
                            'example': {'notification': {'scheduled_at': '2030-01-01T12:00:00Z'}}}}
        orchestrator.executor.execute = lambda *_args: failure
        transcripts = []

        def route(query, **_kwargs):
            transcripts.append(query)
            if len(transcripts) == 1:
                return {'intent': 'tool', 'tool_name': 'send_webhook',
                        'arguments': {'webhook': 'sample_notification', 'data': {}}}
            return {'intent': 'qa', 'text_response': 'The payload needs correction.'}

        orchestrator.router.route = route
        result = self._run_with_max_turns(orchestrator, 3)
        self.assertEqual(len(transcripts), 2)
        self.assertIn('payload_schema', transcripts[1])
        self.assertIn('scheduled_at', transcripts[1])
        self.assertEqual(result['tool_trace'][0]['result_data']['payload_schema'], schema)

    def test_uncertain_webhook_delivery_never_automatically_retries(self):
        orchestrator = self._build_orchestrator(fail_on_calls=set(), tool_name='send_webhook')
        calls = []

        def execute(*args):
            calls.append(args)
            return {'ok': False, 'error': 'Delivery is unknown; check the destination before retrying.',
                    'data': {'request_sent': None, 'delivery_status': 'unknown', 'retry_safe': False}}

        orchestrator.executor.execute = execute
        result = self._run_with_max_turns(orchestrator, 4)
        self.assertTrue(result['terminal_failure'])
        self.assertEqual(len(calls), 1)
        self.assertEqual(orchestrator.router.calls, 1)

    def _build_orchestrator(self, *, fail_on_calls, tool_name="serpapi_yelp_search"):
        orchestrator = Orchestrator.__new__(Orchestrator)
        orchestrator.executor = FakeExecutor(fail_on_calls=fail_on_calls)
        orchestrator.router = FakeRouter(tool_name=tool_name)
        orchestrator.status_updater = FakeStatusUpdater()
        orchestrator.max_retries = 1
        orchestrator.timezone = ZoneInfo("America/Los_Angeles")
        orchestrator.auto_context_enabled = False
        orchestrator._last_experience_id = None
        orchestrator.session_id = "test-session"
        orchestrator.web_conversation_id = "test-conv"
        orchestrator.progress_callback = None
        orchestrator.cancel_check = None
        orchestrator.learning_enabled = False

        orchestrator._try_workflow = lambda _transcript: None
        orchestrator._get_relevant_memories_bundle = lambda _transcript: {"context": "", "meta": {}}
        orchestrator._get_learning_insights = lambda _transcript, _available_tools: ("", [])
        orchestrator._format_max_turns_summary = lambda *_args: "Reached max turns."
        orchestrator._log_conversation = lambda *_args, **_kwargs: None
        orchestrator._maybe_collect_feedback = lambda result, _transcript: result
        return orchestrator

    def _run_with_max_turns_and_retries(self, orchestrator, max_turns, max_retries):
        orchestrator.max_retries = max_retries

        def fake_get_int(key, default=0):
            return max_turns if key == "MAX_TOOL_TURNS" else default

        with patch("orchestrator_v2.get_int", side_effect=fake_get_int):
            result = orchestrator.process("find local activities")
        return result

    def _run_with_max_turns(self, orchestrator, max_turns):
        return self._run_with_max_turns_and_retries(orchestrator, max_turns, orchestrator.max_retries)

    def test_tool_failure_retry_does_not_reset_max_tool_turn_budget(self):
        orchestrator = self._build_orchestrator(fail_on_calls={1})

        result = self._run_with_max_turns(orchestrator, 1)

        self.assertTrue(result["max_turns_reached"])
        self.assertEqual(orchestrator.router.calls, 1)
        self.assertEqual(orchestrator.executor.calls, 1)
        self.assertEqual(result["tool_trace"][0]["tool"], "serpapi_yelp_search")
        self.assertFalse(result["tool_trace"][0]["ok"])

    def test_search_hint_tools_reach_final_response_for_guard(self):
        orchestrator = self._build_orchestrator(fail_on_calls=set())
        orchestrator.router.route = lambda *_args, **_kwargs: {
            "intent": "qa",
            "text_response": "Both search tools are enabled.",
            "available_tools": ["tool_search", "searxng_search"],
            "web_search_hint_tools": ["searxng_search", "tavily_search"],
            "usage_info": {"input_tokens": 1, "output_tokens": 1, "total_tokens": 2},
        }

        result = self._run_with_max_turns(orchestrator, 1)

        self.assertEqual(result["available_tools"], ["tool_search", "searxng_search"])
        self.assertEqual(result["web_search_hint_tools"], ["searxng_search", "tavily_search"])

    def test_web_tool_hint_wrapper_is_not_used_for_memory_retrieval(self):
        orchestrator = self._build_orchestrator(fail_on_calls=set())
        memory_queries = []
        intelligence_queries = []
        orchestrator._get_relevant_memories_bundle = lambda query: (
            memory_queries.append(query) or {"context": "", "meta": {}}
        )
        orchestrator._get_learning_insights = lambda query, _available_tools: (
            intelligence_queries.append(query) or ("", [])
        )
        prompt = (
            "[CONTEXT - Tool preference for this request]\n\n"
            "Selected tool hints: canvas.\n\n"
            "[END CONTEXT]\n\n"
            "User's request: Find local activities"
        )

        with patch(
            "orchestrator_v2.get_int",
            side_effect=lambda key, default=0: 1 if key == "MAX_TOOL_TURNS" else default,
        ):
            orchestrator.process(prompt)

        self.assertEqual(memory_queries, ["Find local activities"])
        self.assertEqual(intelligence_queries, ["Find local activities"])

    def test_mid_budget_failure_retry_uses_only_remaining_turns(self):
        orchestrator = self._build_orchestrator(fail_on_calls={3})

        result = self._run_with_max_turns(orchestrator, 5)

        self.assertTrue(result["max_turns_reached"])
        self.assertEqual(orchestrator.router.calls, 5)
        self.assertEqual(orchestrator.executor.calls, 5)
        self.assertEqual([entry["ok"] for entry in result["tool_trace"]], [True, True, False, True, True])

    def test_last_turn_failure_retry_has_no_extra_router_turn(self):
        orchestrator = self._build_orchestrator(fail_on_calls={3})

        result = self._run_with_max_turns(orchestrator, 3)

        self.assertTrue(result["max_turns_reached"])
        self.assertEqual(orchestrator.router.calls, 3)
        self.assertEqual(orchestrator.executor.calls, 3)
        self.assertEqual([entry["ok"] for entry in result["tool_trace"]], [True, True, False])

    def test_web_denial_preserves_completed_call_and_stops_before_next_execution(self):
        orchestrator = self._build_orchestrator(fail_on_calls=set())
        orchestrator.router.tool_name = 'safe_read'
        original_route = orchestrator.router.route

        def route(*args, **kwargs):
            result = original_route(*args, **kwargs)
            if orchestrator.router.calls == 2:
                result['tool_name'] = 'api_call'
                result['arguments'] = {'url': 'https://example.test', 'method': 'GET'}
            return result

        orchestrator.router.route = route
        orchestrator.registry = SimpleNamespace(get_tool=lambda name: SimpleNamespace(
            permissions={'auto_approve': name != 'api_call', 'network': name == 'api_call'}))
        decisions = []
        events = []
        orchestrator.set_progress_callback(lambda event, **fields: events.append((event, fields)))
        orchestrator.set_tool_approval_callback(lambda tool, args, permissions, index: (
            decisions.append((tool, args, permissions, index)) or 'denied'))

        result = self._run_with_max_turns(orchestrator, 4)

        self.assertEqual(orchestrator.executor.calls, 1)
        self.assertEqual(orchestrator.router.calls, 2)
        self.assertEqual(result['tools_used'], ['safe_read'])
        self.assertEqual(result['data']['safe_read']['call'], 1)
        self.assertEqual(result['approval_outcome'], {'tool': 'api_call', 'decision': 'denied'})
        self.assertTrue(result['cancelled'])
        self.assertIn('safe_read', result['speech'])
        self.assertEqual(len(decisions), 1)
        self.assertFalse(any(event == 'tool_start' and fields.get('tool') == 'api_call'
                             for event, fields in events))

    def test_web_approval_executes_the_same_prepared_call_once(self):
        orchestrator = self._build_orchestrator(fail_on_calls=set(), tool_name='api_call')
        orchestrator.registry = SimpleNamespace(get_tool=lambda _name: SimpleNamespace(
            permissions={'auto_approve': False, 'network': True}))
        prepared = []
        orchestrator.set_tool_approval_callback(lambda tool, args, _permissions, _index: (
            prepared.append((tool, dict(args))) or 'approved'))

        result = self._run_with_max_turns(orchestrator, 1)

        self.assertEqual(prepared, [('api_call', {'find_desc': 'arcade games kids 1'})])
        self.assertEqual(orchestrator.executor.calls, 1)
        self.assertEqual(result['tools_used'], ['api_call'])

    def test_approval_precedes_running_status(self):
        orchestrator = self._build_orchestrator(fail_on_calls=set(), tool_name='ssh_remote')
        orchestrator.registry = SimpleNamespace(get_tool=lambda _name: SimpleNamespace(
            permissions={'auto_approve': False, 'network': True}))
        order = []
        orchestrator.status_updater.update = lambda **_kwargs: order.append('running')
        orchestrator.set_tool_approval_callback(lambda *_args: order.append('approval') or 'denied')

        self._run_with_max_turns(orchestrator, 1)
        self.assertEqual(order, ['approval'])

        order.clear()
        orchestrator.router.calls = 0
        orchestrator.set_tool_approval_callback(lambda *_args: order.append('approval') or 'approved')
        self._run_with_max_turns(orchestrator, 1)
        self.assertEqual(order, ['approval', 'running'])

    def test_late_terminal_failure_preserves_progress_summary(self):
        orchestrator = self._build_orchestrator(fail_on_calls={3})

        result = self._run_with_max_turns_and_retries(orchestrator, 5, 0)

        self.assertFalse(result["ok"])
        self.assertEqual(orchestrator.router.calls, 3)
        self.assertEqual(orchestrator.executor.calls, 3)
        self.assertIn("Reached max turns.", result["speech"])
        self.assertIn("One final step failed", result["speech"])
        self.assertIn("Serpapi yelp search failed", result["speech"])
        self.assertEqual(result["tools_used"], ["serpapi_yelp_search", "serpapi_yelp_search"])
        self.assertEqual(result["data"]["serpapi_yelp_search"], [{"call": 1}, {"call": 2}])
        self.assertEqual(result["usage"]["model_calls"], 3)
        self.assertEqual(result["usage"]["total_tokens"], 6)

    def test_late_incident_keeps_success_data_and_ordered_failure_diagnosis(self):
        orchestrator = self._build_orchestrator(fail_on_calls={2}, tool_name="serpapi_yelp_search")
        original_execute = orchestrator.executor.execute

        def execute(tool_name, arguments):
            result = original_execute(tool_name, arguments)
            if not result["ok"]:
                result["data"] = {
                    "provider": "SerpApi",
                    "failure_reason": "active_provider_incident",
                    "status_page_url": "https://status.serpapi.com/",
                    "serpapi_incident": {"engine": "yelp", "status": "investigating"},
                    "api_key": "do-not-show",
                }
            return result

        orchestrator.executor.execute = execute
        result = self._run_with_max_turns_and_retries(orchestrator, 3, 0)

        self.assertFalse(result["ok"])
        self.assertEqual(result["data"]["serpapi_yelp_search"], {"call": 1})
        self.assertEqual([entry["ok"] for entry in result["tool_trace"]], [True, False])
        diagnosis = result["tool_trace"][1]["result_data"]
        self.assertEqual(diagnosis["serpapi_incident"]["engine"], "yelp")
        self.assertEqual(diagnosis["api_key"], "[redacted]")

    def test_single_call_terminal_failure_preserves_usage(self):
        orchestrator = self._build_orchestrator(
            fail_on_calls={1},
            tool_name="generate_image",
        )

        result = self._run_with_max_turns_and_retries(orchestrator, 5, 1)

        self.assertFalse(result["ok"])
        self.assertTrue(result["terminal_failure"])
        self.assertEqual(result["tool_name"], "generate_image")
        self.assertEqual(result["usage"]["model_calls"], 1)
        self.assertEqual(result["usage"]["total_tokens"], 2)

    def test_single_call_failure_preserves_earlier_tool_data(self):
        orchestrator = self._build_orchestrator(fail_on_calls={2}, tool_name="safe_read")
        original_route = orchestrator.router.route

        def route(*args, **kwargs):
            result = original_route(*args, **kwargs)
            if orchestrator.router.calls == 2:
                result["tool_name"] = "generate_image"
            return result

        orchestrator.router.route = route

        result = self._run_with_max_turns_and_retries(orchestrator, 5, 1)

        self.assertFalse(result["ok"])
        self.assertEqual(result["tools_used"], ["safe_read", "generate_image"])
        self.assertEqual(result["data"]["safe_read"], {"call": 1})

    def test_reasoning_diagnostic_alone_is_not_counted_as_usage(self):
        orchestrator = self._build_orchestrator(fail_on_calls=set())
        orchestrator.router = FakeRouter(
            usage_info={"reasoning_effort_sent": False},
        )

        result = self._run_with_max_turns(orchestrator, 1)

        self.assertEqual(result["usage"]["model_calls"], 0)
        self.assertEqual(result["usage"]["total_tokens"], 0)
        self.assertEqual(result["usage"]["peak_context_tokens"], 0)


if __name__ == "__main__":
    unittest.main()


def test_ordinary_stop_keeps_original_results_summary_without_web_approval_copy():
    orchestrator = ToolTurnBudgetTests()._build_orchestrator(fail_on_calls=set())
    result = orchestrator._stopped_tool_result(
        tool_name='send_email', decision='cancelled', tools_used=['weather'],
        accumulated_data={'weather': {'temperature': 72}}, tool_trace=[],
        total_usage={}, first_thinking=None,
        conversation_context=[{'summary': 'It is 72 degrees.'}],
    )
    assert result['speech'] == 'Stopped before send_email. Results so far:\n\nIt is 72 degrees.'
    assert result['approval_outcome'] is None
    assert result['data']['weather']['temperature'] == 72


def test_stop_before_routing_keeps_original_turn_summary():
    tests = ToolTurnBudgetTests()
    orchestrator = tests._build_orchestrator(fail_on_calls=set())
    orchestrator.cancel_check = lambda: True
    result = tests._run_with_max_turns(orchestrator, 2)
    assert result['speech'] == 'Processing stopped after 0 turn(s). Results so far:\n\nNo results yet.'
    assert result['cancelled'] is True
    assert 'approval_outcome' not in result


def test_denied_then_approved_prepared_call_reaches_real_tool_subprocess(tmp_path, monkeypatch):
    """The approval boundary controls the ordinary local tool executor."""
    import os
    from executor import ToolExecutor
    from tool_schema import ToolSchema

    script = tmp_path / 'approval_probe.py'
    script.write_text(
        'import json, sys\n'
        'from pathlib import Path\n'
        'args = json.loads(sys.argv[1])\n'
        'Path(args["marker"]).write_text(args["nonce"])\n'
        'print(json.dumps({"ok": True, "speech": "Probe completed.", "data": {"nonce": args["nonce"]}}))\n'
    )
    marker = tmp_path / 'executed.txt'
    schema = ToolSchema(
        name='approval_probe', description='Disposable approval test tool',
        parameters={'type': 'object', 'properties': {'marker': {'type': 'string'}, 'nonce': {'type': 'string'}}},
        script_path=str(script),
        permissions={'dangerous': False, 'bash': False, 'network': False,
                     'filesystem': True, 'auto_approve': False},
    )
    registry = SimpleNamespace(get_tool=lambda name: schema if name == 'approval_probe' else None,
                               is_mcp_tool=lambda _name: False)
    monkeypatch.setattr('executor.export_config_environment',
                        lambda _mode: {'PATH': os.environ.get('PATH', '')})

    def run(decision):
        orchestrator = ToolTurnBudgetTests()._build_orchestrator(
            fail_on_calls=set(), tool_name='approval_probe')
        orchestrator.registry = registry
        orchestrator.executor = ToolExecutor(mode='cloud', registry=registry, load_runtime_config=False)
        orchestrator.executor.skills_dir = tmp_path
        original_route = orchestrator.router.route

        def route(*args, **kwargs):
            prepared = original_route(*args, **kwargs)
            prepared['arguments'] = {'marker': str(marker), 'nonce': 'same-exact-call'}
            return prepared

        orchestrator.router.route = route
        if decision is not None:
            orchestrator.set_tool_approval_callback(lambda *_args: decision)
        return ToolTurnBudgetTests()._run_with_max_turns(orchestrator, 1)

    denied = run('denied')
    assert denied['approval_outcome']['decision'] == 'denied'
    assert not marker.exists()
    approved = run('approved')
    assert approved['tools_used'] == ['approval_probe']
    assert marker.read_text() == 'same-exact-call'
    marker.unlink()
    ordinary_entry_point = run(None)
    assert ordinary_entry_point['tools_used'] == ['approval_probe']
    assert marker.read_text() == 'same-exact-call'


def test_restricted_channel_has_no_operator_memory_or_learning_context():
    from unittest.mock import Mock
    test = ToolTurnBudgetTests()
    orchestrator = test._build_orchestrator(fail_on_calls=set(), tool_name='get_time')
    orchestrator.personal_context_enabled = False
    orchestrator._get_relevant_memories_bundle = Mock(side_effect=AssertionError('operator memories read'))
    orchestrator._get_learning_insights = Mock(side_effect=AssertionError('operator insights read'))
    # Use the real write methods too: they must return before obtaining any DB/hooks.
    orchestrator._log_conversation = Orchestrator._log_conversation.__get__(orchestrator)
    assert orchestrator._record_learning_experience('private request', [], {}, {}, []) == -1
    result = test._run_with_max_turns(orchestrator, 1)
    assert result['ok']
    orchestrator._get_relevant_memories_bundle.assert_not_called()
    orchestrator._get_learning_insights.assert_not_called()

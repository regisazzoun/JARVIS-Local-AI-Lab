"""Regression tests for generate_image aspect-ratio mapping."""
import base64
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

from google import genai
from google.genai import types

PROJECT_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT / "skills"))

import generate_image


class _FakeModels:
    def __init__(self, response, captured):
        self.response = response
        self.captured = captured

    def generate_content(self, **kwargs):
        self.captured.update(kwargs)
        return self.response


class _FakeClient:
    def __init__(self, response, captured):
        self.models = _FakeModels(response, captured)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        return False


class GenerateImageAspectTests(unittest.TestCase):
    def test_public_reference_image_uses_strict_shared_downloader(self):
        with patch.object(
            generate_image,
            "safe_download_image",
            return_value=(
                b"bounded-jpeg",
                "image/jpeg",
                "https://cdn.example/reference.jpg",
                {"processed_width": 1024, "processed_height": 768},
            ),
        ) as strict_download, patch.object(generate_image.requests, "get") as raw_get:
            encoded, mime_type = generate_image._resolve_image_to_base64(
                "https://images.example/reference.png"
            )

        self.assertEqual(base64.b64decode(encoded), b"bounded-jpeg")
        self.assertEqual(mime_type, "image/jpeg")
        strict_download.assert_called_once_with("https://images.example/reference.png")
        raw_get.assert_not_called()

    def test_commented_out_model_env_uses_catalog_default(self):
        with patch.object(generate_image, "get_config_value", side_effect=lambda _key, default=None: default):
            model = generate_image._resolve_configured_image_model("gemini")

        self.assertEqual(model, "gemini-3.1-flash-image")

    def test_explicit_request_model_wins_and_config_is_the_fallback(self):
        with patch.object(
            generate_image,
            "get_config_value",
            return_value="gpt-image-2",
        ) as get_config:
            requested = generate_image._resolve_configured_image_model(
                "openai", "gpt-image-2.5-flare"
            )
        self.assertEqual(requested, "gpt-image-2.5-flare")
        get_config.assert_not_called()

        with patch.object(generate_image, "get_config_value", return_value="gpt-image-2"):
            configured = generate_image._resolve_configured_image_model("openai")
        self.assertEqual(configured, "gpt-image-2")

    def test_main_forwards_explicit_model_to_generate_image(self):
        result = {
            "provider": "openai",
            "model": "gpt-image-2.5-flare",
            "mime_type": "image/png",
        }
        argv = [
            "generate_image.py",
            '{"prompt":"draw it","provider":"openai",'
            '"model":"gpt-image-2.5-flare","save":false}',
        ]
        with (
            patch.object(generate_image, "load_config"),
            patch.object(generate_image, "generate_image", return_value=result) as generate,
            patch.object(generate_image.sys, "argv", argv),
            patch("builtins.print"),
        ):
            generate_image.main()

        self.assertEqual(generate.call_args.kwargs["model"], "gpt-image-2.5-flare")

    def test_gemini_literal_ratios_from_tool_schema(self):
        """LLM often passes enum values like 16:9; must not fall back to 1:1."""
        for key, expected in (
            ("16:9", "16:9"),
            ("9:16", "9:16"),
            ("1:1", "1:1"),
            ("4:3", "4:3"),
            ("landscape", "16:9"),
            ("square", "1:1"),
        ):
            with self.subTest(key=key):
                got = generate_image.GEMINI_ASPECT_RATIOS.get(key, "1:1")
                self.assertEqual(got, expected)

    @staticmethod
    def _response(*, grounding=False):
        metadata = None
        if grounding:
            metadata = types.GroundingMetadata(
                web_search_queries=["current Portland weather"],
                image_search_queries=["Portland skyline"],
                grounding_chunks=[
                    types.GroundingChunk(
                        web=types.GroundingChunkWeb(
                            title="Weather source",
                            uri="https://example.com/weather",
                        )
                    )
                ],
            )
        return types.GenerateContentResponse(
            candidates=[
                types.Candidate(
                    content=types.Content(
                        role="model",
                        parts=[
                            types.Part(text="Generated with current data"),
                            types.Part(
                                inline_data=types.Blob(
                                    data=b"generated-image-bytes",
                                    mime_type="image/png",
                                )
                            ),
                        ],
                    ),
                    grounding_metadata=metadata,
                )
            ]
        )

    @staticmethod
    def _config_value(key, default=None):
        values = {
            "GEMINI_API_KEY": "test-key",
            "GEMINI_IMAGE_MODEL": "gemini-3.1-flash-image",
        }
        return values.get(key, default)

    def test_gemini_sdk_generation_preserves_size_ratio_and_grounding(self):
        captured = {}
        fake_client = _FakeClient(self._response(grounding=True), captured)

        with patch.object(generate_image, "get_config_value", side_effect=self._config_value), patch.object(
            genai, "Client", return_value=fake_client
        ):
            result = generate_image.generate_image_gemini(
                "A current weather infographic",
                aspect_ratio="4:5",
                image_size="4K",
                use_grounding=True,
            )

        config = captured["config"]
        self.assertEqual(captured["model"], "gemini-3.1-flash-image")
        self.assertEqual(config.image_config.aspect_ratio, "4:5")
        self.assertEqual(config.image_config.image_size, "4K")
        self.assertEqual(config.http_options.timeout, 300_000)
        self.assertIsNotNone(config.tools[0].google_search)
        self.assertEqual(base64.b64decode(result["image_base64"]), b"generated-image-bytes")
        self.assertEqual(result["grounding"]["search_queries"], ["current Portland weather"])
        self.assertEqual(result["grounding"]["sources"][0]["title"], "Weather source")

    def test_gemini_sdk_edit_passes_reference_image_as_bytes(self):
        captured = {}
        fake_client = _FakeClient(self._response(), captured)
        encoded_reference = base64.b64encode(b"reference-image-bytes").decode("ascii")

        with patch.object(generate_image, "get_config_value", side_effect=self._config_value), patch.object(
            generate_image,
            "_resolve_image_to_base64",
            return_value=(encoded_reference, "image/jpeg"),
        ), patch.object(genai, "Client", return_value=fake_client):
            result = generate_image.generate_image_gemini(
                "Change the sky to sunset",
                reference_image="stash://space/file",
            )

        content = captured["contents"]
        self.assertEqual(content.parts[0].inline_data.data, b"reference-image-bytes")
        self.assertEqual(content.parts[0].inline_data.mime_type, "image/jpeg")
        self.assertTrue(content.parts[1].text.startswith("Edit this image:"))
        self.assertEqual(captured["config"].http_options.timeout, 180_000)
        self.assertIsNone(captured["config"].tools)
        self.assertTrue(result["is_edit"])

    def test_nano_banana_2_1_pin_reaches_sdk_for_generation_and_editing(self):
        model = "gemini-nano-banana-2.1"
        encoded_reference = base64.b64encode(b"reference-image-bytes").decode("ascii")
        for reference in (None, "stash://space/file"):
            with self.subTest(reference=reference):
                captured = {}
                fake_client = _FakeClient(self._response(grounding=True), captured)
                values = {"GEMINI_API_KEY": "test-key", "GEMINI_IMAGE_MODEL": model}
                with (
                    patch.object(generate_image, "get_config_value", side_effect=lambda key, default=None: values.get(key, default)),
                    patch.object(generate_image, "_resolve_image_to_base64", return_value=(encoded_reference, "image/jpeg")),
                    patch.object(genai, "Client", return_value=fake_client),
                ):
                    result = generate_image.generate_image_gemini(
                        "A weather infographic", aspect_ratio="16:9", image_size="2K",
                        use_grounding=True, reference_image=reference,
                    )
                self.assertEqual(captured["model"], model)
                self.assertEqual(captured["config"].image_config.aspect_ratio, "16:9")
                self.assertEqual(captured["config"].image_config.image_size, "2K")
                self.assertIsNotNone(captured["config"].tools[0].google_search)
                self.assertIsNone(captured["config"].thinking_config)
                self.assertEqual(result["model"], model)
                self.assertEqual(result["is_edit"], reference is not None)
                self.assertEqual(base64.b64decode(result["image_base64"]), b"generated-image-bytes")
                if reference:
                    self.assertEqual(captured["contents"].parts[0].inline_data.data, b"reference-image-bytes")

    def test_configured_provider_outranks_chat_provider_argument(self):
        captured = {}
        fake_client = _FakeClient(self._response(), captured)
        values = {
            "IMAGE_TOOL_PROVIDER": "gemini",
            "GEMINI_API_KEY": "test-key",
            "OPENAI_API_KEY": "test-key",
        }
        encoded_reference = base64.b64encode(b"reference-image-bytes").decode("ascii")
        with (
            patch.object(generate_image, "get_config_value", side_effect=lambda key, default=None: values.get(key, default)),
            patch("tool_availability.media_provider_preflight", return_value=None) as preflight,
            patch.object(generate_image, "_resolve_image_to_base64", return_value=(encoded_reference, "image/jpeg")),
            patch.object(genai, "Client", return_value=fake_client),
            patch.object(generate_image.requests, "post", side_effect=AssertionError("Must not call OpenAI")),
        ):
            result = generate_image.generate_image(
                "Change the hair to blond", provider="openai", model="gemini-nano-banana-2.1",
                reference_image="stash://space/file", image_size="2K",
            )
        preflight.assert_called_once_with("gemini")
        self.assertEqual(captured["model"], "gemini-nano-banana-2.1")
        self.assertEqual(result["provider"], "gemini")
        self.assertTrue(result["is_edit"])

    def test_mismatched_known_model_is_rejected_before_any_provider_request(self):
        values = {"IMAGE_TOOL_PROVIDER": "openai", "OPENAI_API_KEY": "test-key"}
        with (
            patch.object(generate_image, "get_config_value", side_effect=lambda key, default=None: values.get(key, default)),
            patch("tool_availability.media_provider_preflight", return_value=None),
            patch.object(generate_image.requests, "post") as post,
            patch.object(genai, "Client") as client,
        ):
            with self.assertRaisesRegex(ValueError, "belongs to gemini.*selected provider is openai"):
                generate_image.generate_image("A robot", provider="gemini", model="gemini-nano-banana-2.1")
        post.assert_not_called()
        client.assert_not_called()

    def test_omitted_provider_still_uses_configured_image_provider(self):
        with (
            patch.object(generate_image, "get_config_value", return_value="openai"),
            patch("tool_availability.media_provider_preflight", return_value=None),
            patch.object(generate_image, "generate_image_openai", return_value={"provider": "openai"}) as openai,
            patch.object(generate_image, "generate_image_gemini") as gemini,
        ):
            result = generate_image.generate_image("A robot")
        self.assertEqual(result["provider"], "openai")
        openai.assert_called_once()
        gemini.assert_not_called()

    def test_openai_edit_sends_transparent_background_for_gpt_image_1_5(self):
        captured = {}
        encoded_reference = base64.b64encode(b"reference-image-bytes").decode("ascii")

        class FakeResponse:
            status_code = 200
            text = ""

            @staticmethod
            def json():
                return {"data": [{"b64_json": base64.b64encode(b"edited").decode("ascii")}]}

        def fake_post(url, **kwargs):
            captured["url"] = url
            captured.update(kwargs)
            return FakeResponse()

        def fake_config(key, default=None):
            return {
                "OPENAI_API_KEY": "test-key",
                "OPENAI_IMAGE_MODEL": "gpt-image-1.5",
            }.get(key, default)

        with patch.object(generate_image, "get_config_value", side_effect=fake_config), patch.object(
            generate_image,
            "_resolve_image_to_base64",
            return_value=(encoded_reference, "image/png"),
        ), patch.object(generate_image.requests, "post", side_effect=fake_post):
            result = generate_image.generate_image_openai(
                "Keep the logo and remove the background",
                transparent=True,
                output_format="png",
                reference_image="stash://space/file",
            )

        self.assertTrue(captured["url"].endswith("/v1/images/edits"))
        self.assertEqual(captured["data"]["model"], "gpt-image-1.5")
        self.assertEqual(captured["data"]["background"], "transparent")
        self.assertTrue(result["transparent"])

    def test_openai_generation_uses_gpt_image_2_5_default_with_transparency(self):
        captured = {}

        class FakeResponse:
            status_code = 200
            text = ""

            @staticmethod
            def json():
                return {"data": [{"b64_json": base64.b64encode(b"generated").decode("ascii")}]}

        def fake_post(url, **kwargs):
            captured["url"] = url
            captured.update(kwargs)
            return FakeResponse()

        def fake_config(key, default=None):
            return {"OPENAI_API_KEY": "test-key"}.get(key, default)

        with patch.object(generate_image, "get_config_value", side_effect=fake_config), patch.object(
            generate_image.requests, "post", side_effect=fake_post
        ):
            result = generate_image.generate_image_openai(
                "A transparent product icon",
                aspect_ratio="16:9",
                quality="4K",
                transparent=True,
                output_format="webp",
            )

        self.assertTrue(captured["url"].endswith("/v1/images/generations"))
        self.assertEqual(captured["json"]["model"], "gpt-image-2.5-sunburst")
        self.assertEqual(captured["json"]["size"], "3840x2160")
        self.assertEqual(captured["json"]["quality"], "high")
        self.assertEqual(captured["json"]["background"], "transparent")
        self.assertEqual(captured["json"]["output_format"], "webp")
        self.assertTrue(result["transparent"])


if __name__ == "__main__":
    unittest.main()

/*
 * Intel ACPI Component Architecture
 * AML/ASL+ Disassembler version 20250404 (64-bit version)
 * Copyright (c) 2000 - 2025 Intel Corporation
 * 
 * Disassembling to symbolic ASL+ operators
 *
 * Disassembly of acpi-SSDT7.bin
 *
 * Original Table Header:
 *     Signature        "SSDT"
 *     Length           0x00000024 (36)
 *     Revision         0x01
 *     Checksum         0x9A
 *     OEM ID           "APPLE "
 *     OEM Table ID     "SmcDppt"
 *     OEM Revision     0x00001000 (4096)
 *     Compiler ID      "INTL"
 *     Compiler Version 0x20160930 (538315056)
 */
DefinitionBlock ("", "SSDT", 1, "APPLE ", "SmcDppt", 0x00001000)
{

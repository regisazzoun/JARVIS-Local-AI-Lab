#!/usr/bin/env python3
"""
Jarvis Voice Assistant - Orchestrator Executor
Executes tools/skills and formats responses for TTS.
"""
import json
import os
import signal
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturesTimeoutError
from contextlib import nullcontext
from contextvars import copy_context
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any

# Add lib to path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'lib'))
from config_loader import export_config_environment, get_int, load_config
from http_client import PROXY_POLICY_ENV, STANDARD_PROXY_ENV_KEYS
from security_utils import redact_sensitive_text
from serpapi_client import diagnose_serpapi_tool_failure
from ssh_remote_commands import (
    SSH_APT_CHECK_TIMEOUT_SECONDS,
    SSH_APT_UPDATE_TIMEOUT_SECONDS,
    SSH_APT_UPGRADE_TIMEOUT_SECONDS,
    SSH_COMMAND_TIMEOUT_SECONDS,
)
from tool_child_environment import restrict_child_environment
from tool_logger import get_logger
from tool_progress import parse_tool_progress
from tool_search_runtime import search_tools_runtime

try:
    from .workflow_tool_runtime import execute_workflow_tool
except ImportError:
    from workflow_tool_runtime import execute_workflow_tool


class ToolExecutor:
    """Executes tools and skills with permission checking."""
    
    def __init__(self, mode='cloud', registry=None, *, load_runtime_config=True):
        """
        Initialize executor.
        
        Args:
            mode: 'cloud' or 'local'
            registry: Optional shared ToolRegistry (prevents duplicate MCP servers)
        """
        self.mode = mode
        if load_runtime_config:
            load_config(mode)
        self.project_root = Path(__file__).parent.parent.resolve()
        self.skills_dir = self.project_root / "skills"
        
        # Use provided registry or create new one
        if registry:
            self.registry = registry
        else:
            # Backward compatibility: create own registry
            sys.path.insert(0, str(self.project_root / "lib"))
            from tool_schema import ToolRegistry
            mcp_config = str(self.project_root / "config" / "mcp-servers.json")
            self.registry = ToolRegistry(str(self.skills_dir), mcp_config)
        
        # Initialize logger
        self.logger = get_logger(mode)
        self.cancel_check = None
        self.progress_callback = None
        self.jarvis_session_id = None
        self.web_conversation_id = None
        self.excluded_tools: set[str] = set()
        self.allowed_tools: set[str] | None = None
        self.workflow_loader = None
        self.pipeline_executor = None
        self.workflow_status_callback = None

    def set_cancel_check(self, callback):
        """Set callback to check if the current tool execution should be cancelled."""
        self.cancel_check = callback

    def set_progress_callback(self, callback):
        """Set callback for structured progress emitted by local tool subprocesses."""
        self.progress_callback = callback

    def _consume_progress_line(self, tool_name: str, line: str) -> bool:
        """Forward one structured stderr line; return whether it was protocol data."""
        payload = parse_tool_progress(line)
        if payload is None:
            return False
        if not self.progress_callback:
            return True

        event_type = str(payload.pop("event_type", "tool_progress"))
        payload.setdefault("tool", tool_name)
        try:
            self.progress_callback(event_type, **payload)
        except Exception as exc:
            safe_error = redact_sensitive_text(str(exc)).replace("\n", " ")[:300]
            print(
                f"[TOOL_PROGRESS] Callback failed for {tool_name} "
                f"({type(exc).__name__}): {safe_error}",
                file=sys.stderr,
                flush=True,
            )
        return True

    @staticmethod
    def _terminate_process_tree(
        process: subprocess.Popen,
        *,
        grace_seconds: float = 3,
        verify: bool = False,
    ):
        """Terminate a local tool and descendants, then escalate after a grace period."""
        if verify:
            from tool_process import terminate_verified
            return terminate_verified(process, grace_seconds)
        if process.poll() is not None:
            return

        deadline = time.monotonic() + grace_seconds

        try:
            if os.name == "posix":
                os.killpg(process.pid, signal.SIGTERM)
            else:
                process.terminate()
        except (OSError, ProcessLookupError):
            pass

        try:
            process.wait(timeout=grace_seconds)
        except subprocess.TimeoutExpired:
            pass

        if os.name == "posix" and process.poll() is not None:
            while time.monotonic() < deadline:
                try:
                    os.killpg(process.pid, 0)
                except ProcessLookupError:
                    return
                except PermissionError:
                    pass
                time.sleep(0.05)
        elif process.poll() is not None:
            return

        try:
            if os.name == "posix":
                os.killpg(process.pid, signal.SIGKILL)
            else:
                process.kill()
        except (OSError, ProcessLookupError):
            pass

        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            pass

    def set_session_context(self, jarvis_session_id: str | None = None, web_conversation_id: str | None = None):
        """Set session metadata that should be propagated to tool subprocesses."""
        self.jarvis_session_id = jarvis_session_id
        self.web_conversation_id = web_conversation_id

    def set_excluded_tools(self, excluded_tools: list[str] | None = None):
        """Set request-scoped tools that must remain hidden from discovery."""
        self.excluded_tools = {str(name).strip() for name in (excluded_tools or []) if str(name).strip()}
        stop_disallowed = getattr(self.registry, "stop_disallowed_mcp", None)
        # Restricted nested requests share clients with their dispatcher.
        # Visibility is request-scoped; client lifetime belongs to the registry.
        if callable(stop_disallowed) and getattr(self, 'allowed_tools', None) is None:
            stop_disallowed(self.excluded_tools)

    def set_allowed_tools(self, allowed_tools: list[str] | None = None):
        """Enforce an optional request allowlist even after MCP catalog recovery."""
        self.allowed_tools = None if allowed_tools is None else set(allowed_tools)

    def _effective_exclusions(self):
        allowed = getattr(self, 'allowed_tools', None)
        exclusions = getattr(self, 'excluded_tools', set()) | (
            set(self.registry.list_tools()) - allowed if allowed is not None else set()
        )
        resolve = getattr(type(self.registry), 'dependency_exclusions', None)
        return resolve(self.registry, exclusions) if callable(resolve) else exclusions

    def set_workflow_runtime(
        self,
        *,
        workflow_loader=None,
        pipeline_executor=None,
        status_callback=None,
    ):
        """Attach shared foreground workflow components from the orchestrator."""
        self.workflow_loader = workflow_loader
        self.pipeline_executor = pipeline_executor
        self.workflow_status_callback = status_callback

    def _get_subprocess_timeout(self, tool_name: str, args: dict[str, Any] | None = None) -> int:
        """Return the subprocess timeout for a local tool."""
        if tool_name == "ssh_remote":
            args = args or {}
            # The SSH script has per-command deadlines. Keep the outer guard
            # beyond their sum so normal stage timeouts report from the script.
            try:
                with (self.project_root / "config" / "ssh.json").open() as config_file:
                    config = json.load(config_file)
                host = config.get("hosts", {}).get(args.get("host"), {})
                defaults = config.get("defaults", {})
                command_timeout = int(host.get("timeout", defaults.get("timeout", SSH_COMMAND_TIMEOUT_SECONDS)))
                connect_timeout = int(host.get("connect_timeout", defaults.get("connect_timeout", 10)))
                if command_timeout <= 0 or connect_timeout <= 0:
                    raise ValueError("SSH timeout must be positive")
            except (OSError, ValueError, TypeError, AttributeError):
                command_timeout, connect_timeout = SSH_COMMAND_TIMEOUT_SECONDS, 10
            action = args.get("action", "run")
            setup_margin = connect_timeout + 60
            if action == "apt_update":
                stages = SSH_APT_UPDATE_TIMEOUT_SECONDS + SSH_APT_CHECK_TIMEOUT_SECONDS
                if args.get("upgrade", True) is not False:
                    stages += SSH_APT_UPGRADE_TIMEOUT_SECONDS
                return stages + setup_margin
            if action == "multi":
                commands = args.get("commands")
                count = len(commands) if isinstance(commands, list) else 1
                return max(1, count) * command_timeout + setup_margin
            if action == "run":
                return command_timeout + setup_margin
            return 60
        if tool_name == "opencode":
            # Let the skill report/abort its own configured HTTP deadline, then
            # retain a short process-cleanup window for the executor.
            return max(60, get_int("OPENCODE_TASK_TIMEOUT_SECONDS", 900)) + 30
        if tool_name == "ingest_intel":
            return 300  # 5 minutes to match API sync ingest timeout for large intel files
        if tool_name == "manage_intel":
            return 600  # 10 minutes; create/update/delete can trigger two sequential ingests
        if tool_name == "generate_image":
            return 300  # 5 minutes for AI image generation (especially with grounding)
        if tool_name == "generate_music":
            return 600  # 10 minutes for music generation (can take 3-5min for longer tracks)
        if tool_name == "generate_video":
            return 600  # 10 minutes for video generation (typically 2-3 min, up to 5 min for 4k)
        if tool_name == "document_ocr":
            return 1200  # 20 minutes for large GPU OCR jobs plus optional local extraction
        if tool_name == "docling_convert":
            return max(30, min(900, get_int("DOCLING_TIMEOUT_SECONDS", 300))) + 30
        if tool_name == "transcribe_audio":
            # Long recordings may be split into several sequential provider
            # requests. The tool owns the request-level deadlines; retain a
            # cleanup window outside its configured overall allowance.
            return max(60, get_int("AUDIO_TRANSCRIBE_TIMEOUT_SECONDS", 900)) + 30
        if tool_name == "analyze_video":
            return 630  # The reader owns a 600-second deadline plus cleanup.
        if tool_name == "source_library":
            return 180  # One bounded embedding batch; original saves are atomic.
        if tool_name == "project_nomad":
            return 180  # Nomad may perform KB query rewriting plus local model inference.
        if tool_name == "create_social_clip":
            return 1200  # 20 minutes — MoneyPrinterTurbo script + stock + TTS + render + download
        if tool_name == "weather":
            return 90  # Weather API can be slow with proxy fallback
        if tool_name == "external_network_intel":
            # A full passive profile combines several bounded HTTPS providers;
            # leave room for the configured primary/fallback proxy chain.
            return 180
        if tool_name == "gpu_hot_status":
            return 30  # One bounded LAN WebSocket snapshot with REST fallback
        if tool_name == "flight_search":
            return 120  # SerpApi deep search can take up to 90 seconds
        if tool_name == "serpapi_amazon_search":
            return 90  # SerpApi include product details can take up to 90 seconds
        if tool_name == "serpapi_home_depot":
            return 200  # Direct SerpApi only; up to two sequential 90s HTTP calls if include_product_details
        if tool_name == "serpapi_search_index":
            return 120  # One Search Index request; deep recall may use the full 90s HTTP allowance
        if tool_name == "tavily_search":
            return 60  # One bounded Tavily search request plus process cleanup
        if tool_name == "searxng_search":
            return 60  # One configured-instance search plus process cleanup
        if tool_name == "tavily_extract":
            return 90  # Advanced extraction can use a 60-second provider deadline
        if tool_name == "serpapi_google_trends":
            return 120  # One Google Trends request with a 90s HTTP allowance
        if tool_name == "serpapi_google_trending_now":
            return 120  # One Trending Now or selected-trend News request
        if tool_name == "serpapi_travel_explore":
            return 120  # One Travel Explore request with a 90s HTTP allowance
        if tool_name == "serpapi_google_news_light":
            return 120  # One Google News Light request with a 90s HTTP allowance
        if tool_name == "serpapi_google_shopping_light":
            return 120  # One Google Shopping Light request with a 90s HTTP allowance
        if tool_name == "serpapi_google_immersive_product":
            return 120  # One Google Immersive Product request with a 90s HTTP allowance
        if tool_name == "serpapi_google_sports":
            return 200  # Optional Google resolver plus a Google Sports request
        if tool_name == "serpapi_google_images_light":
            return 160  # Search plus optional strict 30s top-image Stash download
        if tool_name == "serpapi_google_events":
            return 120  # One Google Events request with a 90s HTTP allowance
        if tool_name == "serpapi_google_local":
            return 120  # One Google Local request with a 90s HTTP allowance
        if tool_name == "serpapi_google_local_services":
            return 200  # One Local Services call, plus a 90s Maps CID lookup when needed
        if tool_name == "serpapi_open_table_reviews":
            return 90  # One OpenTable Reviews request with a 45s HTTP allowance
        if tool_name == "serpapi_tripadvisor":
            return 160  # Up to three sequential 45s calls for search + optional place details + reviews
        if tool_name in {"trakt_movies", "trakt_tv_shows", "trakt_account"}:
            return 300  # Bounded Trakt list/account requests and token refreshes may be sequential
        if tool_name in {"tmdb_movies", "tmdb_tv_shows"}:
            return 300  # Configuration/genre helpers plus proxy-aware metadata or artwork lookup
        if tool_name == "status_recap":
            return 180  # 3 minutes - calls multiple tools including generate_image
        if tool_name == "crawl_url":
            return 90  # 90 seconds - web scraping with JS wait can be slow
        if tool_name == "search_docs":
            return 90  # 60 seconds - search documentation with qmd
        if tool_name == "text_summarizer":
            return 180  # May call configured LLM over long stash/transcript artifacts
        if tool_name in {"craft_image", "craft_pdf", "craft_photos", "craft_video", "craft_motion"}:
            return 300  # Bounded transfers plus <=110s foreground observation; remote jobs survive timeout.
        if tool_name == "craft_inspect":
            return 180  # Capability/status checks or checksum-verified artifact collection.
        if tool_name == "convert_file":
            return 180  # 3 minutes - convert files various formats, audio, video, image, ect.
        if tool_name == "openclaw":
            return 180  # 3 minutes - OpenClaw is a remote assistant, so we need to increase the timeout
        if tool_name == "youtube_transcript":
            return 180  # Three bounded yt-dlp routes plus the opt-in API fallback and artifact saves
        if tool_name == "youtube_video":
            return 900  # 15 minutes - YouTube video download can be slow if downloading 2hr video
        if tool_name == "phone_call":
            return 900  # 15 min — aligns with VAPI_WAIT_TIMEOUT / wait_for_call_completion + Vapi maxDurationSeconds
        return 75 if self.mode == "local" else 60

    @staticmethod
    def _with_serpapi_incident_context(
        tool_name: str,
        args: dict[str, Any],
        output: dict[str, Any],
        *,
        force: bool = False,
    ) -> dict[str, Any]:
        """Replace a final transient SerpApi failure with matching live incident context."""
        if output.get("ok") is not False:
            return output

        error_text = " ".join(
            str(value)
            for value in (output.get("speech"), output.get("error"))
            if value
        )
        try:
            diagnosis = diagnose_serpapi_tool_failure(
                tool_name,
                args,
                error_text,
                force=force,
            )
        except Exception:
            diagnosis = None
        if not diagnosis:
            return output

        enriched = dict(output)
        speech = str(diagnosis.get("speech") or output.get("speech") or "SerpApi request failed")
        enriched["speech"] = speech
        enriched["error"] = speech

        existing_data = output.get("data")
        data = dict(existing_data) if isinstance(existing_data, dict) else {}
        diagnosis_data = diagnosis.get("data")
        if isinstance(diagnosis_data, dict):
            data.update(diagnosis_data)
        enriched["data"] = data
        return enriched
    
    def execute(self, tool_name: str, args: dict[str, Any], skip_permission_check: bool = False,
                *, background_context=None, invocation_id=None) -> dict[str, Any]:
        if getattr(self, 'allowed_tools', None) is not None and tool_name not in self.allowed_tools:
            return {'ok': False, 'error': 'Tool outside this request allowlist',
                    'speech': 'That action is not enabled for this request.'}
        if tool_name in self._effective_exclusions():
            return {'ok': False, 'error': 'Tool blocked for this request',
                    'speech': f'Tool {tool_name} is blocked for this request'}
        from lib.background_tasks import TaskError
        from lib.background_tasks.admission import WebTaskContext, reject_background_result

        if background_context is not None:
            if not isinstance(background_context, WebTaskContext):
                return {'ok': False, 'error': 'Invalid Web background context'}
            schema = self.registry.get_tool(tool_name)
            if (tool_name in background_context.selected and tool_name not in self.excluded_tools
                    and getattr(schema, 'background_adapter', None) == 'remote_skill_v1'):
                # A current-turn Jarvis receipt cannot be a provider's task
                # handle. Echo its real admission without dispatching another
                # observer or claiming that the requested remote check ran.
                with background_context.lock:
                    for key in ('task_id', 'job_id', 'run_id'):
                        reference = args.get(key)
                        receipt = background_context.receipts.get(reference) if isinstance(reference, str) else None
                        if receipt:
                            return {**receipt, 'receipt_reused': True,
                                    'speech': 'That is a Jarvis background job ID, not a remote task ID. '
                                              'The existing task is queued; results will return to this conversation. '
                                              'No remote status check or additional task was started.'}
            # Docling's selected background work is conversion/collection.
            # Read-only status calls must not recursively queue observer jobs.
            docling_check = tool_name == 'docling_convert' and args.get('action') in ('status', 'job')
            if tool_name in background_context.selected and not docling_check:
                if tool_name in self.excluded_tools:
                    return {'ok': False, 'error': 'Tool blocked for this request'}
                try:
                    return background_context.admit(tool_name, args, invocation_id,
                                                    self.registry.get_tool(tool_name))
                except TaskError as exc:
                    return {'ok': False, 'error': str(exc), 'speech': str(exc)}
        return reject_background_result(self._execute_foreground(tool_name, args, skip_permission_check))

    def _execute_foreground(self, tool_name: str, args: dict[str, Any], skip_permission_check=False, *, supervision=None):
        """
        Execute a tool/skill with permission checking.
        
        Args:
            tool_name: Name of the tool to execute
            args: Arguments to pass to the tool
            skip_permission_check: Skip permission validation (use with caution)
            
        Returns:
            dict: Tool result
            {
                "ok": True/False,
                "speech": "Text to speak",
                "data": {...} (optional),
                "requires_confirmation": bool (if permission check fails)
            }
        """
        # Request/surface exclusions are an execution boundary, not just a
        # discovery hint. Workflows bypass normal LLM schema selection.
        if tool_name in self._effective_exclusions():
            return {
                "ok": False,
                "speech": f"Tool {tool_name} is blocked for this request",
                "error": "Tool blocked for this request",
            }

        # Get tool schema for permission check
        tool_schema = self.registry.get_tool(tool_name)
        
        if not tool_schema and tool_name.startswith("mcp_"):
            try:
                from tool_schema import get_tool_registry, reset_tool_registry

                shared_registry = get_tool_registry(mode=self.mode)
                shared_schema = shared_registry.get_tool(tool_name)
                if not shared_schema:
                    reset_tool_registry()
                    shared_registry = get_tool_registry(mode=self.mode)
                    shared_schema = shared_registry.get_tool(tool_name)
                if shared_schema:
                    self.registry = shared_registry
                    tool_schema = shared_schema
            except Exception as e:
                if os.environ.get("MCP_DEBUG", "").lower() == "true":
                    print(
                        f"[MCP DEBUG] Shared registry recovery failed for {tool_name}: {e}",
                        file=sys.stderr,
                    )

        if not tool_schema:
            return {
                "ok": False,
                "speech": f"Tool {tool_name} not found",
                "error": "Tool not found"
            }

        if getattr(tool_schema, 'background_required', False):
            from lib.background_tasks.local_contract import SKILL_ADAPTERS
            from lib.background_tasks.worker import ExecutionContext

            reviewed_skill_job = (isinstance(supervision, ExecutionContext)
                and tool_schema.background_adapter in SKILL_ADAPTERS
                and supervision.claim.job['adapter'] == tool_schema.background_adapter
                and supervision.claim.job['admission']['tool'] == tool_name)
            if not reviewed_skill_job:
                from lib.background_tasks.admission import background_only_result
                return background_only_result(tool_name)

        if tool_name == "tool_search":
            return self._execute_tool_search(tool_name, args)
        if tool_name == "workflow":
            return self._execute_workflow(tool_name, args)
        if tool_name == "email_inbox":
            from lib.email_inbox import execute_inbox
            start_time = time.time()
            result = execute_inbox(self.mode, args, self)
            self.logger.log_tool_call(tool_name=tool_name, arguments=args, result=result,
                                      duration_ms=(time.time() - start_time) * 1000, mode=self.mode)
            return result
        
        # Check permissions (unless explicitly skipped)
        if not skip_permission_check and tool_schema.requires_confirmation():
            # For voice control, we announce what we're about to do
            warning = tool_schema.get_permission_warning()
            # Only print if not in JSON mode (for voice scripts)
            if sys.stdout.isatty() or os.environ.get('JARVIS_JSON_MODE') != '1':
                print(f"⚠️  Permission check: {warning}", file=sys.stderr)
            
            # TODO: In future, could add verbal confirmation loop here
            # For now, we announce and proceed with caution
        
        # Check if this is an MCP tool
        if self.registry.is_mcp_tool(tool_name):
            return self._execute_mcp_tool(tool_name, args)
        
        # Get script path from schema
        tool_script = Path(tool_schema.script_path)
        
        if not tool_script.exists():
            return {
                "ok": False,
                "speech": f"Tool script not found at {tool_script}",
                "error": "Script not found"
            }
        
        # Execute tool
        start_time = time.time()
        try:
            input_json = json.dumps(args)
            
            # Determine command based on file extension
            if tool_script.suffix == '.py':
                # Run Python scripts with python3, passing JSON as argument
                cmd = [sys.executable if supervision else 'python3', str(tool_script), input_json]
            else:
                # Run bash scripts or other executables directly
                cmd = [str(tool_script)]
            
            # @TOOL_CONFIG: tool execution timeouts — add new tools with custom timeouts here
            # Use longer timeout for local mode (Ollama can be slower)
            # OpenCode tasks need much more time (building, coding, etc.)
            # Ingest intel needs time for embedding generation (especially large profiles)
            # phone_call: Vapi max call length + poll loop + canvas save (see skills/phone_call.py)
            # Subprocess timeout settings see tool.json for HTTP timeouts
            timeout = self._get_subprocess_timeout(tool_name, args)
            
            # Materialize the request's deployment mode into the child env and
            # stamp JARVIS_MODE explicitly so tools never infer mode from the
            # chat provider. Starts from the current environment, so per-request
            # JARVIS_OVERRIDE_* values and session context still propagate.
            tool_env = dict(supervision.environment) if supervision else export_config_environment(self.mode)
            proxy_policy = getattr(tool_schema, "proxy_policy", "inherit")
            if proxy_policy != "inherit":
                tool_env[PROXY_POLICY_ENV] = proxy_policy
                tool_env[f"JARVIS_OVERRIDE_{PROXY_POLICY_ENV}"] = proxy_policy
            if proxy_policy == "off":
                # Child tools commonly call load_config(), so blank override
                # values prevent LOCAL_PROXY* from being rehydrated. Remove
                # conventional variables too so non-Jarvis HTTP libraries do
                # not silently pick up a host proxy.
                for key in ("LOCAL_PROXY", "LOCAL_PROXY2"):
                    tool_env[key] = ""
                    tool_env[f"JARVIS_OVERRIDE_{key}"] = ""
                for key in STANDARD_PROXY_ENV_KEYS:
                    tool_env.pop(key, None)
                    tool_env[f"JARVIS_OVERRIDE_{key}"] = ""
            if self.jarvis_session_id:
                tool_env['JARVIS_SESSION_ID'] = str(self.jarvis_session_id)
            if self.web_conversation_id:
                tool_env['JARVIS_WEB_CONVERSATION_ID'] = str(self.web_conversation_id)
            
            local_limits = None
            if supervision:
                supervision.checkpoint()
                # A background job owns its time budget. Queue/preflight time
                # counts against it; the foreground tool timeout does not.
                deadline = supervision.claim.job['deadline']
                timeout = max(0, deadline - supervision.store.clock())
                tool_env['JARVIS_BACKGROUND_DEADLINE'] = str(deadline)
                tool_env['JARVIS_OVERRIDE_JARVIS_BACKGROUND_DEADLINE'] = str(deadline)
                from lib.background_tasks.local_contract import DEFAULT_LIMITS

                local_settings = getattr(supervision, 'local_execution', {})
                local_limits = {**DEFAULT_LIMITS, **local_settings.get('limits', {})}
                cmd = [sys.executable, str(self.project_root / 'lib/background_tasks/child.py'),
                       str(timeout), '--limits', json.dumps(local_limits), *cmd]
            else:
                # Worker-only budgets must not leak into foreground skills.
                tool_env['JARVIS_BACKGROUND_DEADLINE'] = ''
                tool_env['JARVIS_OVERRIDE_JARVIS_BACKGROUND_DEADLINE'] = ''
                tool_env['JARVIS_BACKGROUND_MAX_INPUT_BYTES'] = ''
                tool_env['JARVIS_OVERRIDE_JARVIS_BACKGROUND_MAX_INPUT_BYTES'] = ''
            child_names = getattr(tool_schema, "child_environment_names", None)
            if tool_name == "ssh_remote" and child_names is not None:
                from ssh_remote_environment import selected_sudo_environment_names

                child_names |= selected_sudo_environment_names(
                    self.project_root / "config" / "ssh.json", args)
                # The restricted child uses an empty HOME. Preserve only the
                # original path base needed for explicit ~/.ssh key paths.
                tool_env["JARVIS_SSH_KEY_HOME"] = tool_env.get("HOME") or str(Path.home())
                tool_env.pop("JARVIS_OVERRIDE_JARVIS_SSH_KEY_HOME", None)
            home_context = (
                TemporaryDirectory(prefix="jarvis-tool-home-")
                if child_names is not None else nullcontext(None)
            )
            with home_context as child_home:
                if child_names is not None:
                    tool_env = restrict_child_environment(
                        tool_env, child_names, home=child_home,
                        proxy_policy=proxy_policy,
                    )
                from tool_process import run_local_process
                stdout, stderr, cancelled = run_local_process(
                    cmd, input_json, python_script=tool_script.suffix == '.py', cwd=self.skills_dir,
                    tool_env=tool_env, timeout=timeout, tool_name=tool_name,
                    consume_progress=lambda line: self._consume_progress_line(tool_name, line),
                    cancel_check=self.cancel_check, terminate=self._terminate_process_tree,
                    process_factory=subprocess.Popen,
                    checkpoint=supervision.checkpoint if supervision else None,
                    process_started=(lambda pid: supervision.record_process_start(
                        pid, local_settings.get('progress_label', 'Running local skill'))) if supervision else None,
                    process_stopped=supervision.record_process_stop if supervision else None,
                    max_output_bytes=local_limits['output_bytes'] if local_limits is not None else None,
                )

            if cancelled:
                duration_ms = (time.time() - start_time) * 1000
                output = {
                    "ok": True,
                    "speech": f"Stopped {tool_name}.",
                    "cancelled": True,
                    "error": "Cancelled by user"
                }
                self.logger.log_tool_call(
                    tool_name=tool_name,
                    arguments=args,
                    result=output,
                    duration_ms=duration_ms,
                    mode=self.mode
                )
                return output
            
            duration_ms = (time.time() - start_time) * 1000
            
            # Parse output (tools write JSON to stdout even on failure)
            try:
                output = json.loads(stdout)
            except json.JSONDecodeError:
                # If JSON parsing fails, fallback to error message
                output = {
                    "ok": False,
                    "speech": f"Tool {tool_name} failed",
                    "error": stderr or stdout or "Unknown error"
                }

            output = self._with_serpapi_incident_context(tool_name, args, output)
            
            # Note: We don't check returncode because tools write valid JSON even on failure
            
            # Log successful execution
            self.logger.log_tool_call(
                tool_name=tool_name,
                arguments=args,
                result=output,
                duration_ms=duration_ms,
                mode=self.mode
            )
            
            return output
            
        except subprocess.TimeoutExpired:
            if supervision:
                raise
            duration_ms = (time.time() - start_time) * 1000
            output = {
                "ok": False,
                "speech": f"Tool {tool_name} timed out",
                "error": "Timeout"
            }
            output = self._with_serpapi_incident_context(
                tool_name,
                args,
                output,
                force=True,
            )
            self.logger.log_tool_call(
                tool_name=tool_name,
                arguments=args,
                result=output,
                duration_ms=duration_ms,
                mode=self.mode
            )
            return output
        except json.JSONDecodeError as e:
            duration_ms = (time.time() - start_time) * 1000
            output = {
                "ok": False,
                "speech": f"Tool {tool_name} returned invalid JSON",
                "error": str(e)
            }
            self.logger.log_tool_call(
                tool_name=tool_name,
                arguments=args,
                result=output,
                duration_ms=duration_ms,
                mode=self.mode
            )
            return output
        except Exception as e:
            if supervision:
                raise
            duration_ms = (time.time() - start_time) * 1000
            output = {
                "ok": False,
                "speech": f"Error executing {tool_name}",
                "error": str(e)
            }
            self.logger.log_tool_call(
                tool_name=tool_name,
                arguments=args,
                result=output,
                duration_ms=duration_ms,
                mode=self.mode
            )
            return output

    def _execute_tool_search(self, tool_name: str, args: dict[str, Any]) -> dict[str, Any]:
        """Run live tool discovery against the active registry."""
        start_time = time.time()
        result = search_tools_runtime(
            registry=self.registry,
            query=args.get("query", ""),
            limit=args.get("limit", 6),
            excluded_tools=self._effective_exclusions(),
            background_context=getattr(self, 'background_context', None),
            tool_names=args.get("tool_names"),
            include_schema=bool(args.get("include_schema")),
        )
        duration_ms = (time.time() - start_time) * 1000
        self.logger.log_tool_call(
            tool_name=tool_name,
            arguments=args,
            result=result,
            duration_ms=duration_ms,
            mode=self.mode
        )
        return result

    def _execute_workflow(self, tool_name: str, args: dict[str, Any]) -> dict[str, Any]:
        """Discover or synchronously run workflows against this executor's registry."""
        start_time = time.time()
        try:
            result = execute_workflow_tool(
                registry=self.registry,
                args=args,
                mode=self.mode,
                excluded_tools=self._effective_exclusions(),
                loader=self.workflow_loader,
                pipeline_executor=self.pipeline_executor,
                tool_executor=self,
                status_callback=self.workflow_status_callback,
            )
        except Exception as exc:
            result = {
                "ok": False,
                "speech": "Workflow execution failed.",
                "error": str(exc),
            }
        duration_ms = (time.time() - start_time) * 1000
        self.logger.log_tool_call(
            tool_name=tool_name,
            arguments=args,
            result=result,
            duration_ms=duration_ms,
            mode=self.mode,
        )
        return result
    
    def _execute_mcp_tool(self, tool_name: str, args: dict[str, Any]) -> dict[str, Any]:
        """
        Execute an MCP tool.
        
        Args:
            tool_name: Full MCP tool name (e.g., "mcp.duckduckgo.search")
            args: Tool arguments
            
        Returns:
            Tool result
        """
        start_time = time.time()
        mcp_client = None
        
        try:
            # Extract server and tool names
            server_name, mcp_tool_name = self.registry.get_mcp_info(tool_name)
            
            if not server_name or not mcp_tool_name:
                return {
                    "ok": False,
                    "speech": f"Invalid MCP tool name: {tool_name}",
                    "error": "Invalid tool name format"
                }
            
            # Get MCP client (should be initialized at startup)
            mcp_client = self.registry.mcp_clients.get(server_name)
            
            if not mcp_client:
                return {
                    "ok": False,
                    "speech": f"MCP server {server_name} not available. Server may have failed to start.",
                    "error": "MCP server not connected"
                }

            # Strict outer timeout guard: prevents WebUI "thinking forever"
            mcp_timeout = int(os.environ.get("MCP_EXECUTOR_TIMEOUT_SECONDS", "45"))
            pool = ThreadPoolExecutor(max_workers=1)
            try:
                future = pool.submit(copy_context().run, mcp_client.call_tool, mcp_tool_name, args)
                try:
                    result = future.result(timeout=mcp_timeout)
                except FuturesTimeoutError:
                    # Try to force-recover the MCP client for next calls
                    if hasattr(mcp_client, "_force_restart"):
                        try:
                            mcp_client._force_restart(f"executor timeout ({mcp_timeout}s)")
                        except Exception:
                            pass

                    result = {
                        "ok": False,
                        "speech": f"MCP tool {tool_name} timed out",
                        "error": f"Executor timeout after {mcp_timeout}s"
                    }
            finally:
                # A timeout must not then wait for the same running future.
                pool.shutdown(wait=False, cancel_futures=True)
            
            duration_ms = (time.time() - start_time) * 1000
            
            # Log execution
            self.logger.log_tool_call(
                tool_name=tool_name,
                arguments=args,
                result=result,
                duration_ms=duration_ms,
                mode=self.mode,
                proxy=(
                    mcp_client.get_proxy_log_metadata()
                    if hasattr(mcp_client, "get_proxy_log_metadata")
                    else None
                ),
            )
            
            return result
            
        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000
            output = {
                "ok": False,
                "speech": f"MCP tool {tool_name} failed",
                "error": str(e)
            }
            self.logger.log_tool_call(
                tool_name=tool_name,
                arguments=args,
                result=output,
                duration_ms=duration_ms,
                mode=self.mode,
                proxy=(
                    mcp_client.get_proxy_log_metadata()
                    if mcp_client is not None
                    and hasattr(mcp_client, "get_proxy_log_metadata")
                    else None
                ),
            )
            return output


def main():
    """CLI interface for testing."""
    if len(sys.argv) < 3:
        print("Usage: executor.py <mode> <tool_name> [args_json]", file=sys.stderr)
        sys.exit(1)
    
    mode = sys.argv[1]
    tool_name = sys.argv[2]
    args = json.loads(sys.argv[3]) if len(sys.argv) > 3 else {}
    
    executor = ToolExecutor(mode)
    result = executor.execute(tool_name, args)
    
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

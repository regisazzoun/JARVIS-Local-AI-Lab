#!/usr/bin/env python3
"""
Jarvis Intelligence Layer

Self-learning, reflective intelligence system that learns from experience.

Key Principles:
- Everything is a vector (continuous, not discrete)
- Learning generalizes through embedding similarity
- Reflection extracts insights, not just scores
- Resilient to outliers and bad sessions
- Meta-cognition evaluates the learning process

Usage:
    from intelligence import IntelligenceLayer

    intel = IntelligenceLayer()

    # Record an experience
    await intel.record_experience(
        query="Is my server running?",
        tools_used=["search_memory", "mcp_fetch"],
        outcome={"answered": True, "turns": 2},
        user_signals={"clarified": False}
    )

    # Get learned insights for a new query
    insights = await intel.get_relevant_insights("Check if Ollama is up")
"""

import os
import sys
import json
import re
import sqlite3
import pickle
import hashlib
from datetime import datetime, timedelta
from typing import Any
from pathlib import Path
import numpy as np
import logging
import threading

# Add lib to path
sys.path.insert(0, os.path.dirname(__file__))
from config_loader import load_config, get_float, get_int, get_active_config_mode
from embedding_metadata import (
    INTELLIGENCE_CONTEXT_NAMESPACE,
    INTELLIGENCE_INSIGHT_NAMESPACE,
    INTELLIGENCE_OUTCOME_NAMESPACE,
    INTELLIGENCE_PATTERN_NAMESPACE,
    INTELLIGENCE_QUERY_NAMESPACE,
    ensure_embedding_metadata_table,
    record_embedding_namespace_complete,
    require_embedding_namespace,
)
from embedding_inputs import build_outcome_embedding_text
from security_utils import redact_sensitive_data, redact_sensitive_text
from time_utils import now_utc


def _reflection_cost_from_usage(usage_info: dict) -> "float | None":
    """Preserve unknown hosted cost as NULL instead of fabricating free usage."""
    raw = usage_info.get('cost_usd')
    if (
        usage_info.get('cost_known') is False
        or usage_info.get('billing_mode') == 'ollama_cloud_subscription'
        or raw in (None, '')
    ):
        return None
    try:
        return float(raw)
    except (TypeError, ValueError):
        return None

logger = logging.getLogger(__name__)

_EXTERNAL_SEARCH_TOOL_PREFIXES = (
    'mcp_brave_search_',
    'mcp_duckduckgo_',
    'serpapi_',
    'searxng_search',
    'tavily_search',
)


def _row_value(row: sqlite3.Row | dict[str, Any], key: str, default: Any = None) -> Any:
    """Read a field from either sqlite Row or plain dict."""
    if isinstance(row, dict):
        return row.get(key, default)
    try:
        return row[key]
    except Exception:
        return default


def _json_loads_safely(value: Any, default: Any) -> Any:
    """Parse a JSON-ish value without letting malformed legacy rows break learning."""
    if value in (None, ""):
        return default
    if isinstance(value, (dict, list)):
        return value
    if isinstance(value, str):
        try:
            return json.loads(value)
        except (TypeError, json.JSONDecodeError):
            return default
    return default


def _coerce_string_list(value: Any) -> list[str]:
    """Normalize reflection/tool metadata into a clean string list."""
    value = _json_loads_safely(value, value)
    if value in (None, ""):
        return []
    if isinstance(value, str):
        return [value.strip()] if value.strip() else []
    if isinstance(value, dict):
        return [str(k).strip() for k in value.keys() if str(k).strip()]
    if isinstance(value, (list, tuple, set)):
        result = []
        for item in value:
            if item in (None, ""):
                continue
            text = str(item).strip()
            if text:
                result.append(text)
        return result
    text = str(value).strip()
    return [text] if text else []


def _normalize_trigger_text(value: Any) -> str:
    """Normalize exact reflection trigger phrases for boundary-safe matching."""
    text = str(value or "").casefold().replace("’", "'")
    # Treat apostrophes as part of the word so "don't" and "dont" agree, while
    # all other punctuation (including hyphens) becomes a word boundary.
    text = text.replace("'", "")
    return " ".join(part for part in re.split(r"[\W_]+", text) if part)


def _matching_trigger_signals(query: str, trigger_signals: Any) -> list[str]:
    """Return stored trigger phrases that are explicitly present in the query.

    Reflection defines these as specific words or phrases in the user query.
    Semantic similarity still discovers candidate insights, but a negative
    constraint must match at least one modern trigger signal before it can
    suppress a tool. Unscoped legacy negatives are unsafe and are ignored.
    """
    normalized_query = _normalize_trigger_text(query)
    if not normalized_query:
        return []

    padded_query = f" {normalized_query} "
    matches: list[str] = []
    for signal in _coerce_string_list(trigger_signals):
        normalized_signal = _normalize_trigger_text(signal)
        if normalized_signal and f" {normalized_signal} " in padded_query:
            matches.append(signal)
    return matches


def _insight_authority(insight: dict[str, Any]) -> float:
    """Rank conflicting learned guidance by relevance and observed reliability."""
    authority = float(insight.get('relevance') or 0.0)
    evidence_count = max(0, int(insight.get('evidence_count') or 0))
    authority *= 1.0 + (0.10 * min(max(0, evidence_count - 1), 4))

    times_applied = max(0, int(insight.get('times_applied') or 0))
    times_helpful = max(0, int(insight.get('times_helpful') or 0))
    if times_applied >= 3:
        success_rate = min(1.0, times_helpful / times_applied)
        authority *= 0.75 + (0.50 * success_rate)

    failures = max(0, int(insight.get('consecutive_failures') or 0))
    authority *= 0.8 ** failures
    if insight.get('matched_trigger_signals'):
        authority *= 1.15
    return authority


def _resolve_relevant_insight_conflicts(
    insights: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Remove contradictory tool guidance before it reaches Tool RAG or the LLM."""
    by_tool: dict[str, dict[str, list[int]]] = {}
    for index, insight in enumerate(insights):
        constraint_type = insight.get('constraint_type', 'positive')
        if constraint_type == 'negative':
            tools = _coerce_string_list(insight.get('avoided_tools', []))
            side = 'negative'
        else:
            tools = _coerce_string_list(insight.get('preferred_tools', {}))
            side = 'positive'
        for tool in tools:
            by_tool.setdefault(tool, {'positive': [], 'negative': []})[side].append(index)

    suppressed: set[int] = set()
    dominance_ratio = max(
        1.0,
        get_float('INTELLIGENCE_CONFLICT_DOMINANCE_RATIO', 1.25),
    )
    for tool, sides in by_tool.items():
        if not sides['positive'] or not sides['negative']:
            continue
        positive_score = max(_insight_authority(insights[i]) for i in sides['positive'])
        negative_score = max(_insight_authority(insights[i]) for i in sides['negative'])
        if positive_score >= negative_score * dominance_ratio:
            suppressed.update(sides['negative'])
            outcome = 'positive'
        elif negative_score >= positive_score * dominance_ratio:
            suppressed.update(sides['positive'])
            outcome = 'negative'
        else:
            # Ambiguous learned advice must not remove or force the tool.
            suppressed.update(sides['positive'])
            suppressed.update(sides['negative'])
            outcome = 'neutral'
        logger.debug(
            "Resolved Intelligence conflict for %s: %s "
            "(positive=%.3f, negative=%.3f)",
            tool,
            outcome,
            positive_score,
            negative_score,
        )

    return [insight for index, insight in enumerate(insights) if index not in suppressed]


def _select_top_relevant_insights(
    insights: list[dict[str, Any]],
    top_k: int,
) -> list[dict[str, Any]]:
    """Resolve conflicts only among candidates eligible for this output window."""
    candidates = insights[:max(0, top_k)]
    return _resolve_relevant_insight_conflicts(candidates)


def _workflow_semantic_pattern(
    reflection: dict[str, Any],
    metadata: dict[str, Any],
) -> str:
    """Anchor workflow retrieval to the recipe purpose, not test scaffolding."""
    fallback = str(reflection.get('applies_to') or '').strip()
    preferred_workflow_id = str(
        metadata.get('preferred_workflow_id') or ''
    ).strip()
    if not preferred_workflow_id:
        return fallback

    workflow_context = reflection.get('_workflow_execution_context')
    if not isinstance(workflow_context, dict):
        return fallback
    if str(workflow_context.get('selected_workflow_id') or '').strip() != preferred_workflow_id:
        return fallback

    name = str(workflow_context.get('selected_workflow_name') or '').strip()
    summary = str(workflow_context.get('selected_workflow_summary') or '').strip()
    triggers = workflow_context.get('selected_workflow_triggers')
    triggers = triggers if isinstance(triggers, dict) else {}
    trigger_phrases = _coerce_string_list(triggers.get('patterns'))
    trigger_phrases.extend(_coerce_string_list(triggers.get('keywords')))
    trigger_phrases = list(dict.fromkeys(trigger_phrases))

    semantic_parts = [part for part in (name, summary) if part]
    if trigger_phrases:
        semantic_parts.append(" ".join(trigger_phrases))
    return ". ".join(semantic_parts) or fallback


def _has_provider_native_search(labels: list[str] | None) -> bool:
    """Return True when provider-native web/X search was used."""
    if not labels:
        return False
    return any(label in {'native:x_search', 'native:web_search'} for label in labels)


def _is_external_search_tool(tool_name: str | None) -> bool:
    """Detect normal Jarvis search tools that should not override native-search lessons."""
    if not tool_name:
        return False
    return any(tool_name.startswith(prefix) for prefix in _EXTERNAL_SEARCH_TOOL_PREFIXES)


def should_suppress_preferred_tool_for_native_search(
    reflection: dict[str, Any],
    experience: sqlite3.Row | dict[str, Any],
) -> bool:
    """
    Suppress misleading preferred_tool storage when native search was the key evidence path.

    This prevents reflections like "perform X-targeted searches first" from becoming
    "prefer mcp_brave_search_*" just because the original path ended on Brave.
    """
    raw_data_text = _row_value(experience, 'raw_data', '{}')
    try:
        raw_data = json.loads(raw_data_text) if raw_data_text else {}
    except Exception:
        raw_data = {}

    context_data = raw_data.get('context', {})
    native_labels = context_data.get('provider_native_tools_used', []) or []
    if not _has_provider_native_search(native_labels):
        return False

    preferred_tool = reflection.get('preferred_tool')
    if preferred_tool and _is_external_search_tool(preferred_tool):
        return True

    final_tool = _row_value(experience, 'final_tool')
    if not preferred_tool and final_tool and _is_external_search_tool(final_tool):
        return True

    return False


class IntelligenceLogger:
    """Dedicated logger for intelligence layer operations."""

    def __init__(self):
        self.project_root = Path(__file__).parent.parent
        self.log_dir = self.project_root / "logs" / "intelligence"
        self.log_dir.mkdir(parents=True, exist_ok=True)

    def _get_log_file(self) -> Path:
        """Get today's log file."""
        date_str = datetime.now().strftime("%Y-%m-%d")
        return self.log_dir / f"intelligence-{date_str}.jsonl"

    def log(self, event_type: str, data: dict[str, Any]):
        """Log an intelligence event."""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "event": event_type,
            **redact_sensitive_data(data)
        }

        try:
            with open(self._get_log_file(), "a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception as e:
            logger.warning(f"Failed to write intelligence log: {e}")

    def log_experience_recorded(self, exp_id: int, query: str, tools: list[str], success: bool):
        """Log when an experience is recorded."""
        self.log("experience_recorded", {
            "experience_id": exp_id,
            "query": redact_sensitive_text(query)[:200],
            "tools_used": tools,
            "success": success
        })

    def log_reflection_started(self, exp_id: int, query: str):
        """Log when reflection starts."""
        self.log("reflection_started", {
            "experience_id": exp_id,
            "query": redact_sensitive_text(query)[:200]
        })

    def log_reflection_prompt(self, exp_id: int, prompt: str):
        """Log the reflection prompt sent to LLM."""
        self.log("reflection_prompt", {
            "experience_id": exp_id,
            "prompt_preview": redact_sensitive_text(prompt)[:500],
            "prompt_length": len(prompt)
        })

    def log_reflection_response(
        self,
        exp_id: int,
        response: dict[str, Any],
        provider: str,
        model: str,
        usage_info: dict[str, Any] | None = None
    ):
        """Log the reflection response from LLM."""
        self.log("reflection_response", {
            "experience_id": exp_id,
            "provider": provider,
            "model": model,
            "response": response,
            "usage_info": usage_info or {}
        })

    def log_insight_created(self, insight_id: int, constraint_type: str, description: str, confidence: float):
        """Log when a new insight is created."""
        self.log("insight_created", {
            "insight_id": insight_id,
            "constraint_type": constraint_type,
            "description": redact_sensitive_text(description)[:200],
            "confidence": confidence
        })

    def log_decay_applied(self, insight_id: int, old_confidence: float, new_confidence: float,
                          days_since_applied: int, reason: str):
        """Log when confidence decay is applied to an insight."""
        self.log("decay_applied", {
            "insight_id": insight_id,
            "old_confidence": round(old_confidence, 4),
            "new_confidence": round(new_confidence, 4),
            "decay_amount": round(old_confidence - new_confidence, 4),
            "days_since_applied": days_since_applied,
            "reason": reason
        })

    def log_anomaly_detected(self, experience_id: int, anomaly_type: str, details: dict[str, Any]):
        """Log when an anomaly is detected in an experience."""
        self.log("anomaly_detected", {
            "experience_id": experience_id,
            "anomaly_type": anomaly_type,
            "details": details
        })

    def log_meta_cognition(self, meta_type: str, observation: str, conclusion: str,
                           action: str, confidence: float):
        """Log meta-cognition findings."""
        self.log("meta_cognition", {
            "meta_type": meta_type,
            "observation": observation,
            "conclusion": conclusion,
            "action_taken": action,
            "confidence": confidence
        })

    def log_maintenance_run(self, job_type: str, stats: dict[str, Any]):
        """Log when a maintenance job runs."""
        self.log("maintenance_run", {
            "job_type": job_type,
            "stats": stats
        })

    def log_insight_pruned(self, insight_id: int, description: str, reason: str,
                           final_confidence: float):
        """Log when an insight is pruned/removed."""
        self.log("insight_pruned", {
            "insight_id": insight_id,
            "description": redact_sensitive_text(description)[:200],
            "reason": reason,
            "final_confidence": final_confidence
        })

    def log_insight_updated(self, insight_id: int, old_confidence: float, new_confidence: float):
        """Log when an existing insight is updated."""
        self.log("insight_updated", {
            "insight_id": insight_id,
            "old_confidence": old_confidence,
            "new_confidence": new_confidence
        })

    def log_insights_applied(self, query: str, insights: list[dict], biases: dict[str, float]):
        """Log when insights are applied to routing."""
        self.log("insights_applied", {
            "query": redact_sensitive_text(query)[:200],
            "insights_count": len(insights),
            "insights": [{"id": i.get("id"), "relevance": i.get("relevance")} for i in insights[:5]],
            "tool_biases": biases
        })

    def log_insight_skipped(self, reason: str, details: str):
        """Log when an insight is not stored (factual, low generalizability, etc.)"""
        self.log("insight_skipped", {
            "reason": reason,
            "details": redact_sensitive_text(details)[:200]
        })


# Global intelligence logger instance
_intel_logger = None

def get_intel_logger() -> IntelligenceLogger:
    """Get the intelligence logger instance."""
    global _intel_logger
    if _intel_logger is None:
        _intel_logger = IntelligenceLogger()
    return _intel_logger


class IntelligenceLayer:
    """
    Self-learning intelligence that operates in continuous vector space.

    Architecture:
    1. Experience Memory - Raw experiences with embeddings
    2. Insight Memory - Generalized learnings from reflection
    3. Meta Memory - Knowledge about the learning process itself
    """

    def __init__(self, db_path: str = None, *, load_runtime_config: bool = True):
        """Initialize the intelligence layer and ensure its database schema."""
        if load_runtime_config or db_path is None:
            load_config()

        if db_path is None:
            project_root = Path(__file__).parent.parent.resolve()
            data_dir = project_root / "data"
            data_dir.mkdir(exist_ok=True)

            # Resolve data mode from the active config scope / JARVIS_MODE,
            # never from the chat provider (matches memory_db selection).
            from config_loader import get_active_config_mode
            mode = get_active_config_mode()
            if mode == 'local':
                db_path = str(data_dir / "jarvis_intelligence_local.db")
            else:
                db_path = str(data_dir / "jarvis_intelligence.db")

        self.db_path = db_path
        self.conn = None
        self._embedding_cache = {}
        self._init_db()

        # Learning parameters
        self.learning_rate = get_float('INTELLIGENCE_LEARNING_RATE', 0.1)
        self.decay_rate = get_float('INTELLIGENCE_DECAY_RATE', 0.95)
        self.anomaly_threshold = get_float('INTELLIGENCE_ANOMALY_THRESHOLD', 2.5)
        self.min_confidence = get_float('INTELLIGENCE_MIN_CONFIDENCE', 0.3)
        self.relevance_threshold = get_float('INTELLIGENCE_RELEVANCE_THRESHOLD', 0.2)
        self.negative_weight = get_float('INTELLIGENCE_NEGATIVE_WEIGHT', 1.0)  # Multiplier for negative constraints

    def _init_db(self):
        """Initialize intelligence database with experience and insight tables."""
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row

        # SECURITY: Restrict DB file to owner-only (600) since it contains
        # learning data and interaction history. sqlite3.connect() uses the
        # process umask (typically 022 → 644), so we fix it after creation.
        try:
            os.chmod(self.db_path, 0o600)
        except OSError:
            pass  # Non-fatal: may fail on some filesystems

        cursor = self.conn.cursor()

        # ============================================
        # EXPERIENCE MEMORY
        # Raw experiences from each interaction
        # ============================================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS experiences (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

                -- The interaction
                query TEXT NOT NULL,
                query_embedding BLOB,
                context_summary TEXT,
                context_embedding BLOB,

                -- What happened
                tools_used TEXT,  -- JSON list
                tool_sequence TEXT,  -- Order matters: ["tool1", "tool2"]
                turns_taken INTEGER,
                final_tool TEXT,  -- The tool that actually answered

                -- Outcome signals
                outcome_success BOOLEAN,
                user_satisfied BOOLEAN,  -- Inferred from signals
                had_to_retry BOOLEAN,
                had_to_clarify BOOLEAN,
                error_occurred BOOLEAN,

                -- Rich outcome embedding (captures the "feeling" of the outcome)
                outcome_embedding BLOB,

                -- Raw data for later analysis
                raw_data TEXT  -- JSON blob of everything
            )
        """)

        # ============================================
        # INSIGHT MEMORY
        # Generalized learnings from reflection
        # ============================================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS insights (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

                -- The insight itself
                insight_type TEXT,  -- 'tool_preference', 'query_pattern', 'error_pattern', 'macro_skill'
                description TEXT,  -- Natural language description
                insight_embedding BLOB,

                -- PHASE 1: Constraint type (positive vs negative)
                constraint_type TEXT DEFAULT 'positive',  -- 'positive' = DO USE, 'negative' = DO NOT USE

                -- What this insight applies to
                applies_to_pattern TEXT,  -- e.g., "status queries", "memory lookups"
                pattern_embedding BLOB,
                trigger_concept TEXT,  -- Specific concept that triggers this insight

                -- Learned associations
                preferred_tools TEXT,  -- JSON: {"mcp_fetch": 0.8, "search_memory": 0.3}
                preferred_workflow_id TEXT,  -- Specific recipe selected through the workflow meta-tool
                preferred_tool_sequence TEXT,  -- JSON list: advisory observed sequence, not a hard workflow
                supporting_tools TEXT,  -- JSON list: useful secondary tools observed with the primary preference
                sequence_required BOOLEAN DEFAULT 0,  -- True only when order is essential
                avoided_tools TEXT,  -- JSON: ["search_memory"] - tools to explicitly avoid
                avoided_patterns TEXT,  -- JSON list of patterns to avoid
                trigger_signals TEXT,  -- JSON list of exact query signals from reflection
                primary_intent TEXT,  -- Compact intent label used for auditing/gating

                -- PHASE 1: Quality filters
                generalizability TEXT DEFAULT 'medium',  -- 'high', 'medium', 'low' (filter out 'low')
                reasoning TEXT,  -- Why this insight was learned

                -- Confidence and strength
                confidence REAL DEFAULT 0.5,  -- 0.0 to 1.0
                strength REAL DEFAULT 0.5,  -- How strongly to apply this
                evidence_count INTEGER DEFAULT 1,  -- How many experiences support this

                -- PHASE 1: Decay tracking
                last_applied TIMESTAMP,
                last_outcome TEXT,  -- 'success', 'failure', 'unused'
                times_applied INTEGER DEFAULT 0,
                times_helpful INTEGER DEFAULT 0,  -- When applied, was it helpful?
                times_failed INTEGER DEFAULT 0,  -- When applied, did it fail?
                consecutive_failures INTEGER DEFAULT 0,  -- For rapid decay on repeated failures

                -- Audit provenance for the first experience that created this insight.
                -- Additional supporting/refuting records live in insight_evidence.
                source_experience_id INTEGER,
                source_web_conversation_id TEXT,
                source_query TEXT,
                source_tool_sequence TEXT,
                source_reflection_json TEXT
            )
        """)

        # ============================================
        # META MEMORY
        # Knowledge about the learning process
        # ============================================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS meta_knowledge (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

                -- What meta-knowledge is this?
                meta_type TEXT,  -- 'learning_quality', 'blind_spot', 'over_generalization'
                description TEXT,

                -- Self-assessment
                observation TEXT,  -- What was observed
                conclusion TEXT,  -- What was concluded
                action_taken TEXT,  -- What adjustment was made

                -- Tracking
                confidence REAL DEFAULT 0.5,
                validated BOOLEAN DEFAULT 0
            )
        """)

        # ============================================
        # REFLECTION QUEUE
        # Experiences waiting for reflection
        # ============================================
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS reflection_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                experience_id INTEGER,
                priority REAL DEFAULT 0.5,
                queued_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                processed BOOLEAN DEFAULT 0,
                FOREIGN KEY (experience_id) REFERENCES experiences(id)
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS insight_evidence (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                insight_id INTEGER NOT NULL,
                experience_id INTEGER,
                web_conversation_id TEXT,
                query TEXT,
                tool_sequence TEXT,
                preferred_tool TEXT,
                preferred_workflow_id TEXT,
                avoided_tool TEXT,
                preferred_tool_sequence TEXT,
                supporting_tools TEXT,
                reflection_json TEXT,
                confidence REAL,
                confidence_delta REAL,
                action TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (insight_id) REFERENCES insights(id),
                FOREIGN KEY (experience_id) REFERENCES experiences(id)
            )
        """)

        # Indexes for efficient queries
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_exp_timestamp ON experiences(timestamp)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_insight_type ON insights(insight_type)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_insight_confidence ON insights(confidence)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_reflection_pending ON reflection_queue(processed, priority)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_insight_evidence_insight ON insight_evidence(insight_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_insight_evidence_experience ON insight_evidence(experience_id)")

        # PHASE 1: Schema migration for existing databases
        self._migrate_schema(cursor)
        self._backfill_insight_sources_from_evidence(cursor)
        self._backfill_raw_data_experience_ids(cursor)
        ensure_embedding_metadata_table(self.conn)

        self.conn.commit()

    def _migrate_schema(self, cursor):
        """Add new columns to existing databases (PHASE 1 upgrades)."""
        # Get existing columns in insights table
        cursor.execute("PRAGMA table_info(insights)")
        existing_columns = {row[1] for row in cursor.fetchall()}

        # New columns to add
        new_columns = [
            ("constraint_type", "TEXT DEFAULT 'positive'"),
            ("trigger_concept", "TEXT"),
            ("trigger_signals", "TEXT"),
            ("primary_intent", "TEXT"),
            ("avoided_tools", "TEXT"),
            ("preferred_workflow_id", "TEXT"),
            ("preferred_tool_sequence", "TEXT"),
            ("supporting_tools", "TEXT"),
            ("sequence_required", "BOOLEAN DEFAULT 0"),
            ("generalizability", "TEXT DEFAULT 'medium'"),
            ("reasoning", "TEXT"),
            ("reflection_provider", "TEXT"),
            ("reflection_model", "TEXT"),
            ("reflection_input_tokens", "INTEGER DEFAULT 0"),
            ("reflection_output_tokens", "INTEGER DEFAULT 0"),
            ("reflection_total_tokens", "INTEGER DEFAULT 0"),
            ("reflection_cost_usd", "REAL DEFAULT 0"),
            ("last_outcome", "TEXT"),
            ("times_failed", "INTEGER DEFAULT 0"),
            ("consecutive_failures", "INTEGER DEFAULT 0"),
            ("source_experience_id", "INTEGER"),
            ("source_web_conversation_id", "TEXT"),
            ("source_query", "TEXT"),
            ("source_tool_sequence", "TEXT"),
            ("source_reflection_json", "TEXT"),
        ]

        for col_name, col_def in new_columns:
            if col_name not in existing_columns:
                try:
                    cursor.execute(f"ALTER TABLE insights ADD COLUMN {col_name} {col_def}")
                    logger.info(f"Added column {col_name} to insights table")
                except sqlite3.OperationalError as e:
                    # Column might already exist or other issue
                    logger.debug(f"Could not add column {col_name}: {e}")

        cursor.execute("PRAGMA table_info(insight_evidence)")
        evidence_columns = {row[1] for row in cursor.fetchall()}
        if "preferred_workflow_id" not in evidence_columns:
            try:
                cursor.execute(
                    "ALTER TABLE insight_evidence "
                    "ADD COLUMN preferred_workflow_id TEXT"
                )
            except sqlite3.OperationalError as e:
                logger.debug(
                    "Could not add preferred_workflow_id to insight_evidence: %s",
                    e,
                )

    def _backfill_insight_sources_from_evidence(self, cursor: sqlite3.Cursor) -> None:
        """Populate blank insight source fields from their newest evidence row."""
        try:
            cursor.execute("""
                UPDATE insights
                SET source_experience_id = COALESCE(
                        source_experience_id,
                        (
                            SELECT e.experience_id
                            FROM insight_evidence e
                            WHERE e.insight_id = insights.id
                              AND e.experience_id IS NOT NULL
                            ORDER BY e.id DESC
                            LIMIT 1
                        )
                    ),
                    source_web_conversation_id = COALESCE(
                        NULLIF(source_web_conversation_id, ''),
                        (
                            SELECT e.web_conversation_id
                            FROM insight_evidence e
                            WHERE e.insight_id = insights.id
                              AND e.web_conversation_id IS NOT NULL
                              AND e.web_conversation_id != ''
                            ORDER BY e.id DESC
                            LIMIT 1
                        )
                    ),
                    source_query = COALESCE(
                        NULLIF(source_query, ''),
                        (
                            SELECT e.query
                            FROM insight_evidence e
                            WHERE e.insight_id = insights.id
                              AND e.query IS NOT NULL
                              AND e.query != ''
                            ORDER BY e.id DESC
                            LIMIT 1
                        )
                    ),
                    source_tool_sequence = COALESCE(
                        NULLIF(source_tool_sequence, ''),
                        (
                            SELECT e.tool_sequence
                            FROM insight_evidence e
                            WHERE e.insight_id = insights.id
                              AND e.tool_sequence IS NOT NULL
                              AND e.tool_sequence != ''
                            ORDER BY e.id DESC
                            LIMIT 1
                        )
                    ),
                    source_reflection_json = COALESCE(
                        NULLIF(source_reflection_json, ''),
                        (
                            SELECT e.reflection_json
                            FROM insight_evidence e
                            WHERE e.insight_id = insights.id
                              AND e.reflection_json IS NOT NULL
                              AND e.reflection_json != ''
                            ORDER BY e.id DESC
                            LIMIT 1
                        )
                    )
                WHERE EXISTS (
                    SELECT 1 FROM insight_evidence e WHERE e.insight_id = insights.id
                )
                  AND (
                    source_experience_id IS NULL
                    OR source_web_conversation_id IS NULL OR source_web_conversation_id = ''
                    OR source_query IS NULL OR source_query = ''
                    OR source_tool_sequence IS NULL OR source_tool_sequence = ''
                    OR source_reflection_json IS NULL OR source_reflection_json = ''
                  )
            """)
        except sqlite3.OperationalError as e:
            logger.debug(f"Could not backfill insight provenance: {e}")

    def _backfill_raw_data_experience_ids(self, cursor: sqlite3.Cursor) -> None:
        """Repair older raw_data blobs that captured experience_id before insert."""
        try:
            rows = cursor.execute("""
                SELECT id, raw_data
                FROM experiences
                WHERE raw_data LIKE '%"experience_id": null%'
                   OR raw_data LIKE '%"completion_guard"%'
            """).fetchall()
        except sqlite3.OperationalError as e:
            logger.debug(f"Could not scan raw_data for experience_id backfill: {e}")
            return

        for row in rows:
            try:
                raw_data = json.loads(row['raw_data'] or '{}')
            except Exception:
                continue
            if not isinstance(raw_data, dict):
                continue

            changed = False
            context = raw_data.get('context')
            if isinstance(context, dict) and context.get('experience_id') in (None, '', -1):
                context['experience_id'] = row['id']
                changed = True

            completion_guard = raw_data.get('completion_guard')
            if isinstance(completion_guard, dict) and completion_guard.get('experience_id') in (None, '', -1):
                completion_guard['experience_id'] = row['id']
                changed = True

            if changed:
                cursor.execute(
                    "UPDATE experiences SET raw_data = ? WHERE id = ?",
                    (json.dumps(raw_data, default=str), row['id'])
                )

    # ============================================
    # EMBEDDING UTILITIES
    # ============================================

    def _embedding_namespace_count(self, namespace: str) -> int:
        """Return the number of persisted vectors in one Intelligence namespace."""
        queries = {
            INTELLIGENCE_QUERY_NAMESPACE:
                "SELECT COUNT(*) FROM experiences WHERE query_embedding IS NOT NULL",
            INTELLIGENCE_CONTEXT_NAMESPACE:
                "SELECT COUNT(*) FROM experiences WHERE context_embedding IS NOT NULL",
            INTELLIGENCE_OUTCOME_NAMESPACE:
                "SELECT COUNT(*) FROM experiences WHERE outcome_embedding IS NOT NULL",
            INTELLIGENCE_INSIGHT_NAMESPACE:
                "SELECT COUNT(*) FROM insights WHERE insight_embedding IS NOT NULL",
            INTELLIGENCE_PATTERN_NAMESPACE:
                "SELECT COUNT(*) FROM insights WHERE pattern_embedding IS NOT NULL",
        }
        return int(self.conn.execute(queries[namespace]).fetchone()[0])

    def _get_embedding(
        self,
        text: str,
        *,
        role: str = "query",
        namespace: str | None = None,
        title: str | None = None,
    ) -> np.ndarray | None:
        """Get embedding for text, with caching."""
        if not text or not text.strip():
            return None

        try:
            fingerprint = None
            if namespace:
                fingerprint = require_embedding_namespace(
                    self.conn,
                    namespace,
                    vector_count=self._embedding_namespace_count(namespace),
                )
            cache_payload = json.dumps(
                {
                    "namespace": namespace,
                    "fingerprint": fingerprint,
                    "role": role,
                    "title": title or "",
                    "text": text,
                },
                sort_keys=True,
            )
            cache_key = hashlib.md5(cache_payload.encode()).hexdigest()
            if cache_key in self._embedding_cache:
                return self._embedding_cache[cache_key]

            # Import embedding function from existing infrastructure
            from embeddings import get_embedding
            embedding = get_embedding(text, role=role, title=title)

            if embedding is not None:
                self._embedding_cache[cache_key] = np.array(embedding)
                return self._embedding_cache[cache_key]
        except Exception as e:
            logger.warning(f"Failed to get embedding: {e}")

        return None

    def _get_persistable_embedding(
        self,
        text: str,
        *,
        role: str,
        namespace: str,
        title: str | None = None,
    ) -> np.ndarray | None:
        """Get a real provider embedding for storage, never a hash fallback."""
        if not text or not text.strip():
            return None

        try:
            from embeddings import get_persistable_embedding
            require_embedding_namespace(
                self.conn,
                namespace,
                vector_count=self._embedding_namespace_count(namespace),
            )
            result = np.array(
                get_persistable_embedding(text, role=role, title=title)
            )
            record_embedding_namespace_complete(self.conn, namespace)
            return result
        except Exception as exc:
            logger.warning("Persistent intelligence embedding skipped: %s", exc)
            return None

    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Compute cosine similarity between two vectors."""
        if a is None or b is None:
            return 0.0

        vector_a = np.asarray(a)
        vector_b = np.asarray(b)
        if vector_a.shape != vector_b.shape:
            raise ValueError(
                f"Embedding shape mismatch: {vector_a.shape} != {vector_b.shape}"
            )

        norm_a = np.linalg.norm(vector_a)
        norm_b = np.linalg.norm(vector_b)

        if norm_a == 0 or norm_b == 0:
            return 0.0

        return float(np.dot(vector_a, vector_b) / (norm_a * norm_b))

    def _serialize_embedding(self, embedding: np.ndarray) -> bytes:
        """Serialize numpy array for database storage."""
        if embedding is None:
            return None
        return pickle.dumps(embedding)

    def _deserialize_embedding(self, blob: bytes) -> np.ndarray | None:
        """Deserialize numpy array from database.

        Handles both JSON format (newer) and pickle format (older).
        CRITICAL: Must catch UnicodeDecodeError for pickle blobs!
        """
        if blob is None:
            return None

        # Try JSON first (newer format)
        try:
            return np.array(json.loads(blob.decode('utf-8')))
        except (json.JSONDecodeError, AttributeError, UnicodeDecodeError):
            # Fall back to pickle (older format)
            return pickle.loads(blob)

    def _parse_timestamp(self, value: Any) -> datetime | None:
        """Parse SQLite/ISO timestamps defensively for maintenance jobs."""
        if not value:
            return None
        try:
            return datetime.fromisoformat(str(value).replace('Z', '+00:00').replace('+00:00', ''))
        except Exception:
            return None

    # ============================================
    # EXPERIENCE RECORDING
    # ============================================

    async def record_experience(
        self,
        query: str,
        tools_used: list[str],
        outcome: dict[str, Any],
        context: dict[str, Any] | None = None,
        user_signals: dict[str, Any] | None = None,
        queue_reflection: bool = True,
    ) -> int:
        """
        Record a complete experience for later reflection.

        Args:
            query: The user's original query
            tools_used: List of tools invoked (in order)
            outcome: Dict with keys like 'success', 'turns', 'error', etc.
            context: Optional context about the conversation state
            user_signals: Optional signals like 'thanked', 'clarified', 'retried'
            queue_reflection: When false, keep the experience and skip reflection_queue

        Returns:
            Experience ID
        """
        user_signals = user_signals or {}
        context = context or {}
        query = redact_sensitive_text(query or "")
        outcome = redact_sensitive_data(outcome or {})
        context = redact_sensitive_data(context)
        user_signals = redact_sensitive_data(user_signals)

        # Generate embeddings
        query_embedding = self._get_persistable_embedding(
            query,
            role="document",
            namespace=INTELLIGENCE_QUERY_NAMESPACE,
            title="User query",
        )

        # Create rich outcome description for embedding
        outcome_description = self._describe_outcome(query, tools_used, outcome, user_signals)
        outcome_embedding = self._get_persistable_embedding(
            outcome_description,
            role="document",
            namespace=INTELLIGENCE_OUTCOME_NAMESPACE,
            title="Interaction outcome",
        )

        # Context embedding
        context_summary = json.dumps(context)[:750] if context else ""
        context_embedding = (
            self._get_persistable_embedding(
                context_summary,
                role="document",
                namespace=INTELLIGENCE_CONTEXT_NAMESPACE,
                title="Conversation context",
            )
            if context_summary else None
        )

        # Infer satisfaction
        user_satisfied = self._infer_satisfaction(outcome, user_signals)

        cursor = self.conn.cursor()
        raw_data = {
            'query': query,
            'tools_used': tools_used,
            'outcome': outcome,
            'context': context,
            'user_signals': user_signals,
            'timestamp': datetime.now().isoformat()
        }

        cursor.execute("""
            INSERT INTO experiences (
                query, query_embedding, context_summary, context_embedding,
                tools_used, tool_sequence, turns_taken, final_tool,
                outcome_success, user_satisfied, had_to_retry, had_to_clarify,
                error_occurred, outcome_embedding, raw_data
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            query,
            self._serialize_embedding(query_embedding),
            context_summary,
            self._serialize_embedding(context_embedding),
            json.dumps(tools_used),
            json.dumps(tools_used),  # sequence same as tools_used for now
            outcome.get('turns', len(tools_used)),
            tools_used[-1] if tools_used else None,
            outcome.get('success', True),
            user_satisfied,
            user_signals.get('retried', False),
            user_signals.get('clarified', False),
            outcome.get('error', False),
            self._serialize_embedding(outcome_embedding),
            json.dumps(raw_data, default=str)
        ))

        experience_id = cursor.lastrowid
        if isinstance(raw_data.get('context'), dict):
            raw_data['context']['experience_id'] = experience_id
            cursor.execute(
                "UPDATE experiences SET raw_data = ? WHERE id = ?",
                (json.dumps(raw_data, default=str), experience_id)
            )

        # Queue for reflection with priority based on learning value.
        # Web chat can skip this insert while still keeping the experience.
        priority = None
        if queue_reflection:
            priority = self._calculate_learning_priority(outcome, user_signals, tools_used)
            cursor.execute("""
                INSERT INTO reflection_queue (experience_id, priority)
                VALUES (?, ?)
            """, (experience_id, priority))

        self.conn.commit()

        if priority is None:
            logger.info(f"Recorded experience {experience_id} without queuing a reflection")
        else:
            logger.info(f"Recorded experience {experience_id} with priority {priority:.2f}")

        # Log to intelligence log
        get_intel_logger().log_experience_recorded(
            exp_id=experience_id,
            query=query,
            tools=tools_used,
            success=outcome.get('success', True)
        )

        return experience_id

    def _describe_outcome(
        self,
        query: str,
        tools_used: list[str],
        outcome: dict[str, Any],
        user_signals: dict[str, Any]
    ) -> str:
        """Create the canonical v1 outcome embedding document."""
        return build_outcome_embedding_text(query, tools_used, outcome, user_signals)

    def _infer_satisfaction(
        self,
        outcome: dict[str, Any],
        user_signals: dict[str, Any]
    ) -> bool:
        """Infer whether the user was satisfied."""
        # Positive signals
        if user_signals.get('thanked'):
            return True

        # Negative signals
        if user_signals.get('retried') or user_signals.get('clarified'):
            return False

        # Default to success status
        return outcome.get('success', True)

    def _calculate_learning_priority(
        self,
        outcome: dict[str, Any],
        user_signals: dict[str, Any],
        tools_used: list[str]
    ) -> float:
        """
        Calculate how valuable this experience is for learning.

        High priority:
        - Failures (we learn more from mistakes)
        - Multi-turn journeys (shows what didn't work)
        - User clarifications (misunderstanding occurred)

        Lower priority:
        - Clean single-turn successes (not much to learn)
        """
        priority = 0.5  # Base

        # Failures are valuable learning opportunities
        if not outcome.get('success', True):
            priority += 0.3

        # Multi-turn suggests initial approach was wrong
        turns = outcome.get('turns', len(tools_used))
        if turns > 1:
            priority += min(0.2, (turns - 1) * 0.05)

        # User had to clarify = we misunderstood
        if user_signals.get('clarified'):
            priority += 0.2

        # User retried = we failed them
        if user_signals.get('retried'):
            priority += 0.25

        # Cap at 1.0
        return min(1.0, priority)

    # ============================================
    # REFLECTION ENGINE
    # ============================================

    async def reflect_on_experience(
        self,
        experience_id: int,
        use_sequential_thinking: bool = True
    ) -> dict[str, Any] | None:
        """
        Deeply reflect on an experience to extract insights.

        This is where the magic happens - we don't just score,
        we think about WHY things happened.
        """
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM experiences WHERE id = ?", (experience_id,))
        exp = cursor.fetchone()

        if not exp:
            return None

        # Build reflection prompt
        raw_data = redact_sensitive_data(json.loads(exp['raw_data']))
        context_data = raw_data.get('context', {})

        # Extract LLM response and tool results for content evaluation
        llm_response = (
            context_data.get('raw_llm_response')
            or context_data.get('llm_response')
            or '[Not captured]'
        )
        final_speech = context_data.get('final_speech', '[Not captured]')
        corrected_response = context_data.get('corrected_llm_response', '[Not captured]')
        corrected_tools_used = context_data.get('corrected_tools_used', [])
        corrected_tool_results = context_data.get('corrected_tool_results', '[Not captured]')
        tool_results = context_data.get('tool_results', '[Not captured]')
        tool_trace = context_data.get('tool_trace', '[Not captured]')
        server_side_tools = context_data.get('server_side_tools', {})
        provider_native_tools_used = context_data.get('provider_native_tools_used', [])
        completion_guard = raw_data.get('completion_guard', {})
        feedback_record = raw_data.get('feedback', {})
        latest_feedback = (
            feedback_record.get('latest', {})
            if isinstance(feedback_record, dict)
            else {}
        )
        if not isinstance(latest_feedback, dict):
            latest_feedback = {}
        user_feedback_record = raw_data.get('user_feedback', {})
        latest_user_feedback = (
            user_feedback_record.get('latest', {})
            if isinstance(user_feedback_record, dict)
            else {}
        )
        if not isinstance(latest_user_feedback, dict):
            latest_user_feedback = {}
        user_feedback_metadata = (
            latest_user_feedback.get('metadata', {})
            if isinstance(latest_user_feedback.get('metadata'), dict)
            else {}
        )
        response_style = context_data.get('response_style') or '[Not captured]'
        qa_word_limit = context_data.get('qa_word_limit') or '[Not captured]'
        multi_turn_word_limit = context_data.get('multi_turn_word_limit') or '[Not captured]'

        # CRITICAL: What tools were AVAILABLE to the LLM (from Tool RAG + ghost tools)
        available_tools = context_data.get('available_tools', [])
        tool_policy = context_data.get('tool_policy')
        tool_rag_skipped = context_data.get('tool_rag_skipped')
        chat_only_mode = tool_policy == 'none'

        # Determine if this was a suboptimal experience
        tools_list = json.loads(exp['tools_used'])
        (
            len(tools_list) > 1 or
            not exp['outcome_success'] or
            exp['had_to_retry'] or
            exp['had_to_clarify']
        )

        # Format available tools list
        if chat_only_mode:
            available_tools_str = '(intentionally disabled by Chat only policy)'
        else:
            available_tools_str = ', '.join(available_tools) if available_tools else '[Not captured]'
        tool_policy_str = (
            'none (Chat only; tools intentionally disabled)'
            if chat_only_mode
            else (str(tool_policy) if tool_policy else '[Not captured]')
        )
        tool_rag_skipped_str = (
            str(tool_rag_skipped).lower()
            if isinstance(tool_rag_skipped, bool)
            else '[Not captured]'
        )
        chat_only_evaluation = ""
        if chat_only_mode:
            chat_only_evaluation = """
CHAT ONLY EVALUATION:
- The user intentionally selected Chat only. No client-side or provider-hosted tools were available, so using zero tools was correct and must not be treated as missing telemetry or a routing failure.
- Evaluate the direct answer for relevance, accuracy, completeness, clarity, tone, and whether it used conversation or injected memory context appropriately.
- Do not infer that a tool should have been used, do not penalize the absence of tools, and do not create preferred_tool, avoided_tool, preferred_workflow_id, preferred_tool_sequence, or supporting_tools conclusions from this turn.
- The user's manual Chat-only selection is not evidence that the same query should avoid tools in Auto mode. Do not restate the Chat-only policy as a learned routing rule.
- If there is no independently reusable procedural lesson, return is_procedural=false so the reflection is processed without storing a tool-routing insight.

CRITICAL EVALUATION - CHAT ONLY:
1. Did the response directly and completely answer the user's request?
2. Was it accurate, internally consistent, and appropriately qualified where certainty was limited?
3. Did its clarity, tone, detail, and formatting match the configured response style?
4. Did it use relevant conversation or injected memory context without inventing unsupported details?
5. If current or external information was required, did it clearly explain that Chat only could not fetch it?
6. Treat explicit user reaction, evaluator feedback, and Completion Guard evidence according to their actual meanings; do not invent a retry, clarification, or tool failure.
7. If no independently reusable procedural lesson remains, return is_procedural=false.
"""
        tools_used_list = json.loads(exp['tools_used']) if exp['tools_used'] else []
        workflow_execution = context_data.get('workflow_execution')
        if not isinstance(workflow_execution, dict):
            # Backward compatibility for reflections queued before workflow
            # execution summaries were recorded explicitly.
            from workflow_learning import extract_workflow_learning_context

            reconstructed_data = _json_loads_safely(tool_results, {})
            reconstructed_trace = _json_loads_safely(tool_trace, [])
            workflow_execution = extract_workflow_learning_context(
                {
                    "ok": bool(exp['outcome_success']),
                    "tools_used": tools_used_list,
                    "data": reconstructed_data,
                    "tool_trace": reconstructed_trace,
                },
                tools_used_list,
            )
        workflow_execution_str = (
            json.dumps(workflow_execution, default=str)
            if workflow_execution
            else "(not a workflow interaction)"
        )
        provider_native_tools_str = ', '.join(provider_native_tools_used) if provider_native_tools_used else '(none captured)'
        server_side_tools_str = json.dumps(server_side_tools) if server_side_tools else '(none captured)'
        artifact_tools = [tool for tool in ('canvas', 'stash') if tool in available_tools]
        artifact_tools_str = ', '.join(artifact_tools) if artifact_tools else '(none available)'

        # Identify tools that were available but NOT used (for reflection analysis)
        unused_tools = [t for t in available_tools if t not in tools_used_list] if available_tools else []
        unused_tools_str = ', '.join(unused_tools[:10]) if unused_tools else 'None'  # Limit to 10

        reflection_task = (
            "Analyze this Chat-only interaction for response quality and any "
            "independently reusable non-tool procedural lesson."
            if chat_only_mode
            else "Analyze this interaction to extract a PROCEDURAL insight (not a fact)."
        )
        reflection_prompt = f"""
{reflection_task}

**User Query**: {exp['query']}

**Tool Policy**: {tool_policy_str}
**Tool RAG Skipped**: {tool_rag_skipped_str}

**AVAILABLE TOOLS** (what the LLM could choose from):
{available_tools_str}

**Tools Actually Used (in order)**: {exp['tools_used']}
**Provider-Native Tools Used**: {provider_native_tools_str}
**Tools Available But NOT Used**: {unused_tools_str}
**Turns Taken**: {exp['turns_taken']}
**Final Tool**: {exp['final_tool']}
**Outcome Status**: {"SUCCESS" if exp['outcome_success'] else "FAILURE"}
**User Satisfied**: {exp['user_satisfied']}
**Had to Clarify**: {exp['had_to_clarify']}
**Had to Retry**: {exp['had_to_retry']}

**Tool Results** (what the tools returned):
{tool_results[:1500] if tool_results != '[Not captured]' else '[Not available]'}

**Tool Attempt Trace** (attempted tools, sanitized arguments, failures, and recovery):
{tool_trace[:2000] if tool_trace != '[Not captured]' else '[Not available]'}

**Workflow Execution Context** (authoritative routing-vs-recipe attribution):
{workflow_execution_str[:5000]}

**LLM Response** (what was said to the user):
{llm_response[:1000] if llm_response != '[Not captured]' else '[Not available]'}

**Final Spoken/Display Response**:
{final_speech[:600] if final_speech != '[Not captured]' else '[Not available]'}

**Corrected/Repaired Response** (if Completion Guard found one):
{corrected_response[:1000] if corrected_response != '[Not captured]' else '[Not available]'}

**Corrected Tools Used**:
{', '.join(corrected_tools_used) if corrected_tools_used else '(none captured)'}

**Corrected Tool Results**:
{corrected_tool_results[:1200] if corrected_tool_results != '[Not captured]' else '[Not available]'}

**Completion Guard Outcome**:
- Status: {completion_guard.get('status', 'none')}
- Note: {completion_guard.get('note', '') or '(none)'}
- Metadata: {json.dumps(completion_guard.get('metadata', {}))[:800] if completion_guard else '(none)'}

**Feedback Outcome**:
- Rating: {latest_feedback.get('rating', 'none')}
- Summary: {latest_feedback.get('summary', '') or '(none)'}
- Issues: {json.dumps(latest_feedback.get('issues', []), default=str)[:800] if latest_feedback else '(none)'}
- Analysis: {latest_feedback.get('analysis', '')[:800] if latest_feedback.get('analysis') else '(none)'}

**Explicit User Reaction**:
- Reaction: {latest_user_feedback.get('reaction', 'none')}
- Source: {latest_user_feedback.get('source', '') or '(none)'}
- Mode: {user_feedback_metadata.get('mode', '') or '(unknown)'}
- Provider: {user_feedback_metadata.get('provider', '') or '(unknown)'}
- Model: {user_feedback_metadata.get('model', '') or '(unknown)'}

**Presentation Context**:
- Response Style: {response_style}
- Q&A Word Limit: {qa_word_limit}
- Multi-Turn Word Limit: {multi_turn_word_limit}
- Artifact Tools Available: {artifact_tools_str}

**Provider-Native Tool Metadata**:
{server_side_tools_str}
"""
        if chat_only_mode:
            reflection_prompt += chat_only_evaluation
        else:
            reflection_prompt += """
CRITICAL EVALUATION:
1. Did the tool(s) return relevant data for the query? (tool_results vs query)
2. Did the LLM response accurately reflect the tool data? (llm_response vs tool_results)
3. Did the LLM response actually answer what the user asked? (llm_response vs query)
4. Was the FIRST tool the optimal choice, or should a different tool have been used initially?
5. If Completion Guard marked this as repaired, unresolved, or ticket_created, treat that as strong evidence the ORIGINAL answer path was insufficient even if a later repair improved it.
6. If a corrected/repaired response exists, compare the original path with the repaired path and learn from what changed.
7. Provider-native tools are metadata-only evidence paths, not normal Jarvis tool choices. If provider-native tools are listed, do NOT infer "zero-tool hallucination" from an empty tools_used list alone.
8. Do NOT create preferred_tool/avoided_tool insights that tell Jarvis to prefer or avoid provider-native tools such as native:x_search or native:code_interpreter.
9. If provider-native web/X search was part of the successful evidence path, and the lesson is about search targeting or freshness, set preferred_tool to null unless a normal Jarvis tool was clearly the decisive improvement.
10. If Tool Attempt Trace shows a failed tool call that was later corrected, extract the reusable payload/argument lesson.
11. Prefer global argument-shape lessons when they apply across tools, e.g. "tool argument values must be concrete values, not JSON schema objects."
12. Keep insight_summary short; put exact argument-shape details in why_or_why_not/reasoning when needed.
13. If Feedback Outcome has a low rating or concrete issue summary, treat that as direct evidence about why the settled answer was unsatisfactory.
14. If response style is auto/casual and the user asks for multi-item or multi-field details, consider whether an available artifact tool (canvas/stash) should have been used for the full structured output while the spoken response stayed brief. Only recommend artifact tools that appear in Artifact Tools Available.
15. If multiple tools were useful, do not force a rigid workflow. Use preferred_tool_sequence only as an observed/advisory sequence, and set sequence_required true only when the order is essential for correctness.
16. Separate primary intent from content topic. Example: "email this YouTube video" is primarily an email/send action, not a transcript-analysis request.
17. A Web upload query may already contain a completed vision result inside
    "[User uploaded an image. Vision analysis: ...]" (or the multi-image equivalent).
    Treat that attached analysis as evidence gathered BEFORE routing, not as raw user text
    that still requires a lookup.
18. For those pre-analyzed uploads, compare memory tool results against the attached vision
    evidence. If search_memory/semantic_recall only returns the newly stored artifact, the
    same stash reference, or an equivalent description, it added no unique information:
    first_tool_optimal must be false and no positive memory-tool preference should be learned.
19. Memory can still be valuable for a pre-analyzed upload when it contributes distinct,
    relevant prior knowledge (for example, the user's earlier notes about a hand sketch,
    provenance, related projects, previous uploads, or an explicit comparison/history request).
    Judge the incremental evidence; do not create a blanket rule to avoid memory for images.
20. Explicit User Reaction is direct human evidence. A reaction of `up` means the user
    strongly valued the settled answer or its tool path; identify the reusable strategy
    without turning provider/model provenance into a universal model preference. A reaction
    of `down` means the user was dissatisfied; determine the likely procedural weakness
    without inventing a retry, clarification, or tool failure that did not occur.
21. A strategy learned from a provider-native capability must remain capability-aware.
    Never store provider-native labels as normal Jarvis preferred tools, and do not assume
    another provider or local model has the same hosted capability.
22. If Workflow Execution Context is present, evaluate the LLM's choice of the specific
    workflow separately from the deterministic recipe's component execution.
23. workflow(search) and workflow(describe) are discovery operations. They may legitimately
    precede one workflow(run); do not classify those calls as retries, failed execution,
    or an inefficient component-tool sequence merely because tools_used repeats "workflow".
24. The workflow JSON owns component order. Never copy component_tools_used or step_outcomes
    into preferred_tool_sequence, and never claim the router selected those tools individually.
25. Attribute a wrong workflow ID, missing required query, or poor workflow match to workflow
    selection/input. Attribute a failed recipe step to that component/recipe. Do not turn a
    component failure into a blanket rule to avoid all workflows.
26. Learn a positive workflow preference only when run_started and run_completed are true,
    cancelled is false, outcome_success is true, and the selected workflow clearly matched
    the user's intent. Search-only, describe-only, missing-input, unavailable, preflight-failed,
    cancelled, and failed runs must not create a positive workflow preference.
27. For a valid positive workflow lesson, set preferred_tool to "workflow" and
    preferred_workflow_id to the exact selected_workflow_id. Do not create a generic
    workflow preference without a workflow ID. The stored rule must say to discover or
    confirm that recipe is currently runnable before running it.
28. After a completed workflow, do not recommend rerunning the recipe or its component tools
    in the same request. Component summarizer or LLM calls are recipe implementation details,
    not router-selected tool or model preferences.
29. For a positive workflow lesson, describe the UNDERLYING USER TASK and recipe outputs,
    using selected_workflow_name, selected_workflow_summary, triggers, and query inputs.
    Do not make "workflow discovery", "run a workflow", "previously successful procedure",
    test labels, or other orchestration scaffolding the trigger concept or applies_to pattern.
30. Example: if quick_note saves content to memory and Canvas, use an applies_to pattern like
    "Requests to save a quick note to memory and Canvas" and an insight like "For quick-note
    saving requests, confirm and run quick_note." The workflow ID belongs only in
    preferred_workflow_id; the semantic trigger remains the user's real task.

TOOL CATEGORIES (for understanding what tools do):
- **MEMORY TOOLS** (check stored knowledge): search_memory, recall, semantic_recall, get_recent_conversations, search_conversations
- **ACTION TOOLS** (do something live): mcp_fetch_fetch, network_tools, api_call, send_webhook, send_email
- **STORAGE TOOLS** (save info): remember, update_memory, forget
- **UTILITY TOOLS** (simple tasks): get_time, crypto_price, list_reminders, list_alerts
- **SEARCH TOOLS** (web search): mcp_brave_search_*, mcp_duckduckgo_*
- **BUILD TOOLS** (create projects): opencode
- **ARTIFACT TOOLS** (save structured/detail-heavy output): canvas, stash
- **PROVIDER-NATIVE TOOLS** (metadata only, not Jarvis routing choices): native:x_search, native:web_search, native:code_interpreter

SYSTEM RULES THE LLM SHOULD HAVE FOLLOWED:
- **MEMORY-FIRST RULE**: For questions about user's info, servers, configs, preferences → SHOULD check memory FIRST
- Memory-first does not require re-fetching the current upload's vision description when that
  description is already attached. Search memory only when it may add distinct stored context.
- If query mentions a server IP/service → memory might have stored health check commands with CORRECT details
- If query asks about "my X" or personal info → memory likely has stored preferences
- Using ACTION TOOLS before MEMORY TOOLS violates system rules for personal/stored data queries
- If memory search was skipped but query was about stored knowledge → first_tool_optimal = FALSE

CRITICAL: Look for signs the user-provided info might be WRONG:
- If a connection/fetch failed → memory might have the CORRECT endpoint stored
- If user says "my server at X" but X fails → the stored server might be at a DIFFERENT address
- A "not running" result could actually mean "wrong IP" if memory wasn't checked first
- When something FAILS and memory wasn't checked → strongly consider first_tool_optimal = FALSE

TOOL FAILURE RECOVERY (important for generation tools):
- If a generation tool (generate_video, generate_image, generate_music) was called multiple times, check WHY
- If the tool returned unexpected results (wrong duration, wrong size) and was retried → the LLM should have searched memory for known provider limitations instead of retrying
- Provider API limitations are NOT fixable by retrying with different params (e.g., xAI video editing cannot change duration)
- Pattern: tool fails/unexpected → retry same tool = BAD. Tool fails/unexpected → search_memory for limitations → inform user = GOOD.
- If multiple turns were used on the SAME generation tool → first_tool_optimal may be true but the RECOVERY STRATEGY was wrong

TOOL ARGUMENT RECOVERY (important for smaller/local models):
- If a failed attempt used schema-shaped values like {"type": "string"} instead of concrete user values, create a negative global insight.
- If a later attempt succeeded with corrected arguments, learn the argument convention that made it work.
- Do not store user-specific values as the rule; store the reusable procedure.

RESULT-BASED EVALUATION (most important):
- 1 tool used + good result = likely optimal first choice
- Exception: a memory tool that merely echoes evidence already attached to the query is
  redundant even if the final answer is correct; a direct answer was the optimal path
- Multiple tools + had to retry = first tool probably suboptimal
- Action tool first + connection failed = should have checked memory
- Memory empty + action succeeded = action was correct fallback
- Same generation tool called 2+ times = recovery strategy failure (should search memory or inform user)

IMPORTANT CLASSIFICATION:
- A FACT is data like "The server IP is 10.0.0.1" → belongs in Memory DB, NOT here
- A SKILL/PROCEDURE is "For status queries, use fetch tools" → belongs here

Your task: Extract a PROCEDURAL insight about TOOL SELECTION, not facts.
"""

        reflection_prompt += """
Provide your analysis as JSON:
```json
{
    "is_procedural": true/false,  // Is this insight about tool selection strategy?
    "knowledge_type": "procedural" or "factual",  // If factual, we'll skip storing

    "insight_type": "routing_correction" or "tool_preference" or "query_pattern",
    "constraint_type": "positive" or "negative",  // "positive" = DO use this approach, "negative" = DO NOT use

    "trigger_concept": "the concept/topic that triggers this rule",
    "trigger_signals": ["specific", "words", "in query", "that signal this"],

    "first_tool_optimal": true/false,
    "why_or_why_not": "explanation of what went right or wrong",

    // CONTENT EVALUATION (new)
    "tool_returned_relevant_data": true/false,  // Did the tool return useful data for the query?
    "response_matched_tool_data": true/false,   // Did the LLM accurately use the tool's output?
    "response_answered_query": true/false,      // Did the final response actually answer the user's question?
    "content_quality_notes": "brief notes on response quality issues if any",

    "rule": "ALWAYS/NEVER + action + for + query type",  // e.g., "ALWAYS prefer crypto_price over search_memory for price queries"
    "preferred_tool": "tool_name" or null,  // The tool to use
    "preferred_workflow_id": "workflow_id" or null,  // only with preferred_tool="workflow"
    "avoided_tool": "tool_name" or null,  // The tool to avoid (for negative constraints)
    "preferred_tool_sequence": ["tool_a", "tool_b"],  // optional/advisory only; [] if order was not the lesson
    "supporting_tools": ["tool_b"],  // optional secondary tools that helped but should not override primary intent
    "sequence_required": false,  // true only if the exact order is essential
    "primary_intent": "compact action/intent label",

    "applies_to": "category of queries this applies to",
    "generalizability": "high" or "medium" or "low",  // "low" insights won't be stored

    "confidence": 0.0-1.0,
    "insight_summary": "One actionable sentence, max 25 words"
}
```

Example for POSITIVE constraint (what TO do):
```json
{
    "is_procedural": true,
    "knowledge_type": "procedural",
    "insight_type": "routing_correction",
    "constraint_type": "positive",
    "trigger_concept": "server status",
    "trigger_signals": ["running", "up", "status", "alive"],
    "first_tool_optimal": false,
    "why_or_why_not": "search_memory returned stale data, mcp_fetch got live status",
    "rule": "ALWAYS use mcp_fetch_fetch for server status queries",
    "preferred_tool": "mcp_fetch_fetch",
    "avoided_tool": "search_memory",
    "preferred_tool_sequence": [],
    "supporting_tools": [],
    "sequence_required": false,
    "primary_intent": "live server status check",
    "applies_to": "System status and health check queries",
    "generalizability": "high",
    "confidence": 0.9,
    "insight_summary": "For server status queries, use mcp_fetch for real-time data."
}
```

Example for NEGATIVE constraint (what NOT to do):
```json
{
    "is_procedural": true,
    "knowledge_type": "procedural",
    "insight_type": "routing_correction",
    "constraint_type": "negative",
    "trigger_concept": "live data",
    "trigger_signals": ["current", "now", "live", "real-time"],
    "first_tool_optimal": false,
    "why_or_why_not": "search_memory returned outdated data from days ago",
    "rule": "NEVER use search_memory for queries requiring current/live data",
    "preferred_tool": null,
    "avoided_tool": "search_memory",
    "preferred_tool_sequence": [],
    "supporting_tools": [],
    "sequence_required": false,
    "primary_intent": "current live data lookup",
    "applies_to": "Any query requiring real-time information",
    "generalizability": "high",
    "confidence": 0.85,
    "insight_summary": "DO NOT use search_memory for real-time queries - data is stale."
}
```

Example for FACTUAL (should NOT be stored here):
```json
{
    "is_procedural": false,
    "knowledge_type": "factual",
    "insight_summary": "The Ollama server is at <host-ip> - this is a fact, not a procedure"
}
```
"""

        # Log reflection start
        intel_log = get_intel_logger()
        intel_log.log_reflection_started(experience_id, exp['query'])
        intel_log.log_reflection_prompt(experience_id, reflection_prompt)

        # Use sequential thinking MCP if available, otherwise direct LLM
        reflection = await self._think_deeply(
            reflection_prompt,
            use_sequential_thinking,
            experience_id=experience_id
        )

        if reflection:
            if workflow_execution:
                reflection['_workflow_execution_context'] = workflow_execution
            # Store the insight
            await self._store_insight(reflection, exp)

            # Mark as processed
            cursor.execute("""
                UPDATE reflection_queue
                SET processed = 1
                WHERE experience_id = ?
            """, (experience_id,))
            self.conn.commit()

        return reflection

    async def _think_deeply(
        self,
        prompt: str,
        use_sequential_thinking: bool = True,
        experience_id: int | None = None
    ) -> dict[str, Any] | None:
        """
        Use sequential thinking MCP or direct LLM for deep reflection.
        """
        try:
            if use_sequential_thinking:
                # Try to use sequential thinking MCP
                reflection = await self._call_sequential_thinking(prompt)
                if reflection:
                    return reflection

            # Fallback to direct LLM call
            return await self._direct_llm_reflection(prompt, experience_id=experience_id)

        except Exception as e:
            logger.error(f"Reflection failed: {e}")
            return None

    async def _call_sequential_thinking(self, prompt: str) -> dict[str, Any] | None:
        """Call the sequential thinking MCP server for structured reasoning.

        NOTE: Sequential thinking MCP is optional - falls back to direct LLM if unavailable.
        Currently disabled until MCP client async support is fully implemented.
        """
        # TODO: Re-enable when MCP client supports async initialization properly
        # For now, return None to use direct LLM reflection (which works well)
        logger.debug("Sequential thinking MCP disabled - using direct LLM reflection")
        return None

        # Original implementation (disabled):
        # try:
        #     from mcp_client import MCPManager
        #     project_root = Path(__file__).parent.parent
        #     mcp_config_path = project_root / "config" / "mcp-servers.json"
        #     manager = MCPManager(str(mcp_config_path))
        #     if 'sequentialthinking' not in manager.servers:
        #         return None
        #     client = manager.servers['sequentialthinking']
        #     # MCP client doesn't have async initialize - needs refactoring
        #     ...
        # except Exception as e:
        #     logger.warning(f"Sequential thinking unavailable: {e}")
        # return None

    async def _direct_llm_reflection(
        self,
        prompt: str,
        experience_id: int | None = None
    ) -> dict[str, Any] | None:
        """Direct LLM call for reflection when sequential thinking unavailable."""
        try:
            from llm_provider import create_configured_provider
            from model_prompt_overrides import (
                apply_prompt_override_sections,
                load_model_prompt_override,
            )
            from config_loader import load_config

            # Ensure config is loaded
            load_config()

            override_mode = get_active_config_mode()
            provider_type, model_name, provider = create_configured_provider(
                default_provider="ollama" if override_mode == "local" else "anthropic",
                mode=override_mode,
                disable_server_side_tools=True,
            )
            override = load_model_prompt_override(
                provider=provider_type,
                model=model_name,
                mode=override_mode,
            )
            prompt = apply_prompt_override_sections(
                prompt,
                override,
                prepend_sections=("intelligence_reflection_prepend",),
            )
            system_prompt = (
                "You are a self-reflective AI analyzing your own behavior to learn and improve. "
                "Output valid JSON only, no markdown formatting."
            )
            usage_info = None

            try:
                response, tool_call, usage_info, _thinking = provider.chat_with_tools(
                    messages=[{"role": "user", "content": prompt}],
                    tools=[],
                    system_prompt=system_prompt,
                    enable_thinking=False
                )
                if tool_call:
                    response = json.dumps({
                        "is_procedural": False,
                        "knowledge_type": "factual",
                        "insight_summary": "Reflection unexpectedly requested a tool instead of returning an insight."
                    })
            except Exception as e:
                logger.debug(f"Usage-aware reflection call failed, falling back to chat(): {e}")
                response = provider.chat(prompt, system_prompt=system_prompt)

            parsed = self._parse_reflection_output(response)
            if parsed:
                parsed['_reflection_usage'] = usage_info or {}
                parsed['_reflection_provider'] = provider_type
                parsed['_reflection_model'] = model_name

            # Log the reflection response
            get_intel_logger().log_reflection_response(
                exp_id=experience_id or 0,
                response=parsed or {"raw": str(response)[:500]},
                provider=provider_type,
                model=model_name,
                usage_info=usage_info
            )

            return parsed

        except Exception as e:
            logger.error(f"Direct LLM reflection failed: {e}")
            get_intel_logger().log("reflection_error", {"error": str(e)})

        return None

    def _parse_reflection_output(self, output: Any) -> dict[str, Any] | None:
        """Parse reflection output, handling various formats."""
        if isinstance(output, dict):
            return output

        if isinstance(output, str):
            # Try to extract JSON from string
            try:
                # Look for JSON block
                import re
                json_match = re.search(r'```json\s*(.*?)\s*```', output, re.DOTALL)
                if json_match:
                    return json.loads(json_match.group(1))

                # Try direct parse
                return json.loads(output)
            except json.JSONDecodeError:
                pass

        return None

    def _get_experience_raw_data(self, experience: sqlite3.Row | dict[str, Any]) -> dict[str, Any]:
        """Return raw_data as a dict for provenance and reflection metadata."""
        raw_data = _row_value(experience, 'raw_data', '{}')
        parsed = _json_loads_safely(raw_data, {})
        return parsed if isinstance(parsed, dict) else {}

    def _reflection_sequence_required(self, value: Any) -> bool:
        """Parse conservative boolean metadata from LLM reflection output."""
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return bool(value)
        if isinstance(value, str):
            return value.strip().lower() in {'1', 'true', 'yes', 'required'}
        return False

    def _extract_insight_metadata(
        self,
        reflection: dict[str, Any],
        experience: sqlite3.Row | dict[str, Any],
        suppress_preferred_tool: bool = False
    ) -> dict[str, Any]:
        """
        Normalize reflection output into storable insight metadata.

        Tool sequences are advisory evidence. They help audit and future prompt
        shaping, but they do not force routing to execute a fixed workflow.
        """
        confidence = reflection.get('confidence', 0.5)
        try:
            confidence = float(confidence)
        except (TypeError, ValueError):
            confidence = 0.5

        raw_data = redact_sensitive_data(self._get_experience_raw_data(experience))
        context = raw_data.get('context', {}) if isinstance(raw_data.get('context'), dict) else {}
        chat_only_experience = context.get('tool_policy') == 'none'
        workflow_execution = (
            reflection.get('_workflow_execution_context')
            if isinstance(reflection.get('_workflow_execution_context'), dict)
            else (
                context.get('workflow_execution')
                if isinstance(context.get('workflow_execution'), dict)
                else None
            )
        )
        is_workflow_experience = bool(
            workflow_execution
            and workflow_execution.get('is_workflow_interaction')
        )

        preferred_tools: dict[str, float] = {}
        preferred_tool_names = _coerce_string_list(reflection.get('preferred_tool'))
        if suppress_preferred_tool or chat_only_experience:
            preferred_tool_names = []
        if not preferred_tool_names and not suppress_preferred_tool and not chat_only_experience:
            final_tool = _row_value(experience, 'final_tool')
            if final_tool and not is_workflow_experience:
                # TODO: If the reflection also avoided this same tool, reshape the
                # insight instead of creating contradictory prefer/avoid metadata.
                preferred_tool_names = [str(final_tool)]

        preferred_workflow_id = str(
            reflection.get('preferred_workflow_id') or ''
        ).strip()
        if 'workflow' in preferred_tool_names:
            selected_workflow_id = str(
                (workflow_execution or {}).get('selected_workflow_id') or ''
            ).strip()
            valid_completed_run = bool(
                selected_workflow_id
                and workflow_execution.get('run_started')
                and workflow_execution.get('run_completed')
                and not workflow_execution.get('cancelled')
                and workflow_execution.get('outcome_success')
            ) if workflow_execution else False
            if not valid_completed_run:
                preferred_tool_names = [
                    name for name in preferred_tool_names if name != 'workflow'
                ]
                preferred_workflow_id = ''
            elif preferred_workflow_id and preferred_workflow_id != selected_workflow_id:
                # Reflection may only reinforce the recipe evidenced by this run.
                preferred_tool_names = [
                    name for name in preferred_tool_names if name != 'workflow'
                ]
                preferred_workflow_id = ''
            else:
                preferred_workflow_id = selected_workflow_id
        else:
            preferred_workflow_id = ''

        for tool in preferred_tool_names:
            preferred_tools[tool] = confidence

        avoided_tools = _coerce_string_list(reflection.get('avoided_tool'))
        avoided_tools.extend(_coerce_string_list(reflection.get('avoided_tools')))
        avoided_tools = list(dict.fromkeys(avoided_tools))

        preferred_tool_sequence = _coerce_string_list(reflection.get('preferred_tool_sequence'))
        supporting_tools = _coerce_string_list(reflection.get('supporting_tools'))
        if chat_only_experience:
            preferred_workflow_id = ''
            avoided_tools = []
            preferred_tool_sequence = []
            supporting_tools = []
        if is_workflow_experience:
            component_tools = set(
                _coerce_string_list(
                    (workflow_execution or {}).get('component_tools_used')
                )
            )
            preferred_tool_sequence = [
                tool
                for tool in preferred_tool_sequence
                if tool not in component_tools and tool != 'workflow'
            ]
            supporting_tools = [
                tool
                for tool in supporting_tools
                if tool not in component_tools and tool != 'workflow'
            ]
            if preferred_workflow_id:
                # A workflow preference selects one recipe; its internal order
                # must never become a second router-enforced sequence.
                preferred_tool_sequence = []
        trigger_signals = _coerce_string_list(reflection.get('trigger_signals'))

        source_tool_sequence = _coerce_string_list(_row_value(experience, 'tool_sequence'))
        if not source_tool_sequence:
            source_tool_sequence = _coerce_string_list(_row_value(experience, 'tools_used'))

        return {
            'preferred_tools': preferred_tools,
            'preferred_workflow_id': preferred_workflow_id or None,
            'avoided_tools': avoided_tools,
            'preferred_tool_sequence': preferred_tool_sequence,
            'supporting_tools': supporting_tools,
            'sequence_required': (
                False
                if chat_only_experience
                else self._reflection_sequence_required(reflection.get('sequence_required'))
            ),
            'trigger_signals': trigger_signals,
            'primary_intent': str(reflection.get('primary_intent') or '').strip(),
            'source_experience_id': _row_value(experience, 'id'),
            'source_web_conversation_id': context.get('web_conversation_id'),
            'source_query': redact_sensitive_text(_row_value(experience, 'query') or ''),
            'source_tool_sequence': source_tool_sequence,
            'source_reflection_json': json.dumps(redact_sensitive_data(reflection), default=str),
            'confidence': confidence,
            'suppressed_preferred_tool': suppress_preferred_tool or chat_only_experience,
        }

    def _insight_associations_compatible(
        self,
        existing: sqlite3.Row | dict[str, Any],
        metadata: dict[str, Any]
    ) -> bool:
        """
        Similar prose should not merge if it recommends a different tool.

        The evidence table still records every supporting experience, but
        conflicting tool associations deserve separate insight rows so stale
        preferences do not survive under a freshly reinforced description.
        """
        existing_preferred = set(_coerce_string_list(_row_value(existing, 'preferred_tools')))
        new_preferred = set((metadata.get('preferred_tools') or {}).keys())
        if existing_preferred and not new_preferred and metadata.get('suppressed_preferred_tool'):
            return False
        if existing_preferred and new_preferred and existing_preferred != new_preferred:
            return False
        existing_workflow_id = str(
            _row_value(existing, 'preferred_workflow_id') or ''
        ).strip()
        new_workflow_id = str(
            metadata.get('preferred_workflow_id') or ''
        ).strip()
        if existing_workflow_id != new_workflow_id and (
            existing_workflow_id or new_workflow_id
        ):
            return False

        existing_avoided = set(_coerce_string_list(_row_value(existing, 'avoided_tools')))
        new_avoided = set(metadata.get('avoided_tools') or [])
        if existing_avoided and new_avoided and existing_avoided != new_avoided:
            return False

        existing_sequence = _coerce_string_list(_row_value(existing, 'preferred_tool_sequence'))
        new_sequence = metadata.get('preferred_tool_sequence') or []
        if existing_sequence and new_sequence and existing_sequence != new_sequence:
            return False

        return True

    def _merge_json_list_fields(self, existing_value: Any, new_values: list[str]) -> str:
        """Return a JSON list containing the stable union of old and new values."""
        merged = _coerce_string_list(existing_value)
        for value in new_values:
            if value and value not in merged:
                merged.append(value)
        return json.dumps(merged)

    def _record_insight_evidence(
        self,
        cursor: sqlite3.Cursor,
        insight_id: int,
        metadata: dict[str, Any],
        reflection: dict[str, Any],
        action: str,
        confidence_delta: float | None = None,
    ) -> None:
        """Attach an auditable source experience/reflection to an insight."""
        preferred_tool_names = list((metadata.get('preferred_tools') or {}).keys())
        avoided_tools = metadata.get('avoided_tools') or []
        cursor.execute("""
            INSERT INTO insight_evidence (
                insight_id, experience_id, web_conversation_id, query,
                tool_sequence, preferred_tool, preferred_workflow_id, avoided_tool,
                preferred_tool_sequence, supporting_tools, reflection_json,
                confidence, confidence_delta, action
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            insight_id,
            metadata.get('source_experience_id'),
            metadata.get('source_web_conversation_id'),
            metadata.get('source_query'),
            json.dumps(metadata.get('source_tool_sequence') or []),
            preferred_tool_names[0] if preferred_tool_names else None,
            metadata.get('preferred_workflow_id'),
            avoided_tools[0] if avoided_tools else None,
            json.dumps(metadata.get('preferred_tool_sequence') or []),
            json.dumps(metadata.get('supporting_tools') or []),
            json.dumps(redact_sensitive_data(reflection), default=str),
            metadata.get('confidence'),
            confidence_delta,
            action,
        ))

    async def _store_insight(
        self,
        reflection: dict[str, Any],
        experience: sqlite3.Row
    ) -> int:
        """Store a new insight or update existing similar insight.

        PHASE 1 UPGRADES:
        - Filter out factual knowledge (only store procedural)
        - Filter out low generalizability insights
        - Track constraint_type (positive/negative)
        - Track avoided_tools for negative constraints
        """

        intel_log = get_intel_logger()
        reflection = redact_sensitive_data(reflection)

        # PHASE 1: Filter out factual knowledge
        if not reflection.get('is_procedural', True):
            logger.info(f"Skipping factual insight: {reflection.get('insight_summary', '')[:50]}")
            intel_log.log_insight_skipped("factual", reflection.get('insight_summary', ''))
            return 0

        if reflection.get('knowledge_type') == 'factual':
            logger.info("Skipping factual knowledge (belongs in memory_db)")
            intel_log.log_insight_skipped("factual_knowledge_type", reflection.get('insight_summary', ''))
            return 0

        # PHASE 1: Filter out low generalizability
        generalizability = reflection.get('generalizability', 'medium')
        if generalizability == 'low':
            logger.info(f"Skipping low-generalizability insight: {reflection.get('insight_summary', '')[:50]}")
            intel_log.log_insight_skipped("low_generalizability", reflection.get('insight_summary', ''))
            return 0

        insight_text = reflection.get('insight_summary', reflection.get('rule', reflection.get('pattern', '')))
        if not insight_text:
            return 0

        usage_info = reflection.get('_reflection_usage') or {}
        if not isinstance(usage_info, dict):
            usage_info = {}
        reflection_provider = reflection.get('_reflection_provider', '')
        reflection_model = reflection.get('_reflection_model', '')
        reflection_input_tokens = int(usage_info.get('input_tokens') or 0)
        reflection_output_tokens = int(usage_info.get('output_tokens') or 0)
        reflection_total_tokens = int(
            usage_info.get('total_tokens')
            or (reflection_input_tokens + reflection_output_tokens)
            or 0
        )
        reflection_cost_usd = _reflection_cost_from_usage(usage_info)

        # Extract constraint type
        constraint_type = reflection.get('constraint_type', 'positive')

        suppress_preferred_tool = should_suppress_preferred_tool_for_native_search(reflection, experience)
        if suppress_preferred_tool:
            logger.info(
                "Suppressing preferred_tool for native-search-backed insight: %s",
                reflection.get('insight_summary', reflection.get('rule', ''))[:120]
            )
        metadata = self._extract_insight_metadata(
            reflection,
            experience,
            suppress_preferred_tool=suppress_preferred_tool
        )

        # Generate embeddings. Positive workflow lessons use the recipe's
        # bounded semantic metadata so test wording such as "run the previous
        # procedure" cannot become the retrieval pattern.
        insight_embedding = self._get_persistable_embedding(
            insight_text,
            role="similarity",
            namespace=INTELLIGENCE_INSIGHT_NAMESPACE,
        )
        pattern_text = _workflow_semantic_pattern(reflection, metadata)
        pattern_embedding = (
            self._get_persistable_embedding(
                pattern_text,
                role="document",
                namespace=INTELLIGENCE_PATTERN_NAMESPACE,
                title="Insight applicability",
            )
            if pattern_text else None
        )
        trigger_concept = reflection.get('trigger_concept', '')

        # Check for similar existing insights
        similar = await self._find_similar_insights(insight_embedding, threshold=0.85)
        compatible_similar = [
            row for row in similar
            if self._insight_associations_compatible(row, metadata)
        ]

        cursor = self.conn.cursor()

        if compatible_similar:
            # Update existing insight (blend, don't replace)
            existing = compatible_similar[0]
            new_confidence = self._blend_confidence(
                existing['confidence'],
                metadata['confidence'],
                existing['evidence_count']
            )
            confidence_delta = new_confidence - existing['confidence']

            cursor.execute("""
                UPDATE insights SET
                    description = CASE
                        WHEN ? IS NOT NULL THEN ?
                        ELSE description
                    END,
                    applies_to_pattern = CASE
                        WHEN ? IS NOT NULL THEN ?
                        ELSE applies_to_pattern
                    END,
                    pattern_embedding = CASE
                        WHEN ? IS NOT NULL THEN ?
                        ELSE pattern_embedding
                    END,
                    trigger_concept = CASE
                        WHEN ? IS NOT NULL THEN ?
                        ELSE trigger_concept
                    END,
                    confidence = ?,
                    strength = ?,
                    evidence_count = evidence_count + 1,
                    updated_at = CURRENT_TIMESTAMP,
                    reasoning = ?,
                    generalizability = ?,
                    preferred_tool_sequence = CASE
                        WHEN preferred_tool_sequence IS NULL OR preferred_tool_sequence = ''
                        THEN ?
                        ELSE preferred_tool_sequence
                    END,
                    preferred_workflow_id = COALESCE(
                        NULLIF(preferred_workflow_id, ''),
                        ?
                    ),
                    supporting_tools = ?,
                    trigger_signals = ?,
                    primary_intent = COALESCE(NULLIF(primary_intent, ''), ?),
                    source_experience_id = COALESCE(source_experience_id, ?),
                    source_web_conversation_id = COALESCE(NULLIF(source_web_conversation_id, ''), ?),
                    source_query = COALESCE(NULLIF(source_query, ''), ?),
                    source_tool_sequence = COALESCE(NULLIF(source_tool_sequence, ''), ?),
                    source_reflection_json = COALESCE(NULLIF(source_reflection_json, ''), ?),
                    sequence_required = CASE
                        WHEN COALESCE(sequence_required, 0) = 1 OR ? = 1
                        THEN 1
                        ELSE 0
                    END,
                    reflection_provider = ?,
                    reflection_model = ?,
                    reflection_input_tokens = COALESCE(reflection_input_tokens, 0) + ?,
                    reflection_output_tokens = COALESCE(reflection_output_tokens, 0) + ?,
                    reflection_total_tokens = COALESCE(reflection_total_tokens, 0) + ?,
                    reflection_cost_usd = CASE
                        WHEN reflection_cost_usd IS NULL OR ? IS NULL THEN NULL
                        ELSE reflection_cost_usd + ?
                    END
                WHERE id = ?
            """, (
                metadata['preferred_workflow_id'],
                insight_text,
                metadata['preferred_workflow_id'] if pattern_text else None,
                pattern_text,
                metadata['preferred_workflow_id'] if pattern_embedding is not None else None,
                self._serialize_embedding(pattern_embedding),
                metadata['preferred_workflow_id'] if trigger_concept else None,
                trigger_concept,
                new_confidence,
                min(1.0, existing['strength'] + 0.1),
                reflection.get('why_or_why_not', ''),
                generalizability,
                json.dumps(metadata['preferred_tool_sequence']),
                metadata['preferred_workflow_id'],
                self._merge_json_list_fields(existing['supporting_tools'], metadata['supporting_tools']),
                self._merge_json_list_fields(existing['trigger_signals'], metadata['trigger_signals']),
                metadata['primary_intent'],
                metadata['source_experience_id'],
                metadata['source_web_conversation_id'],
                metadata['source_query'],
                json.dumps(metadata['source_tool_sequence']),
                json.dumps(metadata['source_reflection_json']),
                1 if metadata['sequence_required'] else 0,
                reflection_provider,
                reflection_model,
                reflection_input_tokens,
                reflection_output_tokens,
                reflection_total_tokens,
                reflection_cost_usd,
                reflection_cost_usd,
                existing['id']
            ))

            self._record_insight_evidence(
                cursor,
                insight_id=existing['id'],
                metadata=metadata,
                reflection=reflection,
                action='merged',
                confidence_delta=confidence_delta
            )

            self.conn.commit()
            logger.info(f"Updated existing insight #{existing['id']} (confidence: {new_confidence:.2f})")

            # Log insight update
            get_intel_logger().log_insight_updated(
                insight_id=existing['id'],
                old_confidence=existing['confidence'],
                new_confidence=new_confidence
            )

            return existing['id']

        else:
            # Create new insight with PHASE 1 schema
            if similar:
                logger.info(
                    "Creating separate insight for similar text with different tool association: %s",
                    insight_text[:120]
                )

            insight_type = reflection.get('insight_type', 'tool_preference')
            reasoning = reflection.get('why_or_why_not', '')

            cursor.execute("""
                INSERT INTO insights (
                    insight_type, description, insight_embedding,
                    constraint_type, trigger_concept,
                    applies_to_pattern, pattern_embedding,
                    preferred_tools, preferred_workflow_id,
                    preferred_tool_sequence, supporting_tools,
                    sequence_required, avoided_tools, trigger_signals, primary_intent,
                    generalizability, reasoning,
                    reflection_provider, reflection_model,
                    reflection_input_tokens, reflection_output_tokens,
                    reflection_total_tokens, reflection_cost_usd,
                    confidence, evidence_count,
                    source_experience_id, source_web_conversation_id,
                    source_query, source_tool_sequence, source_reflection_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                insight_type,
                insight_text,
                self._serialize_embedding(insight_embedding),
                constraint_type,
                trigger_concept,
                pattern_text,
                self._serialize_embedding(pattern_embedding),
                json.dumps(metadata['preferred_tools']),
                metadata['preferred_workflow_id'],
                json.dumps(metadata['preferred_tool_sequence']),
                json.dumps(metadata['supporting_tools']),
                1 if metadata['sequence_required'] else 0,
                json.dumps(metadata['avoided_tools']),
                json.dumps(metadata['trigger_signals']),
                metadata['primary_intent'],
                generalizability,
                reasoning,
                reflection_provider,
                reflection_model,
                reflection_input_tokens,
                reflection_output_tokens,
                reflection_total_tokens,
                reflection_cost_usd,
                metadata['confidence'],
                1,
                metadata['source_experience_id'],
                metadata['source_web_conversation_id'],
                metadata['source_query'],
                json.dumps(metadata['source_tool_sequence']),
                metadata['source_reflection_json'],
            ))

            insight_id = cursor.lastrowid
            self._record_insight_evidence(
                cursor,
                insight_id=insight_id,
                metadata=metadata,
                reflection=reflection,
                action='created',
                confidence_delta=None
            )
            self.conn.commit()
            logger.info(f"Created new {constraint_type} insight #{insight_id}: {insight_text[:50]}...")

            # Log insight creation
            get_intel_logger().log_insight_created(
                insight_id=insight_id,
                constraint_type=constraint_type,
                description=insight_text,
                confidence=reflection.get('confidence', 0.5)
            )

            return insight_id

    def _blend_confidence(
        self,
        old_confidence: float,
        new_confidence: float,
        evidence_count: int
    ) -> float:
        """
        Blend old and new confidence with exponential moving average.
        More evidence = more stable (harder to shift).
        """
        # Higher evidence count = lower learning rate (more stable)
        effective_rate = self.learning_rate / (1 + 0.1 * evidence_count)

        return (1 - effective_rate) * old_confidence + effective_rate * new_confidence

    async def _find_similar_insights(
        self,
        embedding: np.ndarray,
        threshold: float = 0.8
    ) -> list[dict[str, Any]]:
        """Find insights similar to the given embedding."""
        if embedding is None:
            return []

        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM insights WHERE insight_embedding IS NOT NULL")

        similar = []
        for row in cursor.fetchall():
            stored_embedding = self._deserialize_embedding(row['insight_embedding'])
            if stored_embedding is not None:
                similarity = self._cosine_similarity(embedding, stored_embedding)
                if similarity >= threshold:
                    similar.append({
                        **dict(row),
                        'similarity': similarity
                    })

        # Sort by similarity
        similar.sort(key=lambda x: x['similarity'], reverse=True)
        return similar

    # ============================================
    # QUERY INTELLIGENCE
    # ============================================

    async def get_relevant_insights(
        self,
        query: str,
        top_k: int = 5
    ) -> list[dict[str, Any]]:
        """
        Get insights relevant to a query.

        This is called BEFORE routing to bias tool selection
        based on learned patterns.

        PHASE 1 UPGRADES:
        - Returns constraint_type (positive/negative)
        - Returns avoided_tools for negative constraints
        - Filters out low-generalizability insights
        """
        query_embedding = self._get_embedding(
            query,
            role="query",
            namespace=INTELLIGENCE_PATTERN_NAMESPACE,
        )
        if query_embedding is None:
            return []

        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT * FROM insights
            WHERE confidence >= ?
            AND pattern_embedding IS NOT NULL
            AND (generalizability IS NULL OR generalizability != 'low')
        """, (self.min_confidence,))

        relevant = []
        for row in cursor.fetchall():
            pattern_embedding = self._deserialize_embedding(row['pattern_embedding'])
            if pattern_embedding is not None:
                similarity = self._cosine_similarity(query_embedding, pattern_embedding)

                # Weight by confidence and similarity
                relevance = similarity * row['confidence']

                if relevance > self.relevance_threshold:
                    constraint_type = str(
                        (
                            row['constraint_type']
                            if 'constraint_type' in row.keys()
                            else 'positive'
                        ) or 'positive'
                    ).strip().lower()
                    trigger_signals = _coerce_string_list(
                        _json_loads_safely(row['trigger_signals'], [])
                        if 'trigger_signals' in row.keys()
                        else []
                    )
                    matched_trigger_signals = _matching_trigger_signals(
                        query,
                        trigger_signals,
                    )
                    if constraint_type == 'negative' and not trigger_signals:
                        logger.debug(
                            "Skipping unscoped legacy negative insight #%s",
                            row['id'],
                        )
                        continue
                    if constraint_type == 'negative' and not matched_trigger_signals:
                        logger.debug(
                            "Skipping negative insight #%s: current request lacks its trigger signals",
                            row['id'],
                        )
                        continue

                    insight_data = {
                        'id': row['id'],
                        'insight': row['description'],
                        'applies_to': row['applies_to_pattern'],
                        'preferred_tools': _json_loads_safely(row['preferred_tools'], {}),
                        'preferred_workflow_id': (
                            row['preferred_workflow_id']
                            if 'preferred_workflow_id' in row.keys()
                            else None
                        ),
                        'confidence': row['confidence'],
                        'relevance': relevance,
                        'evidence_count': row['evidence_count'],
                        'times_applied': row['times_applied'],
                        'times_helpful': row['times_helpful'],
                        'times_failed': row['times_failed'],
                        'consecutive_failures': row['consecutive_failures'],
                        # PHASE 1: New fields
                        'constraint_type': constraint_type,
                        'avoided_tools': _json_loads_safely(row['avoided_tools'], []) if 'avoided_tools' in row.keys() else [],
                        'trigger_concept': row['trigger_concept'] if 'trigger_concept' in row.keys() else '',
                        'trigger_signals': trigger_signals,
                        'matched_trigger_signals': matched_trigger_signals,
                        'primary_intent': row['primary_intent'] if 'primary_intent' in row.keys() else '',
                        'preferred_tool_sequence': _json_loads_safely(row['preferred_tool_sequence'], []) if 'preferred_tool_sequence' in row.keys() else [],
                        'supporting_tools': _json_loads_safely(row['supporting_tools'], []) if 'supporting_tools' in row.keys() else [],
                        'sequence_required': bool(row['sequence_required']) if 'sequence_required' in row.keys() else False,
                        'source_experience_id': row['source_experience_id'] if 'source_experience_id' in row.keys() else None,
                        'source_web_conversation_id': row['source_web_conversation_id'] if 'source_web_conversation_id' in row.keys() else None,
                        'reasoning': row['reasoning'] if 'reasoning' in row.keys() else ''
                    }
                    relevant.append(insight_data)

        # Sort by relevance
        relevant.sort(key=lambda x: x['relevance'], reverse=True)
        return _select_top_relevant_insights(relevant, top_k)

    async def get_tool_biases(self, query: str) -> dict[str, float]:
        """
        Get tool preference biases based on learned insights.

        Returns dict of tool_name -> bias score
        Positive bias = prefer this tool
        Negative bias = avoid this tool

        PHASE 1 UPGRADES:
        - Positive constraints add positive bias
        - Negative constraints add negative bias (penalize tools)
        - Avoided tools get explicit negative bias
        """
        insights = await self.get_relevant_insights(query)

        biases = {}
        for insight in insights:
            constraint_type = insight.get('constraint_type', 'positive')

            # Handle preferred tools (positive bias)
            for tool, preference in insight['preferred_tools'].items():
                # Weight by relevance
                weighted_preference = preference * insight['relevance']

                if constraint_type == 'positive':
                    biases[tool] = biases.get(tool, 0) + weighted_preference
                else:
                    # Negative constraint's "preferred" tool is actually what to use INSTEAD
                    biases[tool] = biases.get(tool, 0) + (weighted_preference * 0.5)  # Weaker positive

            # Handle avoided tools (negative bias) - PHASE 1
            for tool in insight.get('avoided_tools', []):
                # Strong negative bias weighted by relevance, confidence, and negative_weight
                # negative_weight > 1.0 makes negative constraints stronger than positive
                negative_bias = -self.negative_weight * insight['relevance'] * insight['confidence']
                biases[tool] = biases.get(tool, 0) + negative_bias

        return biases

    # ============================================
    # INSIGHT USAGE TRACKING (PHASE 1: Decay)
    # ============================================

    async def record_insight_usage(
        self,
        insight_id: int,
        was_helpful: bool,
        outcome: str = None
    ):
        """
        Record when an insight is used and whether it helped.

        This enables:
        - Confidence decay for bad insights
        - Strengthening of good insights
        - Pruning of consistently failing insights
        """
        cursor = self.conn.cursor()

        # Get current insight state
        cursor.execute("SELECT * FROM insights WHERE id = ?", (insight_id,))
        insight = cursor.fetchone()
        if not insight:
            return

        times_applied = (insight['times_applied'] or 0) + 1
        times_helpful = (insight['times_helpful'] or 0) + (1 if was_helpful else 0)
        times_failed = (insight['times_failed'] or 0) + (0 if was_helpful else 1)

        # Track consecutive failures for rapid decay
        if was_helpful:
            consecutive_failures = 0
        else:
            consecutive_failures = (insight['consecutive_failures'] or 0) + 1

        # Calculate new confidence with decay
        old_confidence = insight['confidence']
        if was_helpful:
            # Slight boost for helpful usage
            new_confidence = min(1.0, old_confidence + 0.05)
        else:
            # Decay based on consecutive failures
            decay_factor = 0.1 * consecutive_failures  # Faster decay with repeated failures
            new_confidence = max(0.1, old_confidence - decay_factor)

        cursor.execute("""
            UPDATE insights SET
                times_applied = ?,
                times_helpful = ?,
                times_failed = ?,
                consecutive_failures = ?,
                confidence = ?,
                last_applied = CURRENT_TIMESTAMP,
                last_outcome = ?
            WHERE id = ?
        """, (
            times_applied,
            times_helpful,
            times_failed,
            consecutive_failures,
            new_confidence,
            outcome or ('success' if was_helpful else 'failure'),
            insight_id
        ))

        self.conn.commit()

        logger.info(
            f"Insight #{insight_id} {'helped' if was_helpful else 'failed'}: "
            f"confidence {old_confidence:.2f} → {new_confidence:.2f}"
        )

    async def prune_low_confidence_insights(self, threshold: float = 0.2) -> int:
        """
        Remove insights that have decayed below threshold.

        The "Gardener" process - run periodically to clean up bad learnings.
        """
        cursor = self.conn.cursor()

        # Find insights to prune
        cursor.execute("""
            SELECT id, description, confidence, times_applied, times_failed
            FROM insights
            WHERE confidence < ?
        """, (threshold,))

        to_prune = cursor.fetchall()

        if not to_prune:
            return 0

        # Log what we're removing
        for row in to_prune:
            logger.info(
                f"Pruning insight #{row['id']}: '{row['description'][:50]}...' "
                f"(confidence: {row['confidence']:.2f}, failed: {row['times_failed']}x)"
            )

        # Delete low-confidence insights
        cursor.execute("DELETE FROM insights WHERE confidence < ?", (threshold,))
        self.conn.commit()

        return len(to_prune)

    # ============================================
    # META-COGNITION
    # ============================================

    async def evaluate_learning_quality(self) -> dict[str, Any]:
        """
        Meta-cognition: evaluate how well the learning process is working.
        """
        cursor = self.conn.cursor()

        # Get recent insights
        cursor.execute("""
            SELECT * FROM insights
            ORDER BY created_at DESC
            LIMIT 20
        """)
        recent_insights = cursor.fetchall()

        # Analyze patterns
        analysis = {
            'total_insights': len(recent_insights),
            'avg_confidence': 0,
            'avg_evidence': 0,
            'potential_issues': []
        }

        if recent_insights:
            confidences = [r['confidence'] for r in recent_insights]
            evidences = [r['evidence_count'] for r in recent_insights]

            analysis['avg_confidence'] = sum(confidences) / len(confidences)
            analysis['avg_evidence'] = sum(evidences) / len(evidences)

            # Check for potential issues
            if analysis['avg_confidence'] < 0.4:
                analysis['potential_issues'].append(
                    "Low average confidence - insights may not be reliable"
                )

            if analysis['avg_evidence'] < 2:
                analysis['potential_issues'].append(
                    "Low evidence counts - need more experience to validate insights"
                )

            # Check for over-generalization (too few patterns covering too much)
            cursor.execute("SELECT COUNT(DISTINCT applies_to_pattern) FROM insights")
            unique_patterns = cursor.fetchone()[0]

            if unique_patterns < 3 and len(recent_insights) > 10:
                analysis['potential_issues'].append(
                    "Possible over-generalization - few patterns covering many insights"
                )

        return analysis

    async def process_reflection_queue(self, batch_size: int = 5) -> int:
        """Process pending reflections in the queue."""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT experience_id FROM reflection_queue
            WHERE processed = 0
            ORDER BY priority DESC
            LIMIT ?
        """, (batch_size,))

        pending = cursor.fetchall()
        processed = 0

        for row in pending:
            result = await self.reflect_on_experience(row['experience_id'])
            if result:
                processed += 1

        return processed

    # ============================================
    # MAINTENANCE JOBS (Decay, Anomaly, Meta-Cognition)
    # ============================================

    def _create_maintenance_backup(self, job_type: str) -> str:
        """Create and verify a SQLite-consistent backup before maintenance writes."""
        if self.conn.in_transaction:
            raise RuntimeError("Cannot back up Intelligence DB with a transaction already open")

        db_path = Path(self.db_path).resolve()
        project_data = Path(__file__).parent.parent.resolve() / "data"
        try:
            db_path.relative_to(project_data)
            backup_dir = project_data / "backups"
        except ValueError:
            # Tests and explicitly supplied operator databases stay self-contained.
            backup_dir = db_path.parent / "backups"

        backup_dir.mkdir(parents=True, exist_ok=True)
        timestamp = now_utc().strftime("%Y%m%d_%H%M%S_%f")
        safe_job_type = re.sub(r"[^a-z0-9_-]+", "-", job_type.lower()).strip("-")
        backup_path = backup_dir / f"{db_path.name}.pre_{safe_job_type}_{timestamp}"

        backup_fd = os.open(
            backup_path,
            os.O_CREAT | os.O_EXCL | os.O_WRONLY,
            0o600,
        )
        os.close(backup_fd)
        source_conn = sqlite3.connect(f"{db_path.as_uri()}?mode=ro", uri=True)
        backup_conn = sqlite3.connect(str(backup_path))
        try:
            source_conn.backup(backup_conn)
            backup_conn.commit()
            quick_check = backup_conn.execute("PRAGMA quick_check").fetchone()[0]
            if quick_check != "ok":
                raise RuntimeError(
                    f"Maintenance backup failed integrity check: {quick_check}"
                )
        finally:
            backup_conn.close()
            source_conn.close()

        os.chmod(backup_path, 0o600)
        return str(backup_path)

    def _open_maintenance_writer(self) -> sqlite3.Connection:
        """Open a dedicated connection and reserve the SQLite writer slot."""
        if self.conn.in_transaction:
            raise RuntimeError(
                "Cannot start Intelligence maintenance with pending database writes"
            )

        maintenance_conn = sqlite3.connect(
            self.db_path,
            timeout=30,
            check_same_thread=False,
        )
        maintenance_conn.row_factory = sqlite3.Row
        try:
            maintenance_conn.execute("BEGIN IMMEDIATE")
        except Exception:
            maintenance_conn.close()
            raise
        return maintenance_conn

    def _decay_assessment(
        self,
        insight: sqlite3.Row,
        *,
        now: datetime,
        last_decay_run: datetime | None,
    ) -> dict[str, Any]:
        """Classify one insight and calculate selective, bounded decay."""
        old_confidence = float(insight['confidence'] or 0.0)
        constraint_type = str(insight['constraint_type'] or 'positive').strip().lower()
        evidence_count = int(insight['evidence_count'] or 0)
        times_applied = int(insight['times_applied'] or 0)
        times_helpful = int(insight['times_helpful'] or 0)
        times_failed = int(insight['times_failed'] or 0)
        consecutive_failures = int(insight['consecutive_failures'] or 0)
        success_rate = (
            times_helpful / times_applied
            if times_applied > 0
            else None
        )

        trigger_signals = _coerce_string_list(
            _json_loads_safely(insight['trigger_signals'], [])
        )
        has_primary_intent = bool(str(insight['primary_intent'] or '').strip())
        has_source = bool(
            insight['source_experience_id']
            or str(insight['source_web_conversation_id'] or '').strip()
        )
        legacy = not trigger_signals and not has_primary_intent and not has_source
        unscoped_negative = constraint_type == 'negative' and not trigger_signals

        activity_candidates = [
            self._parse_timestamp(insight['last_applied']),
            self._parse_timestamp(insight['updated_at']),
            self._parse_timestamp(insight['latest_evidence_at']),
            self._parse_timestamp(insight['created_at']),
        ]
        last_activity = max((ts for ts in activity_candidates if ts), default=now)
        days_since = max(0, (now - last_activity).days)

        max_catchup_days = max(1, get_int('INTELLIGENCE_DECAY_MAX_CATCHUP_DAYS', 30))
        effective_decay_days = min(days_since, max_catchup_days)
        if last_decay_run:
            days_since_decay_run = max(0, (now - last_decay_run).days)
            effective_decay_days = min(effective_decay_days, days_since_decay_run)

        prune_threshold = max(
            0.0,
            min(1.0, get_float('INTELLIGENCE_PRUNE_CONFIDENCE', 0.15)),
        )
        legacy_prune_days = max(
            1,
            get_int('INTELLIGENCE_LEGACY_NEGATIVE_PRUNE_DAYS', 120),
        )
        direct_legacy_prune = (
            unscoped_negative
            and legacy
            and evidence_count <= 1
            and days_since >= legacy_prune_days
        )

        if old_confidence < prune_threshold:
            return {
                'old_confidence': old_confidence,
                'new_confidence': old_confidence,
                'days_since': days_since,
                'effective_decay_days': effective_decay_days,
                'policy': 'below_prune_threshold',
                'prune': True,
                'prune_reason': 'below_threshold',
            }

        if direct_legacy_prune:
            return {
                'old_confidence': old_confidence,
                'new_confidence': old_confidence,
                'days_since': days_since,
                'effective_decay_days': effective_decay_days,
                'policy': 'legacy_unscoped_negative',
                'prune': True,
                'prune_reason': 'legacy_unscoped_negative',
            }

        grace_days = max(0, get_int('INTELLIGENCE_DECAY_GRACE_DAYS', 30))
        proven = (
            consecutive_failures == 0
            and not unscoped_negative
            and (
                evidence_count >= 2
                or (
                    times_applied >= 2
                    and success_rate is not None
                    and (
                        success_rate == 1.0
                        or (times_applied >= 3 and success_rate >= 0.75)
                    )
                )
            )
        )

        new_confidence = old_confidence
        if days_since <= grace_days or effective_decay_days <= 0:
            policy = 'recent'
        elif proven:
            # Useful evidence protects a strategy. Real outcomes still adjust
            # confidence immediately in record_insight_usage().
            policy = 'proven'
        else:
            base_retention = max(0.5, min(0.999, float(self.decay_rate)))
            failing = (
                consecutive_failures > 0
                or (
                    times_applied >= 3
                    and times_failed > times_helpful
                )
            )
            if failing:
                policy = 'failing'
                weekly_retention = max(0.5, base_retention - 0.05)
            elif unscoped_negative:
                policy = 'unscoped_negative'
                weekly_retention = max(0.5, base_retention - 0.10)
            elif old_confidence < self.min_confidence:
                policy = 'low_confidence'
                weekly_retention = max(0.5, base_retention - 0.03)
            elif legacy:
                policy = 'legacy'
                weekly_retention = base_retention
            elif evidence_count <= 1 and times_applied == 0:
                policy = 'unproven'
                weekly_retention = min(0.995, base_retention + 0.03)
            else:
                policy = 'ordinary'
                weekly_retention = min(0.995, base_retention + 0.04)

            new_confidence = old_confidence * (
                weekly_retention ** (effective_decay_days / 7)
            )

        return {
            'old_confidence': old_confidence,
            'new_confidence': max(0.0, min(1.0, new_confidence)),
            'days_since': days_since,
            'effective_decay_days': effective_decay_days,
            'policy': policy,
            'prune': new_confidence < prune_threshold,
            'prune_reason': 'below_threshold',
        }

    async def run_decay_job(
        self,
        force: bool = False,
        dry_run: bool = False,
        *,
        create_backup: bool = True,
    ) -> dict[str, Any]:
        """
        Selectively retire weak Intelligence while preserving proven strategies.

        Age alone never lowers a proven insight. Weak, failing, legacy, and
        unscoped negative insights decay at different bounded rates. Old
        one-evidence negative rules without modern trigger metadata are pruned
        because they cannot be applied safely.

        Args:
            force: If True, bypass the minimum interval check
            dry_run: If True, calculate changes without writing to the database

        Returns:
            Stats about the decay job run
        """
        if dry_run:
            return self._run_decay_job_with_connection(
                self.conn,
                force=force,
                dry_run=True,
                create_backup=False,
            )

        # Use a dedicated writer connection. BEGIN IMMEDIATE prevents any
        # learning writer from slipping between the verified snapshot and the
        # maintenance changes, while readers may continue normally.
        maintenance_conn = self._open_maintenance_writer()
        try:
            return self._run_decay_job_with_connection(
                maintenance_conn,
                force=force,
                dry_run=False,
                create_backup=create_backup,
            )
        except Exception:
            maintenance_conn.rollback()
            raise
        finally:
            if maintenance_conn.in_transaction:
                maintenance_conn.rollback()
            maintenance_conn.close()

    def _run_decay_job_with_connection(
        self,
        active_conn: sqlite3.Connection,
        *,
        force: bool,
        dry_run: bool,
        create_backup: bool,
    ) -> dict[str, Any]:
        """Plan and optionally apply decay using one stable database snapshot."""
        cursor = active_conn.cursor()

        # Check if decay was already run recently (prevent double-decay)
        min_interval_days = get_int('INTELLIGENCE_DECAY_INTERVAL_DAYS', 30)

        cursor.execute("""
            SELECT MAX(timestamp) as last_run
            FROM meta_knowledge
            WHERE meta_type = 'decay_job_run'
        """)
        row = cursor.fetchone()
        last_decay_run = None

        if row and row['last_run'] and not force:
            last_decay_run = self._parse_timestamp(row['last_run'])
            if not last_decay_run:
                raise RuntimeError(
                    f"Invalid decay timestamp in meta_knowledge: {row['last_run']}"
                )
            days_since_run = max(0, (now_utc().replace(tzinfo=None) - last_decay_run).days)

            if days_since_run < min_interval_days:
                return {
                    'status': 'skipped',
                    'reason': f'Decay job already ran {days_since_run} days ago (minimum interval: {min_interval_days} days)',
                    'last_run': row['last_run'],
                    'next_eligible': (last_decay_run + timedelta(days=min_interval_days)).isoformat()
                }
        elif row and row['last_run']:
            last_decay_run = self._parse_timestamp(row['last_run'])

        # Include every confidence tier so already-inactive junk can be pruned.
        cursor.execute("""
            SELECT id, description, constraint_type, confidence, evidence_count,
                   times_applied, times_helpful, times_failed,
                   consecutive_failures, last_applied, created_at, updated_at,
                   trigger_signals, primary_intent, source_experience_id,
                   source_web_conversation_id,
                   (
                       SELECT MAX(e.created_at)
                       FROM insight_evidence e
                       WHERE e.insight_id = insights.id
                   ) AS latest_evidence_at
            FROM insights
        """)

        insights = cursor.fetchall()
        stats = {
            'status': 'dry_run' if dry_run else 'ok',
            'dry_run': dry_run,
            'total_checked': len(insights),
            'decayed': 0,
            'unchanged': 0,
            'protected': 0,
            'pruned': 0,
            'policy_counts': {},
            'prune_reasons': {},
            'max_catchup_days': max(
                1,
                get_int('INTELLIGENCE_DECAY_MAX_CATCHUP_DAYS', 30),
            ),
            'grace_days': max(0, get_int('INTELLIGENCE_DECAY_GRACE_DAYS', 30)),
            'last_run': row['last_run'] if row else None,
            'backup_path': None,
        }

        now = now_utc().replace(tzinfo=None)
        decisions = []
        confidence_before = 0.0
        confidence_after_survivors = 0.0
        survivor_count = 0
        for insight in insights:
            decision = self._decay_assessment(
                insight,
                now=now,
                last_decay_run=last_decay_run,
            )
            decisions.append((insight, decision))
            policy = decision['policy']
            stats['policy_counts'][policy] = stats['policy_counts'].get(policy, 0) + 1
            confidence_before += decision['old_confidence']

            if decision['prune']:
                stats['pruned'] += 1
                prune_reason = decision['prune_reason']
                stats['prune_reasons'][prune_reason] = (
                    stats['prune_reasons'].get(prune_reason, 0) + 1
                )
                continue

            survivor_count += 1
            confidence_after_survivors += decision['new_confidence']
            if decision['new_confidence'] < decision['old_confidence'] - 1e-9:
                stats['decayed'] += 1
            else:
                stats['unchanged'] += 1
                if policy in {'proven', 'recent'}:
                    stats['protected'] += 1

        stats['avg_confidence_before'] = round(
            confidence_before / len(insights), 4,
        ) if insights else 0.0
        stats['avg_confidence_after_survivors'] = round(
            confidence_after_survivors / survivor_count,
            4,
        ) if survivor_count else 0.0

        if not dry_run:
            if create_backup:
                stats['backup_path'] = self._create_maintenance_backup('decay')

            intel_log = get_intel_logger()
            applied_logs = []
            pruned_logs = []
            try:
                for insight, decision in decisions:
                    if decision['prune']:
                        cursor.execute(
                            "DELETE FROM insight_evidence WHERE insight_id = ?",
                            (insight['id'],),
                        )
                        cursor.execute("DELETE FROM insights WHERE id = ?", (insight['id'],))
                        pruned_logs.append((insight, decision))
                    elif decision['new_confidence'] < decision['old_confidence'] - 1e-9:
                        cursor.execute(
                            "UPDATE insights SET confidence = ? WHERE id = ?",
                            (decision['new_confidence'], insight['id']),
                        )
                        applied_logs.append((insight, decision))

                cursor.execute("""
                    INSERT INTO meta_knowledge (
                        meta_type, description, observation, conclusion,
                        action_taken, confidence
                    ) VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    'decay_job_run',
                    'Selective decay maintenance executed',
                    f"Checked {stats['total_checked']} insights; protected {stats['protected']}",
                    f"Decayed: {stats['decayed']}, Pruned: {stats['pruned']}",
                    'selective_decay_applied',
                    1.0,
                ))
                active_conn.commit()
            except Exception:
                active_conn.rollback()
                raise

            for insight, decision in applied_logs:
                intel_log.log_decay_applied(
                    insight['id'],
                    decision['old_confidence'],
                    decision['new_confidence'],
                    decision['days_since'],
                    (
                        f"{decision['policy']}_decay_"
                        f"{decision['effective_decay_days']}d"
                    ),
                )
            for insight, decision in pruned_logs:
                intel_log.log_insight_pruned(
                    insight['id'],
                    insight['description'],
                    decision['prune_reason'],
                    decision['new_confidence'],
                )
            intel_log.log_maintenance_run('decay_job', stats)
        return stats

    async def run_anomaly_detection(self) -> dict[str, Any]:
        """
        Detect anomalous experiences that might indicate issues.

        Uses INTELLIGENCE_ANOMALY_THRESHOLD from config.
        Flags experiences that deviate significantly from norms.

        Returns:
            Stats and list of detected anomalies
        """
        intel_log = get_intel_logger()
        cursor = self.conn.cursor()

        # Get baseline statistics
        cursor.execute("""
            SELECT
                AVG(turns_taken) as avg_turns,
                AVG(CASE WHEN outcome_success THEN 1 ELSE 0 END) as success_rate
            FROM experiences
            WHERE timestamp > datetime('now', '-7 days')
        """)
        baseline = cursor.fetchone()

        if not baseline or baseline['avg_turns'] is None:
            return {'status': 'insufficient_data', 'anomalies': []}

        avg_turns = baseline['avg_turns']

        # Calculate standard deviation for turns
        cursor.execute("""
            SELECT AVG((turns_taken - ?) * (turns_taken - ?)) as variance
            FROM experiences
            WHERE timestamp > datetime('now', '-7 days')
        """, (avg_turns, avg_turns))
        variance = cursor.fetchone()['variance'] or 1
        std_dev = variance ** 0.5

        anomalies = []
        stats = {
            'baseline_avg_turns': round(avg_turns, 2),
            'baseline_std_dev': round(std_dev, 2),
            'anomalies_found': 0
        }

        # Find anomalous experiences (recent only)
        cursor.execute("""
            SELECT id, query, turns_taken, outcome_success, tools_used
            FROM experiences
            WHERE timestamp > datetime('now', '-1 day')
        """)

        for exp in cursor.fetchall():
            anomaly_reasons = []

            # Check for high turn count
            if std_dev > 0:
                z_score = (exp['turns_taken'] - avg_turns) / std_dev
                if abs(z_score) > self.anomaly_threshold:
                    anomaly_reasons.append({
                        'type': 'high_turns',
                        'turns': exp['turns_taken'],
                        'z_score': round(z_score, 2),
                        'threshold': self.anomaly_threshold
                    })

            # Check for failure with many tools
            if not exp['outcome_success'] and exp['turns_taken'] > 3:
                anomaly_reasons.append({
                    'type': 'failed_multi_turn',
                    'turns': exp['turns_taken']
                })

            if anomaly_reasons:
                query_preview = exp['query'][:100]
                anomaly = {
                    'experience_id': exp['id'],
                    'query': query_preview,
                    'query_truncated': len(exp['query']) > len(query_preview),
                    'reasons': anomaly_reasons
                }
                anomalies.append(anomaly)

                intel_log.log_anomaly_detected(
                    exp['id'],
                    anomaly_reasons[0]['type'],
                    {'query': query_preview, 'reasons': anomaly_reasons}
                )

        stats['anomalies_found'] = len(anomalies)
        stats['anomalies'] = anomalies[:10]  # Limit for stats

        intel_log.log_maintenance_run('anomaly_detection', stats)
        return stats

    async def run_meta_cognition(
        self,
        *,
        create_backup: bool = True,
    ) -> dict[str, Any]:
        """Run meta-cognition with a recoverable pre-write snapshot."""
        backup_path = (
            self._create_maintenance_backup('meta-cognition')
            if create_backup
            else None
        )
        try:
            stats = await self._run_meta_cognition_impl()
        except Exception:
            self.conn.rollback()
            raise
        stats['backup_path'] = backup_path
        return stats

    async def _run_meta_cognition_impl(self) -> dict[str, Any]:
        """
        Higher-level reflection on the learning process itself.

        Detects:
        - Blind spots (repeated failures in certain areas)
        - Over-generalization (insights applied too broadly)
        - Learning quality issues

        Populates meta_knowledge table with findings.

        Returns:
            Findings and actions taken
        """
        intel_log = get_intel_logger()
        cursor = self.conn.cursor()

        findings = []

        # ============================================
        # 1. DETECT BLIND SPOTS
        # Areas where we consistently fail
        # ============================================
        cursor.execute("""
            SELECT
                final_tool,
                COUNT(*) as total,
                SUM(CASE WHEN outcome_success = 0 THEN 1 ELSE 0 END) as failures,
                ROUND(100.0 * SUM(CASE WHEN outcome_success = 0 THEN 1 ELSE 0 END) / COUNT(*), 1) as failure_rate
            FROM experiences
            WHERE timestamp > datetime('now', '-7 days')
            GROUP BY final_tool
            HAVING failures > 2 AND failure_rate > 30
        """)

        for row in cursor.fetchall():
            finding = {
                'meta_type': 'blind_spot',
                'observation': f"Tool '{row['final_tool']}' has {row['failure_rate']}% failure rate ({row['failures']}/{row['total']} calls)",
                'conclusion': f"Possible issue with {row['final_tool']} usage or selection",
                'action': 'flag_for_review',
                'confidence': min(0.9, row['failures'] / 10)
            }
            findings.append(finding)

            # Store in meta_knowledge
            cursor.execute("""
                INSERT INTO meta_knowledge (meta_type, description, observation, conclusion, action_taken, confidence)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                finding['meta_type'],
                f"Blind spot: {row['final_tool']}",
                finding['observation'],
                finding['conclusion'],
                finding['action'],
                finding['confidence']
            ))

            intel_log.log_meta_cognition(
                finding['meta_type'], finding['observation'],
                finding['conclusion'], finding['action'], finding['confidence']
            )

        # ============================================
        # 2. DETECT OVER-GENERALIZATION
        # Insights that are applied too broadly
        # ============================================
        cursor.execute("""
            SELECT
                id, description, times_applied, times_helpful, times_failed,
                ROUND(100.0 * times_failed / NULLIF(times_applied, 0), 1) as failure_rate
            FROM insights
            WHERE times_applied > 5
            AND times_failed > times_helpful
        """)

        for row in cursor.fetchall():
            finding = {
                'meta_type': 'over_generalization',
                'observation': f"Insight #{row['id']} applied {row['times_applied']}x with {row['failure_rate']}% failure rate",
                'conclusion': f"Insight may be too general: '{row['description'][:50]}...'",
                'action': 'flag_for_selective_decay',
                'confidence': 0.7
            }
            findings.append(finding)

            cursor.execute("""
                INSERT INTO meta_knowledge (meta_type, description, observation, conclusion, action_taken, confidence)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                finding['meta_type'],
                f"Over-generalization: insight #{row['id']}",
                finding['observation'],
                finding['conclusion'],
                finding['action'],
                finding['confidence']
            ))

            intel_log.log_meta_cognition(
                finding['meta_type'], finding['observation'],
                finding['conclusion'], finding['action'], finding['confidence']
            )

        # ============================================
        # 3. ASSESS LEARNING QUALITY
        # Overall health of the learning system
        # ============================================
        cursor.execute("""
            SELECT
                COUNT(*) as total_insights,
                AVG(confidence) as avg_confidence,
                AVG(times_applied) as avg_applications,
                SUM(CASE WHEN times_applied > 0 THEN 1 ELSE 0 END) as insights_used
            FROM insights
        """)
        quality = cursor.fetchone()

        issues = []

        if quality['avg_confidence'] and quality['avg_confidence'] < 0.5:
            issues.append("Low average confidence - insights may not be reliable")

        if quality['total_insights'] > 20 and quality['insights_used'] < quality['total_insights'] * 0.2:
            issues.append("Many insights never applied - may be too specific")

        if quality['avg_applications'] and quality['avg_applications'] < 1:
            issues.append("Low insight application rate - matching may be too strict")

        if issues:
            finding = {
                'meta_type': 'learning_quality',
                'observation': f"Found {len(issues)} learning quality issue(s)",
                'conclusion': '; '.join(issues),
                'action': 'review_parameters',
                'confidence': 0.6
            }
            findings.append(finding)

            cursor.execute("""
                INSERT INTO meta_knowledge (meta_type, description, observation, conclusion, action_taken, confidence)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                finding['meta_type'],
                "Learning quality assessment",
                finding['observation'],
                finding['conclusion'],
                finding['action'],
                finding['confidence']
            ))

            intel_log.log_meta_cognition(
                finding['meta_type'], finding['observation'],
                finding['conclusion'], finding['action'], finding['confidence']
            )

        self.conn.commit()

        stats = {
            'findings_count': len(findings),
            'findings': findings,
            'quality_stats': {
                'total_insights': quality['total_insights'],
                'avg_confidence': round(quality['avg_confidence'] or 0, 3),
                'insights_used': quality['insights_used'],
                'avg_applications': round(quality['avg_applications'] or 0, 2)
            }
        }

        intel_log.log_maintenance_run('meta_cognition', stats)
        return stats

    async def run_all_maintenance(self, force: bool = False, dry_run: bool = False) -> dict[str, Any]:
        """Run all maintenance jobs and return combined results.

        Args:
            force: If True, bypass minimum interval check for decay job
            dry_run: If True, calculate decay changes without writing decay updates
        """
        results = {'backup_path': None}
        if dry_run:
            results['decay'] = await self.run_decay_job(
                force=force,
                dry_run=True,
                create_backup=False,
            )
            results['anomalies'] = {'status': 'skipped_dry_run'}
            results['meta_cognition'] = {'status': 'skipped_dry_run'}
            return results

        # Match decay-only ordering: reserve the writer slot first, then take
        # the verified pre-change snapshot, then plan/apply decay on that same
        # stable database state.
        maintenance_conn = self._open_maintenance_writer()
        try:
            results['backup_path'] = self._create_maintenance_backup(
                'all-maintenance'
            )
            results['decay'] = self._run_decay_job_with_connection(
                maintenance_conn,
                force=force,
                dry_run=False,
                create_backup=False,
            )
        except Exception:
            maintenance_conn.rollback()
            raise
        finally:
            if maintenance_conn.in_transaction:
                maintenance_conn.rollback()
            maintenance_conn.close()

        results['anomalies'] = await self.run_anomaly_detection()
        results['meta_cognition'] = await self.run_meta_cognition(create_backup=False)

        return results

    # ============================================
    # CLEANUP & MAINTENANCE
    # ============================================

    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            self.conn = None

    def get_stats(self) -> dict[str, Any]:
        """Get intelligence layer statistics."""
        cursor = self.conn.cursor()

        cursor.execute("SELECT COUNT(*) FROM experiences")
        exp_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM insights")
        insight_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM reflection_queue WHERE processed = 0")
        pending_reflections = cursor.fetchone()[0]

        cursor.execute("SELECT AVG(confidence) FROM insights")
        avg_confidence = cursor.fetchone()[0] or 0

        return {
            'experiences': exp_count,
            'insights': insight_count,
            'pending_reflections': pending_reflections,
            'avg_insight_confidence': round(avg_confidence, 3),
            'db_path': self.db_path
        }


# One instance per data mode. Cloud and local requests may coexist in the Web
# process, so switching one request must never close another request's DB.
_intelligence_layers: dict[str, IntelligenceLayer] = {}
_intelligence_lock = threading.RLock()

# Backward-compatible references to the most recently requested instance.
_intelligence_layer = None
_intelligence_mode = None

def _intelligence_db_path_for_mode(mode: str) -> str:
    """Resolve the Intelligence DB path for an explicit mode."""
    if mode not in {'cloud', 'local'}:
        raise ValueError(f"Invalid intelligence data mode: {mode!r}")
    project_root = Path(__file__).parent.parent.resolve()
    suffix = '_local' if mode == 'local' else ''
    return str(project_root / 'data' / f'jarvis_intelligence{suffix}.db')


def get_intelligence_layer(mode: str = None) -> IntelligenceLayer:
    """Get intelligence layer instance for the current mode."""
    global _intelligence_layer, _intelligence_mode

    # Resolve mode from the active config scope / JARVIS_MODE, never the provider.
    mode = get_active_config_mode(mode)

    with _intelligence_lock:
        layer = _intelligence_layers.get(mode)
        if layer is None or layer.conn is None:
            layer = IntelligenceLayer(db_path=_intelligence_db_path_for_mode(mode))
            _intelligence_layers[mode] = layer
        _intelligence_layer = layer
        _intelligence_mode = mode
        return layer


def reset_intelligence_layer(mode: str = None):
    """Close cached Intelligence layers, optionally for only one data mode."""
    global _intelligence_layer, _intelligence_mode
    with _intelligence_lock:
        if mode is None:
            layers = list(_intelligence_layers.values())
            _intelligence_layers.clear()
        else:
            resolved_mode = get_active_config_mode(mode)
            layer = _intelligence_layers.pop(resolved_mode, None)
            layers = [layer] if layer is not None else []
        for layer in layers:
            layer.close()
        _intelligence_layer = None
        _intelligence_mode = None


# ============================================
# CLI for testing
# ============================================

if __name__ == "__main__":
    import asyncio

    async def main():
        intel = IntelligenceLayer()

        print("Intelligence Layer Stats:")
        print(json.dumps(intel.get_stats(), indent=2))

        # Test recording an experience
        print("\nRecording test experience...")
        exp_id = await intel.record_experience(
            query="Is my server running?",
            tools_used=["search_memory", "mcp_fetch_fetch"],
            outcome={"success": True, "turns": 2},
            user_signals={"clarified": False, "thanked": True}
        )
        print(f"Recorded experience ID: {exp_id}")

        print("\nUpdated Stats:")
        print(json.dumps(intel.get_stats(), indent=2))

        intel.close()

    asyncio.run(main())

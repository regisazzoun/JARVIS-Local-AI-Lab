"""
Jarvis Docs server package.
"""

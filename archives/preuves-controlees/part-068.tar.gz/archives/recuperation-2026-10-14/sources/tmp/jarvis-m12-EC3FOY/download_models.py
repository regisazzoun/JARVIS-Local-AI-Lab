from pathlib import Path
import urllib.request,json,hashlib,time
p=Path('/tmp/jarvis-m12-EC3FOY');d=p/'models';d.mkdir(exist_ok=True);manifest=[]
cap=650*1024*1024;total=sum(x.stat().st_size for x in (p/'wheels').glob('*'))
def download(url,name,max_size):
 global total
 dest=d/name
 try:
  with urllib.request.urlopen(url,timeout=45) as response, dest.open('xb') as out:
   size=0
   while b:=response.read(1024*1024):
    size+=len(b);total+=len(b)
    if size>max_size or total>cap:raise RuntimeError('budget téléchargement dépassé')
    out.write(b)
  manifest.append({'name':name,'url':url,'bytes':size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()});print(name,size,flush=True)
 except Exception as e:print('EN ATTENTE',name,str(e),flush=True);manifest.append({'name':name,'url':url,'error':str(e)})
sha=json.loads((p/'metadata/rhasspy-piper-voices-hf.json').read_text())['sha']
for voice in ['siwis','tom']:
 base=f'https://huggingface.co/rhasspy/piper-voices/resolve/{sha}/fr/fr_FR/{voice}/medium/'
 for fn,limit in [(f'fr_FR-{voice}-medium.onnx',70_000_000),(f'fr_FR-{voice}-medium.onnx.json',100_000),('MODEL_CARD',100_000)]:download(base+fn,voice+'-'+fn,limit)
a=json.loads((p/'metadata/kokoro-assets.json').read_text())['assets']
for name in ['kokoro-v1.0.int8.onnx','voices-v1.0.bin']:
 item=next(x for x in a if x['name']==name);download(item['browser_download_url'],name,item['size']+100)
model=json.load(urllib.request.urlopen('https://huggingface.co/api/models/Systran/faster-whisper-base'));(p/'metadata/whisper-base-hf.json').write_text(json.dumps(model));sha=model['sha']
for fn in ['config.json','model.bin','tokenizer.json','vocabulary.json']:
 download(f'https://huggingface.co/Systran/faster-whisper-base/resolve/{sha}/{fn}','whisper-base-'+fn,160_000_000 if fn=='model.bin' else 5_000_000)
(p/'download-manifest.json').write_text(json.dumps({'downloaded_bytes_total':total,'cap_bytes':cap,'files':manifest},indent=2))

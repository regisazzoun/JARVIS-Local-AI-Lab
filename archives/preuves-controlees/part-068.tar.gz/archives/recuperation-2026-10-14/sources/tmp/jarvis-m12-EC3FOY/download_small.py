from pathlib import Path
import urllib.request,json,hashlib
p=Path('/tmp/jarvis-m12-EC3FOY');m=json.loads((p/'download-manifest.json').read_text());m['cap_bytes']=int(1.2*1024**3);m['cap_increase_reason']='Erreurs observées sur Whisper base : comparaison justifiée du modèle small multilingue CPU, sans changement Ollama.'
model=json.load(urllib.request.urlopen('https://huggingface.co/api/models/Systran/faster-whisper-small'));(p/'metadata/whisper-small-hf.json').write_text(json.dumps(model));sha=model['sha']
for fn in ['config.json','model.bin','tokenizer.json','vocabulary.txt']:
 url=f'https://huggingface.co/Systran/faster-whisper-small/resolve/{sha}/{fn}';dest=p/'models'/('whisper-small-'+fn);size=0
 with urllib.request.urlopen(url,timeout=45) as r,dest.open('xb') as out:
  while b:=r.read(1024*1024):
   size+=len(b)
   if size>510_000_000 or m['downloaded_bytes_total']+size>m['cap_bytes']:raise RuntimeError('download cap')
   out.write(b)
 m['files'].append({'name':dest.name,'url':url,'bytes':size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()});m['downloaded_bytes_total']+=size;print(dest.name,size,flush=True)
m['downloaded_bytes_total']+=39642563 # additional PyAV compatibility wheel
(p/'download-manifest.json').write_text(json.dumps(m,indent=2))

#define UTS_RELEASE "6.18.54-1-t2-trixie"
